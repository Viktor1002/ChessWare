import rage from './assets/fatachessty/rage.png';
import legit from './assets/fatachessty/legit.png';
import visuals from './assets/fatachessty/visuals.png';
import misc from './assets/fatachessty/misc.png';
import configs from './assets/fatachessty/configs.png';
import search from './assets/fatachessty/search.png';
import save from './assets/fatachessty/save.png';
import info from './assets/fatachessty/info.png';
import {VERSION} from './core.js';

// Same 848×588 frame, horizontal tabs, 3×256 groups and bottom toolbar as the source.
export const FATA_SECTIONS={
 Rage:[['General','engine','search','performance'],['Analysis','search','live-analysis','performance']],
 Legit:[['General','engine','search','strength-limits'],['Analysis','search','live-analysis','strength-limits']],
 Visuals:[['Board','board-visuals','move-visuals','customization'],['Chams','piece-chams','chams-materials','customization'],['Style','customization','board-visuals','move-visuals']],
 Misc:[['General','interface','chess-utilities','general']],
 Configs:[['General','local-configurations','manage-configuration','storage']]
};
export class FatachesstyLayout{
 constructor(root,store,ui){
  this.root=root;this.store=store;this.ui=ui;this.views=new Map();this.original=new Map();
  for(const panel of root.querySelectorAll('fieldset'))this.original.set(panel,{parent:panel.parentNode,next:panel.nextSibling});
  this.menu=root.querySelector('.menu');
  this.menu.insertAdjacentHTML('beforeend','<div class="ft-brand" aria-hidden="true">Fatachessty</div><div class="ft-tools" aria-label="Menu tools"></div><div class="ft-dialog" role="dialog" aria-label="Menu information" hidden></div>');
  for(const [tab,url]of Object.entries({Rage:rage,Legit:legit,Visuals:visuals,Misc:misc,Configs:configs}))root.querySelector(`[data-tab="${tab}"] .nav-svg`).style.setProperty('--ft-icon',`url("${url}")`);
  for(const [label,url,callback]of [
   ['Search',search,()=>this.openSearch()],['Quicksave',save,()=>{ui.profileId=store.data.active;ui.handleAction('save');}],
   ['About',info,()=>this.openAbout()]
  ]){const button=document.createElement('button');button.className='ft-tool';button.title=label;button.setAttribute('aria-label',label);button.style.setProperty('--ft-icon',`url("${url}")`);button.onclick=callback;root.querySelector('.ft-tools').append(button);}
  for(const [tab,sections]of Object.entries(FATA_SECTIONS)){
   const bar=document.createElement('div');bar.className='ft-subnav';bar.setAttribute('aria-label',tab+' sections');
   sections.forEach(([label],index)=>{const button=document.createElement('button');button.textContent=label;button.dataset.ftSection=index;button.setAttribute('aria-pressed','false');button.onclick=()=>this.select(tab,index);bar.append(button);});
   root.querySelector(`[data-page="${tab}"]`).prepend(bar);
  }
  this.dialog=root.querySelector('.ft-dialog');
  this.dialog.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();this.close();}});
  this.outside=e=>{if(!e.target.closest('.ft-dialog,.ft-tool'))this.close();};root.addEventListener('pointerdown',this.outside);
 }
 select(tab,index){this.views.set(tab,index);this.update(tab,true);}
 fitBrand(){
  if(this.menu.dataset.skin!=='fatachessty'||this.menu.hidden)return;
  const brand=this.root.querySelector('.ft-brand');let size=18;brand.style.fontSize=size+'px';
  while(brand.scrollWidth>brand.clientWidth&&size>10){size-=.25;brand.style.fontSize=size+'px';}
 }
 update(tab,enabled){
  const signature=JSON.stringify([tab,enabled,this.views.get(tab)||0]);if(signature===this.signature)return;this.signature=signature;
  this.close();
  const materials=this.root.querySelector('[data-panel="chams-materials"]'),controls=this.root.querySelector('.chams-material-controls');
  if(!enabled){
   for(const [panel,where]of [...this.original].reverse()){where.parent.insertBefore(panel,where.next?.parentNode===where.parent?where.next:null);panel.hidden=false;panel.removeAttribute('data-ft-column');}
   this.root.querySelector('[data-panel="piece-chams"] .panel-body').prepend(controls);materials.hidden=true;return;
  }
  materials.querySelector('.panel-body').append(controls);
  const definitions=FATA_SECTIONS[tab],index=this.views.get(tab)||0,selected=definitions[index],page=this.root.querySelector(`[data-page="${tab}"]`),columns=page.querySelector('.columns');
  page.dataset.ftTabbed=String(definitions.length>1);
  for(const [i,button]of [...page.querySelector('.ft-subnav').children].entries())button.setAttribute('aria-pressed',String(i===index));
  for(const panel of page.querySelectorAll('fieldset')){const column=selected.indexOf(panel.dataset.panel);panel.hidden=column<1;panel.dataset.ftColumn=column;}
  for(const name of selected.slice(1))columns.append(page.querySelector(`[data-panel="${name}"]`));
 }
 close(){this.dialog.hidden=true;}
 heading(title){
  this.dialog.replaceChildren();this.dialog.hidden=false;
  const header=document.createElement('div');header.className='ft-dialog-heading';const name=document.createElement('strong');name.textContent=title;
  const close=document.createElement('button');close.textContent='×';close.setAttribute('aria-label','Close dialog');close.onclick=()=>this.close();header.append(name,close);this.dialog.append(header);
 }
 openAbout(){
  this.heading('Fatachessty');const text=document.createElement('p');text.textContent=`ChessWare ${VERSION} · Fatality GUI source port. Stockfish 19 NNUE. Local configurations; manual activation for each game.`;this.dialog.append(text);
  const status=document.createElement('p');status.textContent=this.root.querySelector('.footer .status').textContent;this.dialog.append(status);this.dialog.querySelector('button').focus();
 }
 openSearch(){
  this.heading('Search');const input=document.createElement('input');input.className='text-input';input.placeholder='Find a setting';input.setAttribute('aria-label','Find a setting');
  const results=document.createElement('div');results.className='ft-search-results';this.dialog.append(input,results);
  const render=()=>{
   results.replaceChildren();const query=input.value.trim().toLowerCase();if(!query)return;
   const seen=new Set();
   for(const label of this.root.querySelectorAll('[data-page] .check span,[data-page] .control-name,[data-page] .control-label,[data-page] .color-row label')){
    const text=label.textContent;if(!text.toLowerCase().includes(query))continue;
    const panel=label.closest('fieldset'),tab=label.closest('[data-page]').dataset.page,id=tab+':'+text;if(seen.has(id))continue;seen.add(id);
    const button=document.createElement('button');button.textContent=`${tab} › ${text}`;
    button.onclick=()=>{const index=FATA_SECTIONS[tab].findIndex(section=>section.includes(panel.dataset.panel));this.views.set(tab,Math.max(0,index));this.signature='';this.store.patch({tab});this.close();label.closest('.check,.control,.color-row').scrollIntoView({block:'center'});const control=label.closest('.check,.control,.color-row').querySelector('input,button');control?.focus();};results.append(button);
   }
   if(!results.children.length)results.textContent='No settings found.';
  };input.oninput=render;input.focus();
 }
 destroy(){this.root.removeEventListener('pointerdown',this.outside);}
}
