// Arms are scoped to one observed game. This prevents carry-over, not detection.
export class GameSession {
  update(snapshot,allowed){
    if(!allowed){this.previous=null;return true;}
    const current={board:snapshot.board,game:snapshot.game,key:snapshot.sessionKey,player:snapshot.player,bot:snapshot.bot,ply:Array.isArray(snapshot.history)?snapshot.history.length:null};
    const prior=this.previous;this.previous=current;
    return !prior||prior.board!==current.board||prior.game!==current.game||prior.key!==current.key||prior.player!==current.player||prior.bot!==current.bot||
      (prior.ply!==null&&current.ply!==null&&current.ply<prior.ply);
  }
}
