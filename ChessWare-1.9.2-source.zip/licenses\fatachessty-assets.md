# Fatachessty source assets

Source supplied by the user: `FatalityGUI_Standalone/FatalityGUI_Standalone`.

- `src/resources/josefin_sans.h`: Josefin Sans SemiBold, used as the original GUI's main face.
- `src/resources/josefin_sans_bold.h`: Josefin Sans Bold, used for the title and selected tabs.
- Both embedded fonts identify their licence as SIL Open Font License 1.1 in name-table entries 13/14, pointing to `http://scripts.sil.org/OFL`. Their original font binaries and embedded notices are retained.
- Eight icons come from `src/menu/resources/icon_{rage,legit,visuals,misc,configs,search,save,info}.h`.
- Geometry/widgets/colours are read from the standalone GUI source, principally `gui/helpers.cpp`, `gui/gui.h`, `gui/controls/window.cpp`, `tab.cpp`, `group.cpp`, `checkbox.cpp`, `slider.cpp` and `combo_box.cpp`.

`scripts/import-fatachessty.mjs` imports data only. `src/assets/fatachessty/manifest.json` records source paths, byte counts and SHA-256 values. The native executable and Counter-Strike internals are not distributed in the userscript.
