import {ENABLED_DEFAULTS as DEFAULTS} from './fixtures/features.mjs';
import {chromium,expect} from '@playwright/test';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import {STORAGE_KEY} from '../src/core.js';
import {NEVER_SECTIONS} from '../src/neverchess-layout.js';
const server=spawn(process.execPath,['scripts/serve.mjs','--port','4186'],{stdio:['ignore','pipe','inherit']});let browser;
try{
 await new Promise(resolve=>server.stdout.once('data',resolve));browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:900}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(({key,defaults})=>{if(!localStorage.getItem(key)){const s={...defaults,rageEnabled:false,legitEnabled:false,wmPing:false,menuStyle:'NeverChess',width:690,height:500,spacing:8,x:650,y:105};localStorage.setItem(key,JSON.stringify({version:1,defaultsRevision:1,menuRevision:2,brand:'chessence',settings:s,active:'default',profiles:[{id:'default',name:'Default',settings:s}]}));}},{key:STORAGE_KEY,defaults:DEFAULTS});
 await page.goto('http://127.0.0.1:4186');await page.keyboard.press('Insert');
 const relative=locator=>locator.evaluate(n=>{const r=n.getBoundingClientRect(),m=n.getRootNode().querySelector('.menu').getBoundingClientRect();return {x:r.x-m.x,y:r.y-m.y,w:r.width,h:r.height};});
 assert.deepEqual(await relative(page.locator('.nc-save')),{x:190,y:20,w:100,h:25});assert.deepEqual(await relative(page.locator('.nc-sections')),{x:300,y:20,w:240,h:25});
 assert.deepEqual(await relative(page.locator('.main')),{x:185,y:76,w:490,h:404});
 assert.equal(await page.locator('.nc-brand').evaluate(n=>getComputedStyle(n).fontSize),'22px');
 const tabs=await page.locator('.nav>button').evaluateAll(nodes=>nodes.map(n=>n.getAttribute('aria-label')));assert.deepEqual(new Set(tabs),new Set(['Legit','Rage','Misc','Visuals','Configs']));
 for(const [tab,sections]of Object.entries(NEVER_SECTIONS)){
   await page.getByRole('tab',{name:tab,exact:true}).click();
   for(let i=0;i<3;i++){
     await page.locator(`[data-nc-section="${i}"]`).click();const panels=page.locator(`[data-page="${tab}"] fieldset:visible`);
     assert.equal(await panels.count(),2);assert.deepEqual(new Set(await panels.evaluateAll(nodes=>nodes.map(n=>n.dataset.panel))),new Set(sections[i].slice(1)));
   }
 }
 await page.getByRole('tab',{name:'Visuals',exact:true}).click();await page.locator('[data-nc-section="1"]').click();
 const toggle=page.getByLabel('Extra Outline',{exact:true});assert.deepEqual(await toggle.evaluate(n=>{const r=n.getBoundingClientRect();return [r.width,r.height];}),[30,17]);
 await toggle.check();assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsOutline),true);
 const track=page.getByLabel('Outline Width',{exact:true});assert.deepEqual(await track.evaluate(n=>{const r=n.getBoundingClientRect();return [r.width,r.height];}),[92,4]);await track.focus();await page.keyboard.press('ArrowRight');assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsOutlineWidth),3);
 await page.getByRole('button',{name:'Material Flat',exact:true}).click();await page.getByRole('option',{name:'Metallic',exact:true}).click();assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsMaterial),'Metallic');
 await page.getByRole('button',{name:'Own Material Inherit',exact:true}).click();await page.getByRole('option',{name:'Neon',exact:true}).click();assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsOwnMaterial),'Neon');
 await page.getByRole('button',{name:'Choose Own Color',exact:true}).click();await expect(page.getByRole('dialog',{name:'Color picker'})).toBeVisible();
 await page.getByLabel('Hex color',{exact:true}).fill('#ee1188');await page.getByLabel('Hex color',{exact:true}).press('Tab');assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsOwnColor),'#ee1188');
 const sv=page.getByRole('slider',{name:'Saturation and brightness',exact:true});await sv.click({position:{x:100,y:85}});const value=await page.evaluate(()=>window.__skeet.app.store.settings.chamsOwnColor);assert.notEqual(value,'#ee1188');
 await page.getByRole('slider',{name:'Color opacity',exact:true}).focus();await page.keyboard.press('ArrowLeft');assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsOwnAlpha),99);assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsOpacity),55);
 await page.screenshot({path:'test-results/neverchess-source-picker.png'});await page.keyboard.press('Escape');await expect(page.getByRole('dialog',{name:'Color picker'})).toBeHidden();
 await page.locator('.nc-save').click();assert.equal(await page.evaluate(()=>window.__skeet.app.store.dirty),false);
 await page.getByRole('tab',{name:'Misc',exact:true}).click();await page.locator('[data-nc-section="0"]').click();await page.getByRole('button',{name:'Menu Style NeverChess',exact:true}).click();await page.getByRole('option',{name:'chessence',exact:true}).click();
 await page.getByRole('tab',{name:'Visuals',exact:true}).click();await expect(page.getByRole('button',{name:'Material Metallic',exact:true})).toBeVisible();
 // Settings remain usable in old Skeet and survive a document reload.
 await page.reload();await expect(page.locator('.menu')).toBeVisible();assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsOwnColor),value);assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsOwnMaterial),'Neon');
 await page.keyboard.press('Insert');await page.reload();await expect(page.locator('.menu')).toBeHidden();assert.deepEqual(errors,[]);
 console.log('PASS source geometry, 30x17 switches, 92x4 slider, all 15 functional sections, preserved main tabs, portal selects, custom HSV/alpha/hex editor, save, skin restoration and navigation.');
}finally{await browser?.close();server.kill();}
