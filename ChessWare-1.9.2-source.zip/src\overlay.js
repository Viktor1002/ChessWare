import { Chess, legalMove } from './core.js';
import overlayCss from './overlay.css';

const NS = 'http://www.w3.org/2000/svg';
const EXIT_MS = 220;
let nextOverlayId = 0;

// Kept independent of the DOM so the position and colour rules can be checked directly.
export function overlayDescriptors(snapshot, settings, state, ids, boardWidth = 800) {
  const { best, lines = [], threats = [], selected, analysisAllowed } = state;
  const game = new Chess(snapshot.fen), items = new Map();
  const xy = square => {
    let x = square.charCodeAt(0) - 97, y = 8 - Number(square[1]);
    if (snapshot.flipped) { x = 7 - x; y = 7 - y; }
    return [x * 100, y * 100];
  };
  const add = (key, kind, opacity, parts) => items.set(key, { kind, opacity, parts });
  const square = (key, sq, color, filled = true, kind = 'highlight') => {
    if (!/^[a-h][1-8]$/.test(sq || '')) return;
    const [x, y] = xy(sq);
    add(key, kind, filled ? settings.opacity / 100 : .86, [{ tag: 'rect', attrs: {
      x: x + 3, y: y + 3, width: 94, height: 94, rx: 5,
      fill: filled ? `url(#${kind === 'check' ? ids.check : ids.highlight})` : color,
      'fill-opacity': filled ? 1 : .06, stroke: color,
      'stroke-opacity': filled ? .28 : .95, 'stroke-width': filled ? 1.5 : 3
    } }]);
  };
  if (settings.lastMove && snapshot.last) {
    square('last-from', snapshot.last.from, settings.highlightColor);
    square('last-to', snapshot.last.to, settings.highlightColor);
  }
  if (selected && game.get(selected)?.color === game.turn()) {
    if (settings.selected) square(`selected:${selected}`, selected, settings.highlightColor, false, 'selected');
    for (const move of game.moves({ square: selected, verbose: true })) {
      const [x, y] = xy(move.to);
      if (move.captured && settings.captures) add(`capture:${move.to}`, 'capture', .85, [{ tag: 'circle', attrs: {
        cx: x + 50, cy: y + 50, r: 41, fill: 'none', stroke: settings.highlightColor, 'stroke-width': 5
      } }]);
      else if (settings.legal && !move.captured) add(`legal:${move.to}`, 'legal', .72, [{ tag: 'circle', attrs: {
        cx: x + 50, cy: y + 50, r: 9, fill: `url(#${ids.marker})`, stroke: settings.highlightColor,
        'stroke-width': 1, 'stroke-opacity': .8
      } }]);
    }
  }
  if (settings.threatIndicators) for (const threat of threats) {
    square(`threat:${threat.square}`, threat.square, settings.highlightColor, false, 'threat');
  }
  const king = game.board().flat().find(p => p?.type === 'k' && p.color === game.turn());
  if (king && ((settings.check && game.isCheck()) || (settings.mateIndicator && game.isCheckmate()))) {
    square(`check:${king.square}`, king.square, settings.highlightColor, true, 'check');
    if (settings.mateIndicator && game.isCheckmate()) {
      const [x, y] = xy(king.square);
      add(`mate:${king.square}`, 'mate', .95, [
        { tag: 'rect', attrs: { x: x + 19, y: y + 69, width: 62, height: 22, rx: 3, fill: settings.highlightColor, 'fill-opacity': .88 } },
        { tag: 'text', attrs: { x: x + 50, y: y + 84, 'text-anchor': 'middle', fill: '#fff', 'font-size': 13, 'font-family': 'Verdana', 'letter-spacing': 1 }, text: 'MATE' }
      ]);
    }
  }
  const show = analysisAllowed && ((settings.rageEnabled && settings.bestMove) || (settings.legitEnabled && settings.suggestion));
  if (show && (settings.arrow || settings.arrows) && best) {
    const moves = settings.arrows ? [best, ...lines.map(l => l.pv[0]).filter(m => m !== best)] : [best];
    const width = settings.thickness * 800 / Math.max(1, boardWidth);
    for (const [index, uci] of [...new Set(moves)].slice(0, 5).entries()) {
      if (!legalMove(snapshot.fen, uci)) continue;
      const [sx, sy] = xy(uci.slice(0, 2)), [tx, ty] = xy(uci.slice(2, 4));
      const dx = tx - sx, dy = ty - sy, len = Math.hypot(dx, dy), ux = dx / len, uy = dy / len;
      const x = sx + 50 + ux * 24, y = sy + 50 + uy * 24;
      const ex = tx + 50, ey = ty + 50, head = Math.max(24, width * 2.25), halfHead = Math.max(15, width * 1.4);
      const bx = ex - ux * head, by = ey - uy * head;
      add(`arrow:${uci}`, 'arrow', (index === 0 ? .9 : Math.max(.26, .62 - index * .08)) * settings.arrowAlpha / 100, [
        { tag: 'line', attrs: { x1: x, y1: y, x2: bx + ux * 3, y2: by + uy * 3, stroke: settings.arrowColor, 'stroke-width': width, 'stroke-linecap': 'round' } },
        { tag: 'polygon', attrs: { points: `${ex},${ey} ${bx - uy * halfHead},${by + ux * halfHead} ${bx + uy * halfHead},${by - ux * halfHead}`, fill: settings.arrowColor, stroke: settings.arrowColor, 'stroke-width': 1.5, 'stroke-linejoin': 'round' } }
      ]);
    }
  }
  return items;
}

export class BoardOverlay {
  constructor(svg) {
    this.svg = svg; this.items = new Map(); this.exiting = new Map(); this.entering = new Set(); this.frames = new Set();
    const prefix = `chessence-overlay-${++nextOverlayId}`;
    this.ids = { highlight: prefix + '-highlight', marker: prefix + '-marker', check: prefix + '-check' };
    this.media = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)');
    this.onMotionChange = () => this.setMotion(this.animate);
    this.media?.addEventListener?.('change', this.onMotionChange);
    this.style = document.createElement('style'); this.style.textContent = overlayCss;
    this.svg.getRootNode().append(this.style);
    this.animate = true; this.setMotion(true);
  }
  make(tag, attrs = {}, parent = this.svg) {
    const node = document.createElementNS(NS, tag);
    for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, String(value));
    parent.append(node); return node;
  }
  setMotion(animate) {
    this.animate = animate; this.motion = !!animate && !this.media?.matches;
    this.svg.classList.toggle('cs-overlay-motion', this.motion);
    if (!this.motion) {
      for (const frame of this.frames) cancelAnimationFrame(frame);
      this.frames.clear();
      for (const group of this.entering) group.removeAttribute('data-entering');
      this.entering.clear();
      for (const [key, entry] of this.exiting) { clearTimeout(entry.timer); entry.node.remove(); this.exiting.delete(key); }
      if (!this.items.size && !this.exiting.size) this.svg.setAttribute('hidden', '');
    }
  }
  frame(callback) {
    const frame = requestAnimationFrame(() => { this.frames.delete(frame); if (!this.disposed) callback(); });
    this.frames.add(frame);
  }
  enter(group) {
    if (!this.motion) return;
    group.setAttribute('data-entering', ''); this.entering.add(group);
    if (this.frames.size) return;
    // Two frames guarantee the initial transparent state is painted before transition.
    this.frame(() => this.frame(() => {
      for (const node of this.entering) if (node.parentNode === this.svg) node.removeAttribute('data-entering');
      this.entering.clear();
    }));
  }
  retire(key, entry) {
    this.items.delete(key); this.entering.delete(entry.node);
    if (!this.motion) { entry.node.remove(); return; }
    entry.node.removeAttribute('data-entering'); entry.node.setAttribute('data-leaving', '');
    entry.timer = setTimeout(() => {
      entry.node.remove(); this.exiting.delete(key);
      if (!this.items.size && !this.exiting.size) this.svg.setAttribute('hidden', '');
    }, EXIT_MS);
    this.exiting.set(key, entry);
  }
  definitions(settings) {
    if (!this.defs) {
      this.defs = this.make('defs');
      const highlight = this.make('linearGradient', { id: this.ids.highlight, x1: 0, y1: 0, x2: 0, y2: 1 }, this.defs);
      this.highlightStops = [this.make('stop', { offset: 0, 'stop-opacity': .95 }, highlight), this.make('stop', { offset: 1, 'stop-opacity': .55 }, highlight)];
      const marker = this.make('radialGradient', { id: this.ids.marker }, this.defs);
      this.markerStops = [this.make('stop', { offset: 0, 'stop-opacity': .95 }, marker), this.make('stop', { offset: 1, 'stop-opacity': .7 }, marker)];
      const check = this.make('radialGradient', { id: this.ids.check }, this.defs);
      this.checkStops=[this.make('stop', { offset: 0, 'stop-opacity': .95 }, check),this.make('stop', { offset: 1, 'stop-opacity': .55 }, check)];
    }
    for (const stop of [...this.highlightStops, ...this.markerStops, ...this.checkStops]) stop.setAttribute('stop-color', settings.highlightColor);
  }
  clear() {
    for (const frame of this.frames) cancelAnimationFrame(frame);
    this.frames.clear(); this.entering.clear();
    for (const entry of this.exiting.values()) clearTimeout(entry.timer);
    this.exiting.clear(); this.items.clear(); this.svg.replaceChildren(); this.svg.setAttribute('hidden', '');
    this.signature = ''; this.board = null; this.position = ''; this.defs = null;
  }
  render(snapshot, settings, state) {
    if (this.disposed) return;
    this.setMotion(settings.animation);
    if (!state.allowed || !snapshot.board?.isConnected) { this.clear(); return; }
    const rect = snapshot.board.getBoundingClientRect();
    if (!rect.width || !rect.height) { this.clear(); return; }
    const position = snapshot.fen + '|' + snapshot.flipped;
    // A changed board or position must never retain arrows describing the previous one.
    if (this.board !== snapshot.board || this.position !== position) this.clear();
    this.board = snapshot.board; this.position = position;
    for (const [key, value] of Object.entries({ left: rect.left, top: rect.top, width: rect.width, height: rect.height })) {
      if (this.svg.style[key] !== value + 'px') this.svg.style[key] = value + 'px';
    }
    this.svg.setAttribute('viewBox', '0 0 800 800');
    const signature = JSON.stringify([position, snapshot.last?.from, snapshot.last?.to, state.best, (state.lines || []).map(l => l.pv[0]), state.threats, state.selected, state.analysisAllowed, rect.width,
      ...['lastMove','selected','legal','captures','threatIndicators','check','mateIndicator','rageEnabled','bestMove','legitEnabled','suggestion','arrow','arrows','opacity','highlightColor','arrowColor','arrowAlpha','thickness'].map(k => settings[k])]);
    if (this.signature === signature) return;
    this.signature = signature;
    let desired;
    try { desired = overlayDescriptors(snapshot, settings, state, this.ids, rect.width); }
    catch { this.clear(); return; }
    this.definitions(settings);
    for (const [key, entry] of this.items) if (!desired.has(key)) this.retire(key, entry);
    for (const [key, spec] of desired) {
      let entry = this.items.get(key);
      if (!entry && this.exiting.has(key)) {
        entry = this.exiting.get(key); clearTimeout(entry.timer); this.exiting.delete(key);
        entry.node.removeAttribute('data-leaving'); this.items.set(key, entry);
      }
      if (!entry) {
        const group = this.make('g', { class: 'cs-visual', 'data-visual-key': key, 'data-kind': spec.kind });
        entry = { node: group, fingerprint: '' }; this.items.set(key, entry); this.enter(group);
      }
      const fingerprint = JSON.stringify(spec.parts);
      if (entry.fingerprint !== fingerprint) {
        entry.node.replaceChildren();
        for (const part of spec.parts) { const node = this.make(part.tag, part.attrs, entry.node); if (part.text) node.textContent = part.text; }
        entry.fingerprint = fingerprint;
      }
      entry.node.style.setProperty('--cs-visual-opacity', spec.opacity);
    }
    let previous = this.defs;
    for (const key of desired.keys()) {
      const node = this.items.get(key).node;
      if (previous.nextSibling !== node) this.svg.insertBefore(node, previous.nextSibling);
      previous = node;
    }
    this.svg.toggleAttribute('hidden', !this.items.size && !this.exiting.size);
  }
  destroy() {
    this.clear(); this.disposed = true;
    this.media?.removeEventListener?.('change', this.onMotionChange);
    this.style.remove();
  }
}
