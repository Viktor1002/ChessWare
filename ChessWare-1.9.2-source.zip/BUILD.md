# Build

Node.js 22+.

```sh
npm ci
npm run build:protected
npm run test:loader
```

The protected loader is built by scripts/build-loader.mjs. Source: loader/ and src/. Vendor licenses: licenses/. All required interface resources are included in src/assets/. The installed userscript requires a network connection. Client-side obfuscation does not provide authentication or prevent inspection of running code.
