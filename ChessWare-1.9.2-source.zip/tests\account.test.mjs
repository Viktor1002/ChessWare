import {test} from 'node:test';
import assert from 'node:assert/strict';
import {resolveAccountName,resolveAccountProfile,ProfileIdentity,avatarUrl,accountName} from '../src/account.js';
const fixture=(side,headers)=>({JSON,document:{querySelectorAll:()=>[{getBoundingClientRect:()=>({width:500}),game:{getPlayingAs:()=>side,getHeaders:()=>headers}}]}});
test('signed-in navigation account takes priority over game player names',()=>{const page=fixture(1,{White:'Alias',Black:'Opponent'});page.context={user:{username:'LoVeOfCrAcKs'}};assert.equal(resolveAccountName(page),'LoVeOfCrAcKs');});
test('fallback reads the own colour, never opponent or board orientation',()=>{assert.equal(resolveAccountName(fixture(1,{White:'OwnerWhite',Black:'Opponent'})),'OwnerWhite');assert.equal(resolveAccountName(fixture(2,{White:'Opponent',Black:'OwnerBlack'})),'OwnerBlack');assert.equal(resolveAccountName(fixture(null,{White:'OpponentA',Black:'OpponentB'})),'Guest');});
test('guest and unavailable Firefox context fail safely without taking the bot name',()=>{const page=fixture(1,{White:'null',Black:'Marko'});Object.defineProperty(page,'context',{get(){throw new Error('Permission denied to access object');}});assert.equal(resolveAccountName(page),'Guest');assert.equal(accountName('<img src=x>'),null);assert.equal(accountName('Player|foo'),null);assert.equal(resolveAccountName({}),'Guest');});
test('account avatar is paired with its own username and rejects unrelated or unsafe URLs',()=>{
 const page=fixture(2,{White:'Opponent',Black:'GameAlias'});page.context={user:{username:'AccountOwner',avatar:{url:'https://images.chesscomfiles.com/uploads/owner.png'}}};
 assert.deepEqual(resolveAccountProfile(page),{username:'AccountOwner',avatar:'https://images.chesscomfiles.com/uploads/owner.png',source:'account'});
 for(const value of ['', 'javascript:alert(1)','https://chess.com.evil.example/avatar.png','data:image/svg+xml,hello'])assert.equal(avatarUrl(value),null);
 assert.equal(resolveAccountProfile(fixture(1,{White:'Guest',Black:'Marko'})).username,null);
});
test('public avatar lookup is cached, DOM avatar wins, and switching account cancels stale requests',async()=>{
 const page={context:{user:{username:'First'}},document:{querySelectorAll:()=>[]}};let calls=0,finish;
 const identity=new ProfileIdentity(page,()=>{calls++;return new Promise(resolve=>finish=resolve);});
 identity.read();await Promise.resolve();assert.equal(calls,1);
 page.context.user={username:'Second',avatar:'https://images.chesscomfiles.com/second.png'};assert.equal(identity.read().avatar,'https://images.chesscomfiles.com/second.png');
 finish('https://images.chesscomfiles.com/first.png');await new Promise(resolve=>setImmediate(resolve));assert.equal(identity.read().username,'Second');assert.equal(identity.read().avatar,'https://images.chesscomfiles.com/second.png');identity.destroy();
 const cached=new ProfileIdentity(page,async()=>{calls++;return 'https://images.chesscomfiles.com/api-second.png';});page.context.user={username:'Second'};cached.read();await new Promise(resolve=>setImmediate(resolve));assert.equal(cached.read().avatar,'https://images.chesscomfiles.com/api-second.png');const count=calls;cached.read();assert.equal(calls,count);cached.destroy();
});
