import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULTS, sanitize } from '../src/core.js';
import { watermarkParts } from '../src/watermark.js';
test('watermark removes even legacy tickrate fields and renders ping and time',()=>{
 const date=new Date(2026,10,7,14,5,9);
 assert.deepEqual(watermarkParts({...DEFAULTS,wmPing:true,wmTime:true,wmSeconds:true,wmBrand:'old-brand',wmNickname:'Opponent',wmTick:true,wmTickText:'64 tick'},date,37,'Alex'),['chessence','Alex','37 ms','14:05:09']);
 assert.deepEqual(watermarkParts({...DEFAULTS,wmPing:false,wmTime:false},date,null),['chessence','Guest']);
 assert.equal('wmTick' in sanitize({wmTick:true,wmTickText:'64 tick'}),false);
 assert.equal(watermarkParts({...DEFAULTS,wmPing:true},date,null)[2],'— ms');
 for(const menuStyle of ['chessence','NeverChess','Fatachessty'])assert.equal(watermarkParts({...DEFAULTS,menuStyle},date,null,'Alex')[0],menuStyle==='NeverChess'?'NC':menuStyle);
 const migrated=sanitize({menuStyle:'Old — Skeet',width:730,oldWidth:730});assert.equal(migrated.menuStyle,'chessence');assert.equal(migrated.width,730);assert.equal(migrated.oldWidth,730);
});
test('obsolete identity and analysis hotkey settings are removed from loaded configs',()=>{
 const s=sanitize({wmBrand:'other',wmNickname:'Opponent',analysisKey:'F6',wmOpacity:1000,wmPosition:'invalid'});assert.equal('wmBrand' in s,false);assert.equal('wmNickname' in s,false);assert.equal('analysisKey' in s,false);assert.equal(s.wmOpacity,100);assert.equal(s.wmPosition,'Top right');
});
