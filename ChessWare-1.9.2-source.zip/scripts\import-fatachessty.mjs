// Data-only import from the user's standalone GUI source. Never executes its native code.
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
const root=resolve(process.argv[2]||'FatalityGUI_Standalone/FatalityGUI_Standalone');
await mkdir('src/assets/fatachessty',{recursive:true});
const assets=[];
for(const [source,target,type]of [
 ['resources/josefin_sans.h','josefin-regular.ttf','font'],['resources/josefin_sans_bold.h','josefin-bold.ttf','font'],
 ...['rage','legit','visuals','misc','configs','search','save','info'].map(name=>[`menu/resources/icon_${name}.h`,`${name}.png`,'png'])
]){
 const text=await readFile(join(root,'src',source),'utf8'),body=text.match(/=\s*\{([\s\S]*?)\};/);
 if(!body)throw new Error(`Missing array in ${source}`);
 const bytes=Buffer.from([...body[1].matchAll(/0x([0-9a-f]{1,2})\b/gi)].map(m=>parseInt(m[1],16)));
 if(type==='font'?bytes.readUInt32BE(0)!==0x10000:bytes.readUInt32BE(0)!==0x89504e47)throw new Error(`Invalid ${type}: ${source}`);
 await writeFile(`src/assets/fatachessty/${target}`,bytes);
 assets.push({source,target,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});
}
await writeFile('src/assets/fatachessty/manifest.json',JSON.stringify(assets,null,2)+'\n');
console.log(`Imported ${assets.length} original fonts/icons without executing native code.`);
