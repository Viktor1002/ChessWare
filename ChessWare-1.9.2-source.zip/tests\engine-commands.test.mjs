import {test} from 'node:test';
import assert from 'node:assert/strict';
import {StockfishEngine} from '../src/engine.js';
test('weaker UCI choice is returned even outside PV1 and Rage resets the engine skill',async()=>{
 const engine=new StockfishEngine(),commands=[];
 engine.init=async()=>{};engine.send=command=>commands.push(command);engine.sync=async()=>{};
 engine.waitFor=async()=>{engine.lines.set(1,{index:1,pv:['e2e4'],score:50,kind:'cp'});return 'bestmove g1f3';};
 const options={threads:1,hash:64,multiPV:3,depth:10,time:700,skill:4};
 const weak=await engine.search('start position',options,()=>{});
 assert.equal(weak.move,'g1f3');assert.equal(weak.lines[0].pv[0],'e2e4');
 assert.ok(commands.includes('setoption name UCI_LimitStrength value false'));assert.ok(commands.includes('setoption name Skill Level value 4'));
 commands.length=0;await engine.search('start position',{...options,skill:20},()=>{});
 assert.ok(commands.includes('setoption name Skill Level value 20'));assert.ok(commands.includes('setoption name UCI_LimitStrength value false'));
});
