import { boot } from '../src/app.js';
import { ChessComAdapter } from '../src/adapter.js';
import { Chess, DEFAULTS, STORAGE_KEY } from '../src/core.js';
const chess=new Chess();let flipped=false,mode='bot',selected=null,botTimer,moveCount=0;
for(const san of ['e4','e5','Nf3','Nc6','Bc4','Nf6'])chess.move(san);
const board=document.querySelector('wc-chess-board');
const pieces={w:{p:'♙',n:'♘',b:'♗',r:'♖',q:'♕',k:'♔'},b:{p:'♟',n:'♞',b:'♝',r:'♜',q:'♛',k:'♚'}};
function render(){board.id=mode==='bot'?'board-play-computer':'board-single';board.replaceChildren();for(let r=0;r<8;r++)for(let f=0;f<8;f++){const file=flipped?7-f:f,rank=flipped?r:7-r,square=String.fromCharCode(97+file)+(rank+1),piece=chess.get(square),n=document.createElement('button');n.className=`square ${(f+r)%2?'dark':'light'} ${piece?.color==='w'?'white':'black'}`;n.dataset.square=square;n.setAttribute('aria-label',square);n.textContent=piece?pieces[piece.color][piece.type]:'';if(r===7){const c=document.createElement('span');c.className='coord';c.textContent=square[0];n.append(c);}board.append(n);}document.querySelector('#fixture-status').textContent=mode==='off'?'Outside game fixture':`${mode==='bot'?'Bot':'Multiplayer'} metadata fixture · ${chess.turn()==='w'?'White':'Black'} to move`;}
function reply(){clearTimeout(botTimer);if(chess.turn()==='b'&&!chess.isGameOver())botTimer=setTimeout(()=>{const moves=chess.moves();chess.move(moves[Math.floor(Math.random()*moves.length)]);render();},600);}
board.game={getFEN:()=>chess.fen(),getHeaders:()=>({Event:mode==='bot'?'Play vs Bot':'Live Chess',White:'You',Black:'Practice',Date:'local'}),getOptions:()=>({flipped,enabled:true}),getPositionInfo:()=>({gameOver:chess.isGameOver(),check:chess.isCheck(),checkmate:chess.isCheckmate()}),getMode:()=>({name:'playing'}),getResult:()=>chess.isGameOver()?'1/2-1/2':'*',getPlayingAs:()=>1,getVariant:()=> 'standard',isAtEndOfLine:()=>true,getNodeIds:()=>chess.history().length,getLastMove:()=>chess.history({verbose:true}).at(-1),getHistorySANs:()=>chess.history(),getLegalMoves:()=>chess.moves({verbose:true}),getPGN:()=>chess.pgn(),move:m=>{chess.move(m);moveCount++;render();reply();}};
board.addEventListener('click',e=>{const target=e.target.closest('[data-square]');if(!target||chess.turn()!=='w')return;const sq=target.dataset.square;if(selected){try{board.game.move({from:selected,to:sq,promotion:'q'});selected=null;return;}catch{}}selected=chess.get(sq)?.color==='w'?sq:null;});
const page={document,location:{protocol:'https:',hostname:'www.chess.com',get pathname(){return mode==='bot'?'/play/computer':mode==='human'?'/game/live/123':'/puzzles';}},getComputedStyle:window.getComputedStyle.bind(window)};
const adapter=new ChessComAdapter(page);
// Development-only transport. The production userscript always uses Tampermonkey's GM request.
window.GM_xmlhttpRequest=opts=>{const controller=new AbortController();const name=new URL(opts.url).pathname.split('/').pop();fetch('/node_modules/stockfish/bin/'+name,{signal:controller.signal}).then(async r=>opts.onload?.({status:r.status,response:await r.arrayBuffer()})).catch(e=>e.name==='AbortError'?opts.onabort?.():opts.onerror?.(e));return{abort:()=>controller.abort()};};
window.GM_registerMenuCommand=()=>{};
if(!localStorage.getItem(STORAGE_KEY))localStorage.setItem(STORAGE_KEY,JSON.stringify({version:1,settings:{...DEFAULTS,x:650,y:105},active:'default',profiles:[{id:'default',name:'Default',settings:{...DEFAULTS,x:650,y:105}}]}));
render();const app=boot({adapter});
document.querySelector('#reset').onclick=()=>{clearTimeout(botTimer);chess.reset();selected=null;render();app.tick();};
document.querySelector('#flip').onclick=()=>{flipped=!flipped;render();app.tick();};
document.querySelector('#human').onclick=()=>{mode='human';clearTimeout(botTimer);render();app.tick();};
document.querySelector('#bot').onclick=()=>{mode='bot';render();app.tick();};
window.__skeet={app,chess,board,setMode:value=>{mode=value;render();app.tick();},setRoute:value=>{mode=value?'bot':'human';render();app.tick();},load:fen=>{clearTimeout(botTimer);chess.load(fen);render();app.tick();},get moveCount(){return moveCount;}};
