import {chromium,expect} from '@playwright/test';
import {build} from 'esbuild';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {ENABLED_DEFAULTS} from './fixtures/features.mjs';

const loader=await readFile('dist/ChessWare.loader.user.js','utf8');
const manifest=JSON.parse(await readFile('dist/release.json','utf8'));
const payload=await readFile('dist/ChessWare.protected.user.js');
let fixture=await readFile('demo/demo.js','utf8');
fixture=fixture.replace("import { boot } from '../src/app.js';",'').replace('render();const app=boot({adapter});','render();const app={tick(){},store:{patch(){}},stop(){}};');
const built=await build({stdin:{contents:fixture,resolveDir:process.cwd()+'/demo',sourcefile:'loader-fixture.js'},bundle:true,write:false,format:'iife',loader:{'.css':'empty'}});
const fixtureCode=built.outputFiles[0].text;
const html=(await readFile('demo/index.html','utf8')).replace('<script src="/demo/bundle.js"></script>','');
await mkdir('test-results',{recursive:true});
const browser=await chromium.launch({channel:'msedge',headless:true});
try {
  const page=await browser.newPage({viewport:{width:1440,height:900}}),errors=[],downloads=[],cache=new Map();
  page.on('pageerror',e=>errors.push(e.message));
  await page.route('**/*',route=>route.fulfill({contentType:'text/html',body:html}));
  await page.exposeFunction('__loaderChunk',async(url,offset)=>{
    const name=new URL(url).pathname.split('/').pop();let data;
    if(name==='release.json')data=Buffer.from(JSON.stringify(manifest));
    else if(name===manifest.url.split('/').pop())data=payload;
    else if(/^stockfish-19(?:-single)?\.(?:js|wasm)$/.test(name)){
      if(!cache.has(name))cache.set(name,await readFile('node_modules/stockfish/bin/'+name));data=cache.get(name);
    }else throw new Error('Unexpected URL '+url);
    if(!offset)downloads.push(name);
    return {size:data.length,chunk:data.subarray(offset,offset+1048576).toString('base64')};
  });
  const setup=async()=>{
    await page.goto('https://www.chess.com/play/computer');await page.evaluate(fixtureCode);
    await page.evaluate(()=>{
      window.__requests=[];window.__commands=[];window.GM_registerMenuCommand=(name,callback)=>window.__commands.push({name,callback});window.unsafeWindow=window;
      window.GM_xmlhttpRequest=opts=>{let aborted=false;
        window.__requests.push({url:opts.url,data:opts.data,headers:opts.headers});
        (async()=>{
          if(window.__failNetwork){opts.onerror();return;}
          while(window.__pause)await new Promise(resolve=>setTimeout(resolve,20));
          let data,offset=0;
          do {
            const {size,chunk}=await window.__loaderChunk(opts.url,offset);if(aborted)return;
            data||=new Uint8Array(size);const bytes=Uint8Array.from(atob(chunk),c=>c.charCodeAt(0));data.set(bytes,offset);offset+=bytes.length;
            opts.onprogress?.({loaded:offset,total:size});
          }while(offset<data.length);
          if(window.__corrupt&&opts.url.endsWith('.user.js'))data[data.length-1]^=1;
          opts.onload({status:200,response:data.buffer,finalUrl:opts.url});
        })().catch(()=>opts.onerror?.());
        return {abort:()=>{aborted=true;opts.onabort?.();}};
      };
    });
  };
  const load=()=>page.locator('#chessware-loader [data-action=load]');
  const log=()=>page.locator('#chessware-loader .log');
  const signIn=()=>page.getByRole('button',{name:'Login',exact:true}).click();
  await setup();await page.evaluate(()=>window.__pause=true);await page.evaluate(loader);
  const loginGeometry=await page.locator('#chessware-loader .loader').evaluate(n=>({width:n.getBoundingClientRect().width,height:n.getBoundingClientRect().height}));
  assert.deepEqual(loginGeometry,{width:300,height:210});
  assert.equal(await page.evaluate(()=>window.__requests.length),0,'no request before Login');
  await page.locator('#chessware-loader .loader').screenshot({path:'test-results/loader-login.png'});
  await page.getByLabel('Username',{exact:true}).fill('temporary-user-test-19');
  await page.getByLabel('Password',{exact:true}).fill('temporary-password-test-19');
  await page.locator('.login-exit').click();await expect(page.locator('#chessware-loader .loader')).toBeHidden();
  await page.keyboard.press('Insert');await expect(page.locator('#chessware-loader .loader')).toBeVisible();
  await expect(page.getByLabel('Password',{exact:true})).toHaveValue('');
  await page.getByLabel('Username',{exact:true}).fill('temporary-user-test-19');
  await page.getByLabel('Password',{exact:true}).fill('temporary-password-test-19');
  await signIn();
  await expect(load()).toBeDisabled();assert.equal(await page.locator('#chess-skeet-root').count(),0);
  await page.evaluate(()=>window.__pause=false);
  await expect(load()).toBeEnabled({timeout:20000});await expect(log()).toContainText('Verified');
  await expect(page.getByLabel('Password',{exact:true})).toHaveValue('');
  const saved=await page.evaluate(()=>JSON.stringify({requests:window.__requests,local:{...localStorage},session:{...sessionStorage}}));
  assert.ok(!saved.includes('temporary-password-test-19')&&!saved.includes('temporary-user-test-19'),'login values are never transmitted or persisted');
  const geometry=await page.locator('#chessware-loader .loader').evaluate(n=>{const r=n.getBoundingClientRect();return {width:r.width,height:r.height,font:getComputedStyle(n).fontFamily};});
  assert.deepEqual([geometry.width,geometry.height],[520,400]);assert.ok(geometry.font.includes('Verdana'));
  await page.locator('#chessware-loader .loader').screenshot({path:'test-results/loader-ready.png'});
  await page.locator('#chessware-loader [data-action=exit]').click();await expect(page.locator('#chessware-loader .loader')).toBeHidden();
  await page.keyboard.press('Insert');await expect(page.locator('#chessware-loader .loader')).toBeVisible();
  await load().click();await expect(log()).toContainText('Loaded · Insert');
  assert.equal(await page.locator('#chess-skeet-root').count(),1);
  assert.equal(await page.locator('#chess-skeet-root input[type=checkbox]:checked').count(),0);
  await expect(load()).toBeDisabled();
  await page.evaluate(()=>window.__commands.find(c=>c.name==='Show / hide ChessWare Loader').callback());
  await expect(page.locator('#chessware-loader .loader')).toBeHidden();
  await page.keyboard.press('Insert');await expect(page.locator('#chess-skeet-root .menu')).toBeVisible();
  await expect(page.locator('#chessware-loader .loader')).toBeHidden();
  // Exercise the real protected payload + full NNUE engine after the two-stage launch.
  await page.evaluate(s=>localStorage.setItem('chess-skeet:v1',JSON.stringify({version:1,defaultsRevision:1,settings:{...s,depth:8,moveTime:300,wmPing:false},active:'default',profiles:[]})),ENABLED_DEFAULTS);
  await setup();await page.evaluate(loader);await signIn();await expect(load()).toBeEnabled({timeout:20000});await load().click();
  await page.locator('#chessware-loader [data-action=exit]').click();
  await page.getByRole('tab',{name:'Rage',exact:true}).click();await page.getByLabel('Enable Rage',{exact:true}).check();
  await expect(page.locator('[data-page=Rage] [data-live=best]')).not.toHaveText('—',{timeout:60000});
  await page.locator('[data-page=Rage]').getByLabel('Auto Play',{exact:true}).check();await page.waitForFunction(()=>window.__skeet.moveCount>=1);
  await page.keyboard.press('F8');await expect(page.getByLabel('Enable Rage',{exact:true})).not.toBeChecked();
  assert.ok(downloads.some(name=>name.endsWith('.wasm')));
  // Network failure is actionable; retry downloads and verifies afresh.
  await setup();await page.evaluate(()=>window.__failNetwork=true);await page.evaluate(loader);await signIn();
  await expect(load()).toHaveText('Retry');await expect(log()).toContainText('Connection failed');
  assert.equal(await page.locator('#chess-skeet-root').count(),0);
  await page.evaluate(()=>window.__failNetwork=false);await load().click();await expect(load()).toHaveText('Load');await expect(load()).toBeEnabled({timeout:20000});
  // A single changed byte must never execute.
  await setup();await page.evaluate(()=>window.__corrupt=true);await page.evaluate(loader);await signIn();
  await expect(log()).toContainText('Integrity check failed',{timeout:20000});
  assert.equal(await page.locator('#chess-skeet-root').count(),0);
  assert.deepEqual(errors,[]);
  assert.ok(!loader.includes('sourceMappingURL='));assert.ok(!loader.includes('Connecting to GitHub'));
  await writeFile('test-results/loader.json',JSON.stringify({release:manifest,geometry,loginGeometry,arbitraryLogin:true,emptyLogin:true,noCredentialStorageOrTransmission:true,obfuscated:true,loadOnClick:true,initiallyOff:true,realProtectedPayload:true,realWASM:true,acceptedFixtureMove:true,networkRetry:true,hashMismatchBlocked:true,exitAndReopen:true,insertHandedToMod:true,errors},null,2)+'\n');
  console.log('PASS loader: verified download, click-only protected launch, empty defaults, real full WASM and legal move, stop, hash rejection, network retry, Exit/Insert and zero exceptions.');
}finally{await browser.close();}
