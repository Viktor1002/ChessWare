import {test} from 'node:test';
import assert from 'node:assert/strict';
import {GameSession} from '../src/game-session.js';
import {DEFAULTS,SettingsStore,STORAGE_KEY,SESSION_SWITCHES} from '../src/core.js';
const memory=()=>{const data=new Map();return {getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,v)};};
const paused=settings=>SESSION_SWITCHES.every(key=>settings[key]===false);
test('legacy persisted modes and presets cannot arm a new document or a config load',()=>{
 const storage=memory(),armed={...DEFAULTS,rageEnabled:true,autoPlay:true,legitEnabled:true,autoMove:true,depth:27};
 storage.setItem(STORAGE_KEY,JSON.stringify({version:1,settings:armed,active:'legacy',profiles:[{id:'legacy',name:'Legacy',settings:armed}]}));
 const store=new SettingsStore(storage);assert.ok(paused(store.settings));assert.equal(store.settings.depth,27);
 store.patch({rageEnabled:true,autoPlay:true});assert.equal(store.settings.autoPlay,true);assert.equal(store.settings.rageEnabled,true);
 assert.ok(paused(JSON.parse(storage.getItem(STORAGE_KEY)).settings));
 store.save('legacy');assert.equal(store.dirty,false);assert.ok(paused(store.active.settings));assert.ok(paused(new SettingsStore(storage).settings));
 store.load('legacy');assert.ok(paused(store.settings));assert.equal(store.settings.depth,27);
 store.patch({legitEnabled:true,autoMove:true});store.patch({rageEnabled:true});assert.equal(store.settings.autoMove,false);store.patch({autoPlay:true});store.patch({rageEnabled:false});assert.equal(store.settings.autoPlay,false);
});
test('game lease survives normal moves and flips but resets on identity, history rollback or lost eligibility',()=>{
 const lease=new GameSession(),p={board:{},game:{},sessionKey:'bot-1',player:'w',bot:true,history:[]};
 assert.equal(lease.update(p,true),true);assert.equal(lease.update({...p,history:['e4'],flipped:true},true),false);
 assert.equal(lease.update(p,true),true,'takeback resets');
 for(const changed of [{sessionKey:'human-2'},{game:{}},{board:{}},{player:'b'},{bot:false}]){lease.update(p,true);assert.equal(lease.update({...p,...changed},true),true);}
 lease.update(p,true);assert.equal(lease.update({},false),true);assert.equal(lease.update(p,true),true);
});
