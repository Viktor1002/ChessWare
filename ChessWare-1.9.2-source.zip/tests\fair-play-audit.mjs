// Current regression for the unintended-activation finding in FAIR_PLAY_AUDIT.md.
// The historical 1.6.1 reproducer and report are preserved in the audit archive.
// Only a local fixture is used; no online human game is created.
await import('./session.e2e.mjs');
