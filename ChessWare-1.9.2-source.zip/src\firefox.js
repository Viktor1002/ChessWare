// Only primitive move data crosses from the userscript sandbox into Chess.com's page world.
// Firefox USERSCRIPT_WORLD requires an explicit clone; Chromium can use the plain object.
export function pageMovePayload(page, move, animation) {
  const payload = { from: move.from, to: move.to, animate: !!animation, userGenerated: true };
  for (const key of ['color', 'flags', 'piece', 'san', 'promotion', 'captured']) {
    const value = move[key];
    if (typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value))) payload[key] = value;
  }
  if (typeof cloneInto === 'function') return cloneInto(payload, page, { cloneFunctions: false });
  if (typeof page.Object === 'function' && page.Object !== Object) {
    const target = new page.Object();
    for (const [key, value] of Object.entries(payload)) target[key] = value;
    return target;
  }
  return payload;
}

export const unwrapPage = value => value?.wrappedJSObject || value;

// Read returned records in their own realm, then parse plain data in the sandbox.
// This avoids keeping page-owned arrays/prototypes in UI code under Firefox Xray wrappers.
export function pageData(page, value, fallback = null) {
  if (value == null) return fallback;
  if (['string','number','boolean'].includes(typeof value)) return value;
  const json = typeof page.JSON?.stringify === 'function' ? page.JSON.stringify(value) : JSON.stringify(value);
  return typeof json === 'string' ? JSON.parse(json) : fallback;
}
