import {test} from 'node:test';
import assert from 'node:assert/strict';
import {hexToHsv,hsvToHex} from '../src/color-picker.js';
test('color picker preserves RGB primaries, greys and role colors through HSV',()=>{
 for(const color of ['#ff0000','#00ff00','#0000ff','#ffffff','#000000','#808080','#61bdec','#ad98ee','#fa8068'])assert.equal(hsvToHex(hexToHsv(color)),color);
 assert.equal(hsvToHex({h:120,s:1,v:1}),'#00ff00');assert.equal(hsvToHex({h:0,s:0,v:.5}),'#808080');
});
