import {pageData,unwrapPage} from './firefox.js';
const safely=(fn,fallback=null)=>{try{return fn()??fallback;}catch{return fallback;}};
const query=(root,selector)=>safely(()=>Array.from(root?.querySelectorAll?.(selector)||[]),[]);
const attr=(node,name)=>safely(()=>node?.getAttribute?.(name));
const BASE='https://www.chess.com';
export function accountName(value){
  if(typeof value!=='string')return null;
  const name=value.trim();
  return /^[a-z0-9_-]{1,40}$/i.test(name)&&!['null','undefined','none','true','false'].includes(name.toLowerCase())?name:null;
}
export function avatarUrl(value){
  if(typeof value!=='string'||!value.trim()||value.length>4096)return null;
  return safely(()=>{const url=new URL(value,BASE),host=url.hostname.toLowerCase();return url.protocol==='https:'&&(host==='chess.com'||host.endsWith('.chess.com')||host==='chesscomfiles.com'||host.endsWith('.chesscomfiles.com'))?url.href:null;});
}
function memberName(value){
  return safely(()=>{const url=new URL(value,BASE);if(!['www.chess.com','chess.com'].includes(url.hostname))return null;const match=url.pathname.match(/^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?member\/([^/]+)\/?$/i);return match?accountName(decodeURIComponent(match[1])):null;});
}
function record(user){
  const username=accountName(safely(()=>user?.username))||accountName(safely(()=>user?.userName));
  if(!username)return null;
  const avatar=[()=>user.avatar,()=>user.avatarUrl,()=>user.avatar_url,()=>user.avatar?.url,()=>user.avatar?.src,()=>user.imageUrl].map(fn=>avatarUrl(safely(fn))).find(Boolean)||null;
  return {username,avatar};
}
function imageFrom(node,page){
  for(const image of [node,...query(node,'img,[data-src],[class*="avatar"],[class*="profile-image"]')]){
    const direct=avatarUrl(attr(image,'data-src'))||avatarUrl(attr(image,'data-avatar-url'))||avatarUrl(safely(()=>image?.currentSrc))||avatarUrl(attr(image,'src'));
    if(direct)return direct;
    const background=safely(()=>page.getComputedStyle?.(image)?.backgroundImage,'');
    const match=background.match?.(/url\(["']?([^"')]+)["']?\)/);const value=match&&avatarUrl(match[1]);if(value)return value;
  }
  return null;
}
// Only navigation/current-user elements may establish identity. Member links elsewhere
// (opponents, spectators, friends and the profile currently being viewed) cannot.
const OWN_NAV='a[data-cy="nav-link-profile"],a[data-cy="profile-link"],a.nav-link-profile,a.nav-profile-link,#sb a[href*="/member/"],.nav-component a[href*="/member/"],.sidebar-navigation a[href*="/member/"],nav[aria-label="Main"] a[href*="/member/"],[data-current-user-username],[data-user-is-self="true"],[data-cy="nav-username"],.nav-profile-username,.nav-user-username';
function navigationProfiles(document,page){
  return query(document,OWN_NAV).flatMap(node=>{
    const username=memberName(attr(node,'href'))||accountName(attr(node,'data-current-user-username'))||accountName(attr(node,'data-username'))||
      (safely(()=>node.matches?.('[data-cy="nav-username"],.nav-profile-username,.nav-user-username'))?accountName(safely(()=>node.textContent)):null);
    return username?[{username,avatar:imageFrom(node,page)}]:[];
  });
}
function matchingAvatar(document,page,username){
  for(const node of query(document,'[data-username],a[href*="/member/"]')){
    const name=accountName(attr(node,'data-username'))||memberName(attr(node,'href'));
    if(name?.toLowerCase()!==username.toLowerCase())continue;
    const ownRow=safely(()=>node.closest?.('.player-component,.player-row,.user-tagline-component'));
    const avatar=imageFrom(node,page)||(ownRow&&imageFrom(ownRow,page));if(avatar)return avatar;
  }
  return null;
}
export function resolveAccountProfile(source){
  const page=safely(()=>unwrapPage(source),source),document=safely(()=>page.document);
  const navigation=navigationProfiles(document,page);
  const globals=[()=>page.context?.user,()=>page.context?.currentUser,()=>page.chesscom?.user,()=>page.chesscom?.currentUser,()=>page.ChessCom?.user,()=>page.__INITIAL_STATE__?.auth?.user,()=>page.__NUXT__?.state?.auth?.user];
  let own=globals.map(fn=>safely(()=>record(fn()))).find(Boolean),origin=own?'account':'navigation';
  if(!own)own=navigation[0];
  if(!own){
    for(const script of query(document,'script#__NEXT_DATA__,script[data-current-user]')){
      const data=safely(()=>JSON.parse(script.textContent));
      own=record(data?.props?.pageProps?.currentUser)||record(data?.props?.pageProps?.auth?.user)||record(data?.currentUser);
      if(own){origin='account';break;}
    }
  }
  if(!own)for(const element of query(document,'wc-chess-board,chess-board')){
    own=safely(()=>{
      if(element.getBoundingClientRect().width<=0)return null;
      const game=unwrapPage(element)?.game,side=game?.getPlayingAs?.(),headers=pageData(page,game?.getHeaders?.(),{});
      const key=[1,'w','white'].includes(side)?'White':[2,'b','black'].includes(side)?'Black':null;
      const value=key&&headers[key];const username=accountName(value)||accountName(value?.username);
      return username&&!/^(guest|you|anonymous)$/i.test(username)?{username,avatar:null}:null;
    });
    if(own){origin='own-player';break;}
  }
  if(!own)return {username:null,avatar:null,source:'unavailable'};
  const nav=navigation.find(p=>p.username.toLowerCase()===own.username.toLowerCase());
  return {...own,avatar:own.avatar||nav?.avatar||matchingAvatar(document,page,own.username),source:origin};
}
// Kept for callers that need the old string-only interface.
export const resolveAccountName=source=>resolveAccountProfile(source).username||'Guest';

export async function publicAccountAvatar(username,signal){
  const name=accountName(username);if(!name||signal.aborted)return null;
  // Local preview never performs public profile lookups.
  if(!/^(www\.)?chess\.com$/.test(globalThis.location?.hostname||''))return null;
  const url='https://api.chess.com/pub/player/'+encodeURIComponent(name.toLowerCase());
  const accept=data=>accountName(data?.username)?.toLowerCase()===name.toLowerCase()?avatarUrl(data.avatar):null;
  if(typeof GM_xmlhttpRequest==='function')return new Promise(resolve=>{
    let request,done=false;
    const finish=value=>{if(done)return;done=true;signal.removeEventListener('abort',abort);resolve(value);};
    const abort=()=>{request?.abort();finish(null);};
    signal.addEventListener('abort',abort,{once:true});
    try{request=GM_xmlhttpRequest({method:'GET',url,anonymous:true,timeout:6000,headers:{Accept:'application/json'},onload:r=>finish(r.status===200?safely(()=>accept(JSON.parse(r.responseText))):null),onerror:()=>finish(null),ontimeout:()=>finish(null),onabort:()=>finish(null)});}catch{finish(null);}
  });
  return safelyAsync(async()=>{const response=await fetch(url,{credentials:'omit',signal,headers:{Accept:'application/json'}});return response.ok?accept(await response.json()):null;});
}
async function safelyAsync(fn){try{return await fn();}catch{return null;}}
export class ProfileIdentity{
  constructor(page,lookup=publicAccountAvatar){this.page=page;this.lookup=lookup;this.cache=new Map();this.key=null;}
  read(){
    const profile=resolveAccountProfile(this.page),key=profile.username?.toLowerCase()||null;
    if(key!==this.key){this.controller?.abort();this.key=key;this.pending=null;}
    const cached=key&&this.cache.get(key);
    if(!profile.avatar&&cached&&cached.until>Date.now())profile.avatar=cached.avatar;
    if(key&&!profile.avatar&&(!cached||cached.until<Date.now())&&!this.pending&&!this.disposed){
      const controller=this.controller=new AbortController();this.pending=key;
      Promise.resolve().then(()=>this.lookup(profile.username,controller.signal)).then(value=>{
        if(controller.signal.aborted||this.disposed)return;const avatar=avatarUrl(value);
        this.cache.set(key,{avatar,until:Date.now()+(avatar?12*3600000:300000)});
      }).catch(()=>{if(!controller.signal.aborted)this.cache.set(key,{avatar:null,until:Date.now()+300000});}).finally(()=>{if(this.controller===controller)this.pending=null;});
    }
    return profile;
  }
  destroy(){this.disposed=true;this.controller?.abort();this.cache.clear();}
}
