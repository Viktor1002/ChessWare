NeverChess is an HTML/CSS port of the user-supplied `neverlose-last` ImGui example.

The source geometry and palette are taken from:
- `examples/example_win32_directx9/main.cpp` (690 × 500, 170 px sidebar)
- `examples/example_win32_directx9/gui.hpp` (palette)
- `examples/example_win32_directx9/gui.cpp` (tabs and group boxes)

Museo 500, Museo 900, the source Font Awesome data and the embedded avatar were extracted unchanged from the supplied `bytes.hpp` arrays by `scripts/import-neverchess.mjs`. Original font data and names remain intact. The supplied repository's MIT notice is included as `neverchess-imgui.txt`. The browser menu is connected to chessence's existing settings. The source C++/DirectX runtime and system wallpaper are not included.

Since 1.6.1 the sample avatar remains only a source reference asset. The UI uses the current Chess.com account avatar or generated initials.
