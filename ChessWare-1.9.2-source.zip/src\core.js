import { Chess, validateFen } from 'chess.js';
export { Chess };
export const VERSION = '1.9.2';
export const STORAGE_KEY = 'chess-skeet:v1';
export const DEFAULTS = Object.freeze({
  legitEnabled: false, suggestion: false, autoMove: false, delay: 1200,
  legitSkill: 4, legitDepth: 10, legitMultiPV: 3, legitMoveTime: 700, legitContinuous: false,
  legitEvaluation: false, legitBestLine: false, legitMate: false, legitThreats: false,
  rageEnabled: false, bestMove: false, autoPlay: false, continuous: false,
  depth: 20, multiPV: 3, moveTime: 1500, threads: 0, hash: 0,
  evaluation: false, bestLine: false, mate: false, threats: false,
  scale: 100, spacing: 22, width: 657, height: 555, dock: 'Free',
  menuStyle: 'chessence', oldWidth: 657, oldHeight: 555, oldSpacing: 22,
  newWidth: 690, newHeight: 500, newSpacing: 8,
  fatalWidth: 848, fatalHeight: 588, fatalSpacing: 16,
  watermark: false, menuKey: 'Insert', stopKey: 'F8',
  wmPing: false, wmTime: false,
  wmClock: '24-hour', wmSeconds: false, wmPosition: 'Top right', wmOffsetX: 15, wmOffsetY: 15, wmOpacity: 100,
  sound: false, detect: false,
  lastMove: false, selected: false, legal: false, captures: false,
  arrow: false, arrows: false, threatIndicators: false, check: false, mateIndicator: false,
  arrowColor: '#a4c85a', highlightColor: '#a4c85a', thickness: 7, opacity: 30, animation: false,
  chams: false, chamsOwn: false, chamsEnemy: false, chamsMove: false, chamsTarget: false, chamsSelected: false, chamsThreat: false,
  chamsOwnColor: '#a4c85a', chamsEnemyColor: '#a4c85a', chamsMoveColor: '#a4c85a', chamsTargetColor: '#a4c85a', chamsSelectedColor: '#a4c85a', chamsThreatColor: '#a4c85a',
  chamsOpacity: 55, chamsGlow: 3,
  chamsMaterial: 'Flat', chamsOwnMaterial: 'Inherit', chamsEnemyMaterial: 'Inherit', chamsMoveMaterial: 'Inherit', chamsTargetMaterial: 'Inherit', chamsSelectedMaterial: 'Inherit', chamsThreatMaterial: 'Inherit',
  chamsOutline: false, chamsOutlineWidth: 2, chamsPulse: false, arrowAlpha: 100,
  chamsOwnAlpha: 100, chamsEnemyAlpha: 100, chamsMoveAlpha: 100, chamsTargetAlpha: 100, chamsSelectedAlpha: 100, chamsThreatAlpha: 100,
  x: 70, y: 70, tab: 'Visuals'
});
export const RANGES = {
  ...Object.fromEntries(['Own','Enemy','Move','Target','Selected','Threat'].map(role=>['chams'+role+'Alpha',[0,100,1]])),
  delay: [100, 5000, 50], legitSkill: [0, 10, 1], legitDepth: [1, 16, 1],
  legitMultiPV: [1, 5, 1], legitMoveTime: [100, 2500, 100],
  depth: [1, 40, 1], multiPV: [1, 5, 1], moveTime: [100, 10000, 100],
  threads: [0, 16, 1], hash: [0, 512, 16], scale: [75, 150, 5],
  spacing: [8, 30, 1], width: [600, 1100, 1], height: [450, 850, 1],
  oldWidth: [600, 1100, 1], oldHeight: [450, 850, 1], oldSpacing: [8, 30, 1],
  newWidth: [600, 1100, 1], newHeight: [450, 850, 1], newSpacing: [8, 30, 1],
  fatalWidth: [600, 1100, 1], fatalHeight: [450, 850, 1], fatalSpacing: [8, 30, 1],
  wmOffsetX: [0, 300, 1], wmOffsetY: [0, 300, 1], wmOpacity: [20, 100, 1],
  thickness: [2, 16, 1], opacity: [5, 80, 1], x: [0, 10000, 1], y: [0, 10000, 1],
  chamsOpacity: [5, 100, 1], chamsGlow: [0, 12, 1], chamsOutlineWidth: [1, 6, 1], arrowAlpha: [0, 100, 1]
};
export const CHAMS_MATERIALS = ['Flat','Glow','Outline','Wireframe','Glass','Metallic','Neon','Scanline'];
export const CHOICES = {
  chamsMaterial: CHAMS_MATERIALS,
  ...Object.fromEntries(['Own','Enemy','Move','Target','Selected','Threat'].map(role=>['chams'+role+'Material',['Inherit',...CHAMS_MATERIALS]])),
  dock: ['Free', 'Left', 'Right'],
  menuStyle: ['chessence', 'NeverChess', 'Fatachessty'],
  wmClock: ['24-hour', '12-hour'], wmPosition: ['Top right', 'Top left', 'Bottom right', 'Bottom left'],
  menuKey: ['Insert', 'F2', 'F4'],
  stopKey: ['F8', 'F10', 'F12'], tab: ['Legit', 'Rage', 'Misc', 'Visuals', 'Configs']
};
export function sanitize(input = {}) {
  const result = { ...DEFAULTS };
  for (const key of Object.keys(DEFAULTS)) {
    let value = input?.[key];
    if (key === 'menuStyle' && value === 'Old — Skeet') value = 'chessence';
    if (key === 'menuStyle' && ['New — Chess Skeet','New — chessence'].includes(value)) value = 'NeverChess';
    if (typeof DEFAULTS[key] === 'boolean' && typeof value === 'boolean') result[key] = value;
    else if (RANGES[key] && typeof value === 'number' && Number.isFinite(value)) {
      const [min, max, step] = RANGES[key];
      result[key] = Math.max(min, Math.min(max, Math.round(value / step) * step));
    } else if (CHOICES[key]?.includes(value)) result[key] = value;
    else if (key.endsWith('Color') && /^#[0-9a-f]{6}$/i.test(value)) result[key] = value;
  }
  if(input.newWidth===720&&input.newHeight===570){
    result.newWidth=690;result.newHeight=500;
    if(result.menuStyle==='NeverChess'&&input.width===720&&input.height===570){result.width=690;result.height=500;}
  }
  if (result.rageEnabled) result.legitEnabled = false;
  return result;
}
export const SESSION_SWITCHES=['rageEnabled','legitEnabled','autoPlay','autoMove'];
export function pausedSettings(input){
  return {...sanitize(input),...Object.fromEntries(SESSION_SWITCHES.map(key=>[key,false]))};
}
export function emptySettings(input){
  return {...sanitize(input),...Object.fromEntries(Object.entries(DEFAULTS).filter(([,value])=>typeof value==='boolean').map(([key])=>[key,false]))};
}
export class SettingsStore {
  constructor(storage) {
    this.storage = storage; this.error = ''; this.listeners = new Set();
    const fallback = { version: 1, defaultsRevision: 1, menuRevision: 2, brand: 'chessence', settings: { ...DEFAULTS }, active: 'default', profiles: [{ id: 'default', name: 'Default', settings: { ...DEFAULTS } }] };
    try {
      const raw = storage.getItem(STORAGE_KEY);
      const data = raw ? JSON.parse(raw) : fallback;
      if (data.version !== 1 || !Array.isArray(data.profiles)) throw new Error('Unsupported settings');
      if(data.menuRevision!==2)for(const settings of [data.settings,...data.profiles.map(p=>p.settings)])if(settings){if(settings.newSpacing===12)settings.newSpacing=8;if(settings.menuStyle==='NeverChess'&&settings.spacing===12)settings.spacing=8;}
      this.data = { ...fallback, settings: pausedSettings(data.settings), profiles: data.profiles.slice(0, 50).filter(p => typeof p.id === 'string' && typeof p.name === 'string').map(p => ({ id: p.id.slice(0, 100), name: p.name.slice(0, 32), settings: pausedSettings(p.settings) })) };
      if (!this.data.profiles.length) this.data.profiles = fallback.profiles;
      this.data.active = this.data.profiles.some(p => p.id === data.active) ? data.active : this.data.profiles[0].id;
      if(data.defaultsRevision!==1){
        this.data.settings=emptySettings(this.data.settings);
        const baseline=this.data.profiles.find(p=>p.id==='default');if(baseline)baseline.settings=emptySettings(baseline.settings);
        this.persist();
      }
    } catch { this.data = fallback; this.error = 'Saved settings could not be read. Defaults restored.'; }
  }
  get settings() { return this.data.settings; }
  get active() { return this.data.profiles.find(p => p.id === this.data.active); }
  get dirty() { return JSON.stringify(pausedSettings(this.settings)) !== JSON.stringify(pausedSettings(this.active.settings)); }
  subscribe(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  persist() {
    try { this.storage.setItem(STORAGE_KEY, JSON.stringify({...this.data,settings:pausedSettings(this.settings),profiles:this.data.profiles.map(p=>({...p,settings:pausedSettings(p.settings)}))})); this.error = ''; }
    catch { this.error = 'Storage unavailable or full. Changes are only kept in this tab.'; }
    for (const fn of this.listeners) fn();
  }
  patch(values) {
    if(typeof values.arrowColor==='string'&&/^#[0-9a-f]{6}$/i.test(values.arrowColor)){
      values={...Object.fromEntries(['highlightColor',...['Own','Enemy','Move','Target','Selected','Threat'].map(role=>'chams'+role+'Color')].map(key=>[key,values.arrowColor])),...values};
    }
    if (values.rageEnabled) values = { ...values, legitEnabled: false };
    if (values.legitEnabled) values = { ...values, rageEnabled: false };
    this.data.settings = sanitize({ ...this.settings, ...values });
    if(!this.settings.rageEnabled)this.data.settings.autoPlay=false;
    if(!this.settings.legitEnabled)this.data.settings.autoMove=false;
    this.persist();
  }
  disarm(){
    if(!SESSION_SWITCHES.some(key=>this.settings[key]))return false;
    this.patch(Object.fromEntries(SESSION_SWITCHES.map(key=>[key,false])));return true;
  }
  setMenuStyle(value) {
    if (!CHOICES.menuStyle.includes(value) || value === this.settings.menuStyle) return;
    const prefixes={'chessence':'old',NeverChess:'new',Fatachessty:'fatal'};
    const from = prefixes[this.settings.menuStyle];
    const to = prefixes[value];
    const s = this.settings;
    this.patch({ menuStyle: value,
      [from+'Width']: s.width, [from+'Height']: s.height, [from+'Spacing']: s.spacing,
      width: s[to+'Width'], height: s[to+'Height'], spacing: s[to+'Spacing'] });
  }
  named(name, except) {
    name = String(name).trim();
    if (!name || name.length > 32) throw new Error('Use a name of 1–32 characters.');
    if (this.data.profiles.some(p => p.id !== except && p.name.toLowerCase() === name.toLowerCase())) throw new Error('That config name already exists.');
    return name;
  }
  create(name) {
    if (this.data.profiles.length >= 50) throw new Error('Maximum of 50 configs reached.');
    const profile = { id: crypto.randomUUID(), name: this.named(name), settings: pausedSettings(this.settings) };
    this.data.profiles.push(profile); this.data.active = profile.id; this.persist(); return profile.id;
  }
  save(id) { const p = this.profile(id); p.settings = pausedSettings(this.settings); this.data.active = id; this.persist(); }
  load(id) { const p = this.profile(id); this.data.settings = pausedSettings(p.settings); this.data.active = id; this.persist(); }
  rename(id, name) { this.profile(id).name = this.named(name, id); this.persist(); }
  remove(id) {
    this.profile(id);
    if (this.data.profiles.length === 1) throw new Error('Keep at least one config.');
    this.data.profiles = this.data.profiles.filter(p => p.id !== id);
    if (this.data.active === id) { this.data.active = this.data.profiles[0].id; this.data.settings = pausedSettings(this.active.settings); }
    this.persist();
  }
  profile(id) { const p = this.data.profiles.find(p => p.id === id); if (!p) throw new Error('Config no longer exists.'); return p; }
}
export function isGameRoute(location) {
  return location.protocol === 'https:' && /^(www\.)?chess\.com$/.test(location.hostname) && /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(?:play(?:\/|$)|game(?:\/|$)|live(?:\/|$)|daily(?:\/|$))/.test(location.pathname.toLowerCase());
}
export function guard(snapshot, settings) {
  if (!settings.detect) return 'Game detection is disabled';
  if (!snapshot.route) return 'Open a Chess.com game';
  if (snapshot.error) return snapshot.error;
  if (!snapshot.board || !snapshot.game) return 'Waiting for the chessboard';
  if (!snapshot.playing) return 'Start or resume a game';
  if (!['w', 'b'].includes(snapshot.player)) return 'Player colour is not available';
  if (!snapshot.fen || !validateFen(snapshot.fen).ok) return 'Full position is not available';
  if (snapshot.over) return 'Game finished';
  return '';
}
export function resources(nav = navigator, isolated = globalThis.crossOriginIsolated) {
  const cores = Math.max(1, Number(nav.hardwareConcurrency) || 2);
  const memory = Math.max(1, Number(nav.deviceMemory) || 4);
  const maxThreads = isolated && typeof SharedArrayBuffer !== 'undefined' ? Math.min(16, Math.max(1, cores - 1)) : 1;
  const maxHash = Math.min(512, Math.max(32, memory * 32));
  return { cores, memory, maxThreads, maxHash, threads: Math.min(4, maxThreads), hash: Math.min(128, maxHash) };
}
export function effective(settings, limits) {
  const result={ threads: Math.min(settings.threads || limits.threads, limits.maxThreads), hash: Math.min(settings.hash || limits.hash, limits.maxHash) };
  return settings.legitEnabled?{threads:1,hash:Math.min(64,result.hash)}:result;
}
export function searchOptions(settings,limits){
  const s=sanitize(settings),perf=effective(s,limits);
  return s.legitEnabled?
    {...perf,depth:s.legitDepth,multiPV:s.legitMultiPV,time:s.legitMoveTime,skill:s.legitSkill}:
    {...perf,depth:s.depth,multiPV:s.multiPV,time:s.moveTime,skill:20};
}
export const uciOf = move => move.from + move.to + (move.promotion || '');
export function legalMove(fen, uci) {
  if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(uci || '')) return null;
  try { return new Chess(fen).moves({ verbose: true }).find(m => uciOf(m) === uci) || null; } catch { return null; }
}
export function parseInfo(line) {
  if (!line.startsWith('info ') || !/\spv\s/.test(line)) return null;
  const read = name => Number(line.match(new RegExp(`(?:^| )${name} (-?\\d+)`))?.[1] || 0);
  const score = line.match(/score (cp|mate) (-?\d+)/);
  if (!score) return null;
  return { depth: read('depth'), index: read('multipv') || 1, kind: score[1], score: Number(score[2]), nodes: read('nodes'), nps: read('nps'), time: read('time'), bound: /\b(?:lowerbound|upperbound)\b/.test(line), pv: line.split(' pv ')[1].trim().split(/\s+/) };
}
export function scoreLabel(line, fen) {
  if (!line) return '—';
  const score = line.score * (fen.split(' ')[1] === 'w' ? 1 : -1);
  return line.kind === 'mate' ? `${score < 0 ? '−' : ''}M${Math.abs(score)}` : `${score >= 0 ? '+' : ''}${(score / 100).toFixed(2)}`;
}
export function sanLine(fen, pv, limit = 12) {
  const game = new Chess(fen); const result = [];
  for (const uci of pv.slice(0, limit)) {
    try { result.push(game.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] }).san); } catch { break; }
  }
  return result.join(' ');
}
export function attackedPieces(fen) {
  const game = new Chess(fen), side = game.turn(), enemy = side === 'w' ? 'b' : 'w';
  return game.board().flat().filter(p => p && p.color === side && p.type !== 'k' && game.isAttacked(p.square, enemy)).map(p => ({ square: p.square, piece: p.type, undefended: !game.isAttacked(p.square, side), attackers: game.attackers(p.square, enemy) }));
}
