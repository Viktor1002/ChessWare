import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ChessComAdapter } from '../src/adapter.js';
import { Chess,DEFAULTS,guard } from '../src/core.js';
function fixture(bot){
 const chess=new Chess();const board={id:bot?'board-play-computer':'board-single',getBoundingClientRect:()=>({width:500,height:500}),classList:{contains:()=>false}};
 const game={getHeaders:()=>({Event:bot?'Play vs Bot':'Live Chess',White:'Player',Black:'Opponent'}),getOptions:()=>({enabled:true,flipped:false}),getPositionInfo:()=>({gameOver:false}),getMode:()=>({name:'playing'}),getResult:()=>'*',getPlayingAs:()=>1,getVariant:()=> 'chess',isAtEndOfLine:()=>true,getHistorySANs:()=>chess.history(),getFEN:()=>chess.fen(),getLastMove:()=>chess.history({verbose:true}).at(-1),getNodeIds:()=>({move:chess.history().length,line:0}),getLegalMoves:()=>chess.moves({verbose:true}),move:m=>chess.move(m)};board.game=game;
 const page={JSON,Object,location:{protocol:'https:',hostname:'www.chess.com',pathname:bot?'/play/computer':'/game/live/123'},document:{querySelectorAll:selector=>selector==='wc-chess-board, chess-board'?[board]:[]},getComputedStyle:()=>({visibility:'visible'})};
 return {adapter:new ChessComAdapter(page),page,chess,game};
}
test('adapter discovers both a bot board and a multiplayer board with a different id',()=>{for(const bot of [true,false]){const {adapter}=fixture(bot);const p=adapter.read();assert.equal(p.bot,bot);assert.equal(guard(p,{...DEFAULTS,detect:true}),'');assert.equal(p.fen,new Chess().fen());}});
test('same guarded move sink submits a legal move on either opponent type',async()=>{for(const bot of [true,false]){const {adapter,chess}=fixture(bot);await adapter.move('e2e4',adapter.read(),{...DEFAULTS,detect:true},()=>true);assert.deepEqual(chess.history(),['e4']);}});
test('position or turn changes cancel a pending move for both game types',async()=>{const {adapter,chess}=fixture(false),before=adapter.read();chess.move('d4');await assert.rejects(()=>adapter.move('e2e4',before,{...DEFAULTS,detect:true},()=>true),/Position or game changed/);assert.deepEqual(chess.history(),['d4']);});

test('changing game URL rejects an old queued move even at the same FEN and history',async()=>{const {adapter,page,chess}=fixture(false),before=adapter.read();page.location.pathname='/game/live/456';assert.equal(adapter.read().fen,before.fen);assert.notEqual(adapter.read().sessionKey,before.sessionKey);await assert.rejects(()=>adapter.move('e2e4',before,{...DEFAULTS,detect:true},()=>true),/game changed/);assert.equal(chess.history().length,0);});
test('spectator boards never become the player turn',()=>{const {adapter,game}=fixture(false);game.getPlayingAs=()=>null;game.getMode=()=>({name:'observing'});assert.ok(guard(adapter.read(),{...DEFAULTS,detect:true}));});
