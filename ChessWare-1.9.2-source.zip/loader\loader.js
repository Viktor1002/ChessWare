import css from './loader.css';

const RELEASE_URL = 'https://raw.githubusercontent.com/Viktor1002/ChessWare/main/release.json';
const RELEASE_PREFIX = 'https://raw.githubusercontent.com/Viktor1002/ChessWare/main/dist/';
const MAX_BYTES = 8 * 1024 * 1024;
const SESSION_KEY = 'chessware:loader-session:v1';

export function startLoader() {
  if (document.querySelector('#chessware-loader')) return;
  let session={loggedIn:false,loaded:false,hidden:false};
  try {
    const saved=JSON.parse(sessionStorage.getItem(SESSION_KEY)||'null');
    if(saved?.version===1)session={loggedIn:saved.loggedIn===true||saved.loaded===true,loaded:saved.loaded===true,hidden:saved.hidden===true};
  }catch{}
  function remember(patch){
    session={...session,...patch};
    try{sessionStorage.setItem(SESSION_KEY,JSON.stringify({version:1,...session}));}catch{}
  }
  const host = document.createElement('div'); host.id = 'chessware-loader';
  const root = host.attachShadow({mode:'open'});
  root.innerHTML = `<style>${css}</style><section class="loader login-mode" role="dialog" aria-label="ChessWare Loader" aria-modal="false">
  <div class="drag" title="Drag to move"></div>
  <form class="login" autocomplete="off">
  <input class="username" type="text" placeholder="Username" aria-label="Username" autocomplete="off" spellcheck="false">
  <input class="password" type="password" placeholder="Password" aria-label="Password" autocomplete="off">
  <button class="login-button" type="submit">Login</button><button class="login-exit" type="button">Exit</button></form>
  <div class="main" hidden><div class="products"><div class="product"><div class="product-icon" aria-hidden="true"><svg viewBox="0 0 28 30" fill="currentColor"><path d="M15 1 9 6l-5 5 2 5 6-2-5 9h17l-4-7 1-6-5-5 1-4zm-5 9 2-1-1 3zM6 25h19v4H6z"/></svg></div><div><h1 class="product-name">ChessWare</h1><div class="release-label">Connecting…</div></div></div></div>
  <fieldset class="options"><legend>Options</legend><button data-action="load" disabled>Load</button><button data-action="exit">Exit</button></fieldset>
  <fieldset class="status"><legend>Status</legend><div class="log" role="log" aria-live="polite" aria-relevant="additions"></div></fieldset></div></section>`;
  document.documentElement.append(host);
  const dialog = root.querySelector('.loader'), button = root.querySelector('[data-action=load]');
  const log = root.querySelector('.log'), label = root.querySelector('.release-label');
  let state = 'idle', payload = null, disposed = false, progress = null, loggedIn = false;
  const requests = new Set();
  function line(text,kind='') {
    const node = document.createElement('div'); node.className = `line ${kind}`; node.textContent = text;
    log.append(node); log.scrollTop = log.scrollHeight; return node;
  }
  function request(url,maxBytes,report) {
    return new Promise((resolve,reject)=>{
      let handle,finished=false;
      const finish=(error,value)=>{if(finished)return;finished=true;requests.delete(handle);error?reject(error):resolve(value);};
      try {
        handle = GM_xmlhttpRequest({method:'GET',url,responseType:'arraybuffer',anonymous:true,timeout:60000,
          onprogress:event=>{
            if(event.loaded>maxBytes){finish(new Error('Download exceeds the size limit.'));handle?.abort();return;}
            report?.(event.loaded,event.total);
          },
          onload:response=>{
            if(response.status!==200)return finish(new Error(`HTTP ${response.status}`));
            // GM may follow redirects; never execute a response redirected outside this repository.
            if(response.finalUrl&&!response.finalUrl.startsWith('https://raw.githubusercontent.com/Viktor1002/ChessWare/'))return finish(new Error('Unexpected download destination.'));
            const bytes=new Uint8Array(response.response);
            if(!bytes.length||bytes.length>maxBytes)return finish(new Error('Invalid download size.'));
            finish(null,bytes);
          },onerror:()=>finish(new Error('Connection failed.')),
          ontimeout:()=>finish(new Error('Connection timed out.')),
          onabort:()=>finish(new Error('Download cancelled.'))});
        if(!finished)requests.add(handle);
      }catch(error){finish(error);}
    });
  }
  async function connect() {
    if(!loggedIn||disposed||state==='connecting'||state==='loaded')return;
    if(document.querySelector('#chess-skeet-root')) {state='loaded';remember({loggedIn:true,loaded:true});button.disabled=true;label.textContent='Loaded';line('Already loaded · Insert','success');return;}
    state='connecting';button.disabled=true;button.textContent='Load';payload=null;
    line('Connecting…');label.textContent='Connecting…';
    try {
      const manifest=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(await request(RELEASE_URL,16384)));
      if(manifest.schema!==1||!/^\d+\.\d+\.\d+$/.test(manifest.version)||!Number.isSafeInteger(manifest.bytes)||manifest.bytes<1||manifest.bytes>MAX_BYTES||!/^[a-f0-9]{64}$/.test(manifest.sha256)||typeof manifest.url!=='string'||!manifest.url.startsWith(RELEASE_PREFIX)||!/^ChessWare-[\d.]+\.protected\.user\.js$/.test(manifest.url.slice(RELEASE_PREFIX.length)))throw new Error('Invalid release manifest.');
      line('Connected');label.textContent=`Version ${manifest.version}`;
      progress=line('Loading…');
      const bytes=await request(manifest.url,manifest.bytes,(loaded,total)=>{progress.textContent=`Loading: ${Math.min(100,Math.floor(loaded/(total||manifest.bytes)*100))}%`;});
      if(bytes.length!==manifest.bytes)throw new Error('Incomplete script download.');
      const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),value=>value.toString(16).padStart(2,'0')).join('');
      if(hash!==manifest.sha256)throw new Error('Integrity check failed.');
      const code=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
      if(!code.startsWith('// ==UserScript==')||!code.includes('// @name         ChessWare'))throw new Error('Downloaded file is not a ChessWare userscript.');
      if(disposed)return;
      payload=code;state='ready';progress.textContent='Verified';line('Ready','success');button.disabled=false;
      if(session.loaded)load(true);
    }catch(error){
      if(disposed)return;
      state='error';label.textContent='Connection unavailable';line(error.message,'error');button.textContent='Retry';button.disabled=false;
      dialog.hidden=false;
    }
  }
  function load(restoring=false) {
    if(state==='error'){connect();return;}
    if(state!=='ready'||!payload)return;
    state='loading';button.disabled=true;
    try {
      // Execute in the userscript sandbox, keeping the Firefox page bridge and GM grants.
      // A page <script> injection would lose these permissions and fail under CSP.
      const run = new Function('window','document','location','navigator','localStorage','unsafeWindow','GM_xmlhttpRequest','GM_registerMenuCommand','cloneInto',payload);
      run(window,document,location,navigator,localStorage,
        typeof unsafeWindow==='undefined'?window:unsafeWindow,GM_xmlhttpRequest,
        typeof GM_registerMenuCommand==='function'?GM_registerMenuCommand:undefined,
        typeof cloneInto==='function'?cloneInto:undefined);
      if(!document.querySelector('#chess-skeet-root'))throw new Error('ChessWare did not start.');
      payload=null;state='loaded';label.textContent+=' · loaded';line('Loaded · Insert','success');
      remember({loggedIn:true,loaded:true});
      if(restoring)dialog.hidden=true;
    }catch(error){payload=null;state='error';dialog.hidden=false;button.textContent='Retry';button.disabled=false;line(`Load failed: ${error.message}`,'error');}
  }
  button.addEventListener('click',()=>load());
  root.querySelector('.login').addEventListener('submit',event=>{
    event.preventDefault();
    // Temporary local gate: values are never read, sent, logged or persisted.
    root.querySelector('.login').reset();
    if(loggedIn)return;
    loggedIn=true;remember({loggedIn:true,hidden:false});root.querySelector('.login').hidden=true;root.querySelector('.main').hidden=false;
    dialog.classList.remove('login-mode');connect();
  });
  const hide=()=>{dialog.hidden=true;remember({hidden:true});};
  root.querySelector('.login-exit').addEventListener('click',()=>{root.querySelector('.login').reset();hide();});
  root.querySelector('[data-action=exit]').addEventListener('click',hide);
  const reopen=()=>{dialog.hidden=!dialog.hidden;remember({hidden:dialog.hidden});if(!dialog.hidden&&state==='error')connect();};
  if(typeof GM_registerMenuCommand==='function')GM_registerMenuCommand('Show / hide ChessWare Loader',reopen);
  document.addEventListener('keydown',event=>{
    if(event.code!=='Insert'||event.repeat||document.querySelector('#chess-skeet-root')||/^(INPUT|TEXTAREA|SELECT)$/.test((root.activeElement||event.target)?.tagName))return;
    event.preventDefault();reopen();
  });
  const drag=root.querySelector('.drag');let origin=null;
  drag.addEventListener('pointerdown',event=>{
    if(event.button!==0)return;const rect=dialog.getBoundingClientRect();
    origin={x:event.clientX,y:event.clientY,left:rect.left,top:rect.top};drag.setPointerCapture(event.pointerId);event.preventDefault();
  });
  drag.addEventListener('pointermove',event=>{
    if(!origin)return;dialog.style.transform='none';dialog.style.left=`${Math.max(0,Math.min(innerWidth-80,origin.left+event.clientX-origin.x))}px`;dialog.style.top=`${Math.max(0,Math.min(innerHeight-24,origin.top+event.clientY-origin.y))}px`;
  });
  drag.addEventListener('pointerup',()=>{origin=null;});drag.addEventListener('pointercancel',()=>{origin=null;});
  window.addEventListener('pagehide',event=>{if(event.persisted)return;disposed=true;payload=null;for(const request of requests)request?.abort();requests.clear();});
  dialog.hidden=session.hidden||session.loaded;
  if(session.loggedIn){
    loggedIn=true;root.querySelector('.login').hidden=true;root.querySelector('.main').hidden=false;
    dialog.classList.remove('login-mode');connect();
  }
}
startLoader();
