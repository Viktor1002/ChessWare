# ChessWare 1.9.2 — verification, 11 November 2026

## Protected userscript, 1.9.2

42 unit tests passed. The actual dist/ChessWare.protected.user.js passed a dedicated browser test: initially empty switches, full verified local Stockfish WASM loading, a legal move accepted by the intercepted chess.com board fixture, F8 stop, all three skins and watermark names, config creation and persistence after reload. Only game state/asset transport are fixtures; all product code is the protected production artifact. No online opponent was contacted. Report: test-results/protected.json.

Native Firefox 160.0 / official Tampermonkey 5.5.0 passed --standalone-watermark --protected using the actual installed protected file. Initial settings were empty; the test then explicitly enabled controls. Fonts, original layout, profile, compact watermark, material/colour editing, About and refresh worked after the installation server was stopped. Report: test-results/firefox-protected.json. Its SHA-256 matches the final protected build report. Native engine download/search was not part of this focused run.

Protected size: 2,095,528 bytes versus 1,678,709 bytes for the readable build. The report dist/ChessWare.protection.json records 18 transformed source modules and exact options. The metadata stays readable, embedded assets/vendors stay intact, and there are no source maps. The transformation has no domain locks, debugger blocking, disabled console, paid VM/API or beautifier-triggered self-destruction. It is source obfuscation, not a proven Fair Play bypass or secret storage.

## Product name and compact watermark, 1.9.1

The built userscript metadata names ChessWare. Both legacy output aliases match the new dist/ChessWare.user.js byte-for-byte. The existing browser port regression and native Firefox 160.0 / Tampermonkey 5.5 test passed, including the whole watermark height ≤26px, 10px body text, 12px title, original menu geometry and one-file operation after stopping the installation server. Font, animation, materials and reload checks remained functional.

## One-file operation and matching watermark, 1.9.0

42 unit tests and the local empty-default/theme browser regression passed. Native Firefox 160.0 with official Tampermonkey 5.5.0 passed `--standalone-watermark`: after installing the userscript, the test stopped the local installation server and confirmed that its URL was unreachable. The installed userscript then rendered on actual Chess.com, loaded both embedded fonts, retained frame geometry and long profile text, edited material/color settings and survived refresh. No user account or online moves were used.

Watermark checks verified the Fatachessty text, Josefin font, weight 700, uppercase rendering, RGB text shadows, menu background rgb(25,21,52), active ft-glitch animation, and animation switching to none through the real toggle. The screenshot was visually inspected. Report: `test-results/firefox-fatachessty.json` (`installationServerStopped: true`). This focused run did not download/search Stockfish; engine loading retains the pinned remote URLs and checksum checks, with no local-machine paths or localhost runtime. Internet is still required for Chess.com and automatic engine loading.

## Compact NeverChess watermark, 1.8.5

Both watermark unit cases and the local browser theme-switching regression passed. NeverChess now displays NC; chessence and Fatachessty retain their names, and Menu Style still displays chessence. Reload and empty defaults remain intact.

## Theme names and watermark, 1.8.4

42 unit tests passed, including all three watermark brand names and legacy Old — Skeet migration with preserved dimensions. The local browser test selects NeverChess, chessence and Fatachessty through the actual dropdown, verifies the complete matching watermark label and absence of the old option, and verifies persistence after reload. The Fatachessty port regression also passed with all three renamed style transitions. Watermark remains disabled until explicitly enabled.

## Header text clipping, 1.8.3

The Fatachessty browser regression passed with `Guest4873515159` and `Default gyjp`. Both text rows have at least 18px of height and a 16px line height, with the full tested text fitting horizontally. The 40px account wrapper begins at y=5; the 28px avatar remains centred at y=25 in the unchanged 50px header. The cropped screenshot `test-results/fatachessty-account-spacing.png` was visually inspected: nickname, config label and descenders are complete. Existing frame/group geometry, interactions and three-skin restoration also passed.

Native Firefox 159.0.1 / Tampermonkey 5.5.0 also passed the focused Fatachessty test with a controlled own-profile navigation fixture for the same long nickname. Both original fonts, unchanged geometry, material/color controls and reload remained functional. Screenshot: `test-results/firefox-fatachessty.png`. No signed-in user account or online moves were used.

## Removed position utilities, 1.8.2

42 unit tests and the focused local browser regression passed. The Misc panel has no history/FEN/PGN displays, related checkboxes or copy actions, while Move Sound remains visible. Production no longer requests clipboard permission. Board state/history used internally by analysis and session validation remain unchanged.

## Empty baseline and shared visual color, 1.8.1

42 unit tests passed. New checks cover all boolean defaults being off, a one-time upgrade reset, preservation of named presets and later explicit choices, and Arrow Color propagating to all visual colors without enabling a function. The local browser regression checks zero checked boxes in all three skins and after reload, no engine download/chams/watermark, the removed folder shortcut with the main Configs tab intact, shared color changes through the real HEX picker and persisted chams/highlight values. Manual game detection remains usable. The Fatachessty UI regression and full local NNUE integration also passed with explicit opt-in fixtures. Earlier native Firefox evidence below is version-specific; a native rerun is not claimed for 1.8.1.

## Third source skin, Fatachessty, 1.8.0

39 unit tests passed, including independent settings/config persistence for all three skins. The dedicated Edge regression verifies the source 848×588 frame, 50px header, content rectangle (24,66,800,482), 256px groups at x=24/296/568, 442px tabbed groups and 478px untabbed groups. It checks source font loading, the complete fitting title, all nine displayed icon instances decoding, five main tabs and all section views, 12×12 checkboxes, 100×14 sliders, real outline/material/HEX editing, search navigation, quicksave, config creation, About, reload and restoration through all three styles. It also verifies hidden-menu persistence. Screenshots: `test-results/fatachessty-rage.png`, `test-results/fatachessty-chams.png`; report: `test-results/fatachessty.json`.

Native Firefox 159.0.1 with official Tampermonkey 5.5.0 passed `--fatachessty-only` in a fresh guest profile on Chess.com. The installed userscript rendered the exact frame/group rectangles, loaded both original embedded fonts, fitted the full title, switched sections, changed outline/material settings, opened the color editor and About, and restored the third skin after refresh. No online moves or user account were used. Screenshot/report: `test-results/firefox-fatachessty.png` and `.json`.

The existing NeverChess port regression passed with unchanged source rectangles, controls, all 15 views, color editing and skin restoration. The full local NNUE integration also passed, covering both modes, configs, accepted fixture moves, cancellation and overlays. Native engine downloads were not required for the focused UI test. Older version-specific checks below remain historical evidence.

## Manual activation and observed-game boundaries, 1.7.0

All 38 Node.js tests passed. New cases cover previously armed saved settings and presets opening paused, runtime switches being excluded from persistence and config dirty checks, config loading pausing both modes, mode-specific auto-move coupling, game/session identity changes at the same FEN, normal moves and board flips retaining activation, history rollback and lost eligibility revoking it.

The dedicated Edge session regression passed against a local fixture with real full Stockfish WASM. Startup with an old armed config produced zero engine asset requests and zero moves. Manual bot analysis worked; loading its saved config paused it without changing search parameters. Switching bot metadata to human metadata cancelled a queued Legit move and left all four switches off beyond the old delay. Manually enabled human analysis remained functional and normal advancing moves retained activation. New game, reload and leaving the game disarmed assistance. Result: `test-results/session-controls.json`. The current `tests/fair-play-audit.mjs` delegates to this regression; the historical 1.6.1 audit evidence is preserved separately.

The full Edge end-to-end regression also passed: real NNUE/MultiPV, config CRUD and reload, weaker Legit, accepted local bot and human-metadata moves after explicit activation, queue cancellation, legal/mate overlays and responsive menu. Human metadata is simulated; no live human opponent was used.

The two-skin regression passed at 1.7.0, including automatic own nickname, removed controls, hidden-menu persistence, dimensions, watermark options and the Rage-only stop key. Release previews were refreshed.

Native Firefox 159.0.1 + official Tampermonkey 5.5.0 passed `--session-only` in a fresh guest Chess.com bot game. Both modes initially stayed off; manually enabling Rage and then Legit with continuous analysis disabled survived real advancing moves (`a3 d5 a4 d4`). Refresh cleared both modes and auto-move switches. Result: `test-results/firefox-session-controls.json`. The full native engine test separately reached the real GM download path but could not complete because GitHub asset requests returned HTTP 504 on two attempts. Full NNUE analysis for this version was verified locally in Edge; a successful native full-engine rerun is not claimed.

These tests establish local behaviour and cancellation, not a measured reduction in Chess.com Fair Play detections or account closures. The cause of the reported closure remains unknown. Earlier version-specific visual/profile checks below remain historical evidence for unchanged features.

## Own profile and smaller heading, 1.6.1

The account browser regression reproduces an own-profile navigation link beside an opponent profile, with denied page context and no active game. It verifies own nickname/avatar selection, 22px heading, profile and portrait changes, account-data priority, failed-image initials, no fabricated Guest label and preserved hidden-menu navigation. Unit cases check allowed avatar origins, placeholder rejection, public-avatar caching, DOM priority and cancellation of old account lookups.

Native Firefox 159.0.1 + Tampermonkey 5.5.0 also passed `--identity-only`. In a fresh guest browser profile, a controlled own-navigation fixture points to a known public profile. With page context deliberately denied, the installed userscript resolves that fixture and loads the actual public API avatar via GM request; the image has nonzero natural dimensions. It then switches to NeverChess and verifies 22px heading. This verifies the userscript realm/API path; no private or signed-in user account was used. Screenshot: `test-results/firefox-account.png`.

## Source menu port and material variants, 1.6.0

The dedicated port test checks exact relative rectangles for Save (190,20,100,25), section bar (300,20,240,25), content (185,76,490,404), 30×17 switches and 92×4 slider tracks. All 15 section views expose the correct two panels, retaining the five main tabs. Real interactions cover portal dropdowns, global/per-role materials, outline/width, HSV pointer editing, HEX, independent role alpha, Save, restoration to Skeet, reload and hidden navigation.

The full-engine browser test resolves d4d5 and renders all eight materials on an image-backed capture target. Eight unique element screenshot hashes prove their visible differences. A separate native Firefox/Tampermonkey run selected every material through the actual UI on a real Chess.com board. Compared to chams off, changed board-pixel counts were Flat 35,586; Glow 44,649; Outline 19,335; Wireframe 40,645; Glass 28,263; Metallic 31,346; Neon 54,275; Scanline 29,767. All eight board-image hashes differed, including morphological outline and neon output. Screenshots are in `test-results/firefox-chams-<material>.png`.

## NeverChess and chams, 1.5.0

The dedicated Edge test runs the full Stockfish WASM on a position with a hanging queen. The engine returned d4d5, and the piece layer marked d4 as the move origin and d5 as the capture target. It checks the source 690×500 geometry, actual Museo font loading, grouped menu, saved config action, NC watermark, per-role switches/colors, image alpha-mask routing, fade-out/reversal, reduced motion, flipped coordinates, stale cleanup and teardown. The initial UI and capture-position screenshots were visually inspected. Unit cases also cover en passant, quiet moves, black identity independent of orientation and legacy skin migration.

A separate native Firefox/Tampermonkey `--visuals-only` run used the latest bundle on real Chess.com. Pixel comparison inside the board found **35,586 changed pixels** with chams on versus off, proving that the remote piece-image masks actually render. The test switches to NeverChess through the real UI and closes the menu for the board comparison. Screenshots: `test-results/firefox-chams-on.png` and `test-results/firefox-chams-off.png`.

## Menu navigation regression, 1.4.1

The rebuilt bundle passed a dedicated Edge browser regression: initial hidden state before the first paint checkpoint, explicit Insert/watermark toggles, open/closed persistence after reload and full same-origin navigation, closed SPA pushState/popstate/back navigation, fresh-tab isolation and config/style changes without opening the menu. Analysis was disabled in this focused test; it does not replace the full-engine checks below.

Firefox 159.0.1 with official Tampermonkey 5.5.0 also passed the navigation-only regression on real Chess.com. The script was installed through Tampermonkey in a fresh profile. Hidden state survived SPA navigation, full navigation and refresh; an independent tab started hidden, and clicking the watermark explicitly opened the menu. The user's browser profile and account were not used.

## Native Firefox + actual Tampermonkey, 1.5.0

Tested in Firefox **159.0.1** with official Tampermonkey **5.5.0**, installed from Mozilla Add-ons into a fresh geckodriver-created profile. The real userscript was installed through Tampermonkey's installer and ran in its normal `@sandbox JavaScript` environment.

The script opened a real guest Chess.com bot game, downloaded the complete pinned Stockfish WASM through `GM_xmlhttpRequest`, verified its checksum, started the Worker and displayed a legal suggestion. Rage Auto Play submitted **e4** and the opponent replied **e6**. The test then switched to Legit at Skill 4/20, submitted **c3**, and received **Nf6**. The Rage stop action stopped both modes. All 32 real board pieces used image-backed chams masks. Both skins (including NeverChess and its font), five tabs, automatic Guest identity and the absence of removed controls were checked. No `Permission denied to access object` appeared.

The test uses a separate profile and no user account. It does not change the user's existing Firefox profile. Screenshots: `test-results/firefox-chessence.png` and `test-results/firefox-chessence-new.png`.

## Earlier automated checks, through 1.6.1

- 35 Node.js tests cover both opponent types, discovery of different board IDs, active-game routes, legal moves, stale positions, config persistence, chess rules, UCI parsing, real strength/resource limits, reset to full strength, a weakened bestmove outside PV1, overlay transitions, chams roles/captures/orientation/material inheritance, HSV round trips, removed legacy settings and Firefox realm conversion. Identity checks cover account priority, own player colours, avatars/origin validation, asynchronous cache/cancellation, spectator handling and denied object access. Menu-state tests cover document recreation, independent tab storage, invalid values and denied storage access.
- Edge end-to-end test with the full Stockfish 19 WASM: search/MultiPV/evaluation/arrows, configs and reload, custom selects, hotkeys, bot auto move, cancellation on leaving a game, multiplayer metadata with a non-bot board ID and an accepted engine move, legal destinations, mate indicator and viewport containment.
- Skin tests cover the 657 × 555 old menu, five tabs, both styles, automatic nickname updates, absence of brand/nickname/manual-analysis/center/restore controls, Rage-only stop key and persistence. F6 no longer starts a search.
- Real-browser animation checks measured opacity between 0 and the target during both enter and exit, verified interrupted-exit reversal, final removal, reduced motion, disabled animation and teardown.
- A separate earlier cross-origin-isolated browser run verified the full multithread engine with four worker threads. Release SHA-256 checks matched both JS loaders and both full WASM binaries against `stockfish@19.0.1`.

## Scope of multiplayer verification

Multiplayer acceptance and move execution were checked against a local board with human-game metadata and the standard non-bot board ID. No live human opponent was used for this test. Production detection no longer depends on a bot route, bot header or bot board ID. It still requires an active standard chess game, full valid FEN and a known player colour; auto moves require that player's turn.

The screenshot-reported Firefox object-access issue is addressed by copying page-owned records through page-context JSON, passing only primitive move data through `cloneInto` and using native Worker event listeners. Future Chess.com internal API changes remain outside the test's scope.

The pinned engine's actual UCI output confirms Skill Level 0–20 and UCI_Elo 1320–3190. Real Skill 4 searches sometimes selected Nf3/e3/c4 despite PV1 remaining e4. The implementation therefore uses the final `bestmove`; random differences between strong and weak searches are not used as a pass/fail requirement.
