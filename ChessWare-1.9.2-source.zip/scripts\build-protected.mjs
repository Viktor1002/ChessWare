import {build} from 'esbuild';
import JavaScriptObfuscator from 'javascript-obfuscator';
import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {resolve,relative,sep} from 'node:path';
import {createHash} from 'node:crypto';

const hash=data=>createHash('sha256').update(data).digest('hex');
const normal=await readFile('dist/ChessWare.user.js','utf8');
const metadata=normal.match(/^\/\/ ==UserScript==[\s\S]*?\/\/ ==\/UserScript==/)[0];
const sourceRoot=resolve('src')+sep,modules=[];
const options={
 compact:true,target:'browser-no-eval',identifierNamesGenerator:'hexadecimal',
 controlFlowFlattening:true,controlFlowFlatteningThreshold:0.35,
 deadCodeInjection:true,deadCodeInjectionThreshold:0.10,
 stringArray:true,stringArrayThreshold:0.85,stringArrayEncoding:['rc4'],
 stringArrayRotate:true,stringArrayShuffle:true,stringArrayIndexShift:true,
 stringArrayCallsTransform:true,stringArrayCallsTransformThreshold:0.5,
 stringArrayWrappersCount:2,stringArrayWrappersChainedCalls:true,
 numbersToExpressions:true,simplify:true,
 renameGlobals:false,renameProperties:false,transformObjectKeys:false,
 ignoreImports:true,reservedNames:['^GM_','^unsafeWindow$','^cloneInto$'],
 selfDefending:false,debugProtection:false,disableConsoleOutput:false,sourceMap:false
};
await build({
 entryPoints:['src/index.js'],outfile:'dist/ChessWare.protected.user.js',bundle:true,format:'iife',
 target:['chrome110','firefox115'],minifyWhitespace:true,minifySyntax:true,
 loader:{'.css':'text','.png':'dataurl','.jpg':'dataurl','.ttf':'dataurl'},
 banner:{js:metadata},legalComments:'inline',
 plugins:[{name:'protect-owned-modules',setup(builder){
  builder.onLoad({filter:/\.js$/},async({path})=>{
   if(!path.startsWith(sourceRoot))return;
   const source=await readFile(path,'utf8'),name=relative(sourceRoot,path).replaceAll('\\','/');
   // Only project-owned JavaScript: vendor chess.js, CSS, fonts, images and NNUE stay intact.
   const code=JavaScriptObfuscator.obfuscate(source,{...options,seed:parseInt(hash(name).slice(0,7),16),identifiersPrefix:'cw'+hash(name).slice(0,6)}).getObfuscatedCode();
   modules.push(name);return {contents:code,loader:'js'};
  });
 }}]
});
const protectedCode=await readFile('dist/ChessWare.protected.user.js');
await writeFile('dist/ChessWare.protection.json',JSON.stringify({version:JSON.parse(await readFile('package.json','utf8')).version,tool:'javascript-obfuscator@5.10.0',options,modules:modules.sort(),normalBytes:Buffer.byteLength(normal),protectedBytes:protectedCode.length,normalSHA256:hash(normal),protectedSHA256:hash(protectedCode),limits:'Client-side source obfuscation, not encryption of the whole program or anti-cheat evasion.'},null,2)+'\n');
await copyFile('node_modules/javascript-obfuscator/LICENSE.BSD','licenses/javascript-obfuscator.txt');
console.log(`Protected ${modules.length} project modules; ${protectedCode.length} bytes. Metadata preserved; no source maps or online obfuscation service.`);
