import { ENGINE_ASSETS } from '../src/engine-assets.js';
import { createHash } from 'node:crypto';
for(const [flavor,assets]of Object.entries(ENGINE_ASSETS))for(const [type,asset]of Object.entries(assets)){
  const response=await fetch(asset.url);if(!response.ok)throw new Error(`${flavor} ${type}: HTTP ${response.status}`);
  const hash=createHash('sha256');let bytes=0;for await(const chunk of response.body){hash.update(chunk);bytes+=chunk.length;}
  const digest=hash.digest('hex');if(digest!==asset.sha256)throw new Error(`${flavor} ${type}: checksum mismatch ${digest}`);
  console.log(`Verified ${flavor} ${type}: ${bytes} bytes, SHA-256 matches npm package.`);
}
