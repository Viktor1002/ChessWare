import {ENABLED_DEFAULTS} from './fixtures/features.mjs';
import {chromium,expect} from '@playwright/test';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
const server=spawn(process.execPath,['scripts/serve.mjs','--port','4182'],{stdio:['ignore','pipe','inherit']});
await new Promise(resolve=>server.stdout.once('data',resolve));
const browser=await chromium.launch({channel:'msedge',headless:true});
try{
 const page=await browser.newPage({viewport:{width:1440,height:900}});await page.addInitScript(defaults=>{if(localStorage.getItem('chess-skeet:v1'))return;const settings={...defaults};localStorage.setItem('chess-skeet:v1',JSON.stringify({version:1,defaultsRevision:1,settings,active:'default',profiles:[{id:'default',name:'Default',settings}]}));},ENABLED_DEFAULTS);await page.goto('http://127.0.0.1:4182');await page.keyboard.press('Insert');
 await page.evaluate(()=>window.__skeet.app.store.patch({rageEnabled:true}));
 await page.waitForFunction(()=>window.__skeet.app.state.status==='Analysis complete',null,{timeout:60000});
 const patch=values=>page.evaluate(v=>window.__skeet.app.store.patch(v),values);
 const arrow=page.locator('.board-overlay [data-kind="arrow"]');
 await expect(arrow).toHaveCount(1);await page.waitForTimeout(260);
 await page.evaluate(()=>window.__firstArrow=document.querySelector('#chess-skeet-root').shadowRoot.querySelector('[data-kind="arrow"]'));
 await patch({arrow:false,arrows:false});await expect(arrow).toHaveAttribute('data-leaving','');
 await page.waitForTimeout(70);const fading=await arrow.evaluate(n=>Number(getComputedStyle(n).opacity));assert.ok(fading>0&&fading<.9,`Exit opacity ${fading}`);
 await patch({arrow:true});assert.equal(await arrow.evaluate(n=>n===window.__firstArrow),true);await expect(arrow).not.toHaveAttribute('data-leaving','');
 await page.waitForTimeout(250);await patch({arrow:false});await expect(arrow).toHaveCount(0);
 await patch({arrow:true});await page.waitForTimeout(75);const appearing=await arrow.evaluate(n=>Number(getComputedStyle(n).opacity));assert.ok(appearing>0&&appearing<.9,`Enter opacity ${appearing}`);
 await page.waitForTimeout(240);await page.screenshot({path:'test-results/smooth-visuals.png'});
 await page.emulateMedia({reducedMotion:'reduce'});await patch({arrow:false});await expect(arrow).toHaveCount(0);
 await patch({arrow:true});await expect(arrow).toHaveCount(1);assert.equal(await arrow.evaluate(n=>getComputedStyle(n).transitionDuration),'0s');
 await page.emulateMedia({reducedMotion:'no-preference'});await patch({animation:false,arrow:false});await expect(arrow).toHaveCount(0);
 await page.evaluate(()=>window.__skeet.app.destroy());await expect(page.locator('#chess-skeet-root')).toHaveCount(0);
 console.log('PASS real CSS enter/exit opacity, interrupted exit, reduced motion, animation off and cleanup.');
}finally{await browser.close();server.kill();}
