import { parseInfo } from './core.js';
import { ENGINE_ASSETS } from './engine-assets.js';

function request(url, signal, progress) {
  return new Promise((resolve, reject) => {
    if (signal.aborted) return reject(new DOMException('Cancelled', 'AbortError'));
    let req;
    const cancel = () => { req?.abort(); reject(new DOMException('Cancelled', 'AbortError')); };
    signal.addEventListener('abort', cancel, { once: true });
    const done = fn => value => { signal.removeEventListener('abort', cancel); fn(value); };
    req = GM_xmlhttpRequest({ method: 'GET', url, responseType: 'arraybuffer', timeout: 180000,
      onload: done(r => r.status === 200 ? resolve(r.response) : reject(new Error(`Engine download failed (HTTP ${r.status}).`))),
      onprogress: e => progress?.(e.loaded, e.total),
      onerror: done(() => reject(new Error('Engine download failed. Check your connection and Tampermonkey permissions.'))),
      ontimeout: done(() => reject(new Error('Engine download timed out. Try again.'))),
      onabort: done(() => reject(new DOMException('Cancelled', 'AbortError')))
    });
  });
}
async function verified(asset, signal, progress) {
  const data = await request(asset.url, signal, progress);
  const digest = [...new Uint8Array(await crypto.subtle.digest('SHA-256', data))].map(b => b.toString(16).padStart(2, '0')).join('');
  if (digest !== asset.sha256) throw new Error('Engine checksum mismatch. Download refused.');
  return data;
}
export class StockfishEngine {
  constructor(status = () => {}) { this.status = status; this.waiters = new Set(); this.urls = []; this.epoch = 0; this.cache = new Map(); }
  async init(threads) {
    const flavor = threads > 1 ? 'full' : 'single';
    if (this.worker && this.flavor === flavor && this.ready) return;
    if (this.loading && this.flavor === flavor) return this.loading;
    this.dispose(); this.flavor = flavor;
    const epoch = this.epoch; const abort = this.abort = new AbortController();
    const pending = this.loading = (async () => {
      this.status('Downloading Stockfish 19…');
      const assets = ENGINE_ASSETS[flavor];
      const [js, wasm] = this.cache.get(flavor) || await Promise.all([
        verified(assets.js, abort.signal),
        verified(assets.wasm, abort.signal, loaded => this.status(`Downloading engine · ${(loaded / 1048576).toFixed(0)} / ${(assets.wasm.size / 1048576).toFixed(0)} MB`))
      ]);
      if (epoch !== this.epoch) throw new DOMException('Cancelled', 'AbortError');
      this.cache.set(flavor, [js, wasm]);
      const wasmURL = URL.createObjectURL(new Blob([wasm], { type: 'application/wasm' }));
      const scriptURL = URL.createObjectURL(new Blob([js], { type: 'text/javascript' }));
      this.urls.push(wasmURL, scriptURL);
      this.status('Starting Stockfish 19 NNUE…');
      this.worker = new Worker(`${scriptURL}#${encodeURIComponent(wasmURL)}`);
      this.worker.addEventListener('message',e => this.receive(String(e.data)));
      this.worker.addEventListener('error',e => { this.fail(new Error(e.message || 'Engine worker failed.')); this.dispose(); });
      const uci = this.waitFor(line => line === 'uciok', 60000);
      this.send('uci'); await uci;
      if (!/^Stockfish 19(?:\b|\.)/.test(this.name || '')) throw new Error(`Expected Stockfish 19; received ${this.name || 'unknown engine'}.`);
      this.send('setoption name UCI_Chess960 value false');
      await this.sync(); this.ready = true;
      this.status('Stockfish 19 NNUE · ready');
    })();
    try { return await pending; }
    catch (error) { if (epoch === this.epoch) this.dispose(); throw error; }
    finally { if (this.loading === pending) this.loading = null; }
  }
  send(command) { if (!this.worker) throw new Error('Engine is not ready.'); this.worker.postMessage(command); }
  waitFor(predicate, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const waiter = { predicate, resolve, reject, timer: null };
      waiter.timer = setTimeout(() => { this.waiters.delete(waiter); reject(new Error('Engine response timed out.')); }, timeout);
      this.waiters.add(waiter);
    });
  }
  async sync() { const pending = this.waitFor(l => l === 'readyok'); this.send('isready'); await pending; }
  receive(line) {
    if (line.startsWith('id name ')) this.name = line.slice(8);
    if (/CRITICAL ERROR|Failed to allocate|ERROR:/.test(line)) { this.fail(new Error(line)); this.dispose(); return; }
    for (const w of [...this.waiters]) if (w.predicate(line)) { clearTimeout(w.timer); this.waiters.delete(w); w.resolve(line); }
    const info = parseInfo(line);
    if (info && this.searching) { this.lines.set(info.index, info); this.onInfo?.([...this.lines.values()].sort((a, b) => a.index - b.index)); }
  }
  async search(fen, options, onInfo) {
    if (this.searching) throw new Error('An engine search is already running.');
    await this.init(options.threads);
    this.send(`setoption name Threads value ${options.threads}`);
    this.send(`setoption name Hash value ${options.hash}`);
    this.send(`setoption name MultiPV value ${options.multiPV}`);
    this.send('setoption name UCI_LimitStrength value false');
    this.send(`setoption name Skill Level value ${options.skill ?? 20}`);
    await this.sync();
    this.lines = new Map(); this.onInfo = onInfo; this.searching = true;
    const pending = this.waitFor(l => l.startsWith('bestmove '), options.time + 15000);
    try {
      this.send(`position fen ${fen}`);
      this.send(`go depth ${options.depth} movetime ${options.time}`);
      const result = await pending;
      return { move: result.split(' ')[1], lines: [...this.lines.values()].sort((a, b) => a.index - b.index) };
    } catch (error) { this.dispose(); throw error; }
    finally { this.searching = false; this.onInfo = null; }
  }
  fail(error) { for (const w of this.waiters) { clearTimeout(w.timer); w.reject(error); } this.waiters.clear(); }
  cancel() { if(this.searching && this.worker) this.send('stop'); }
  dispose() {
    this.epoch++; this.abort?.abort(); this.worker?.terminate(); this.worker = null;
    this.ready = false; this.searching = false; this.loading = null;
    this.fail(new DOMException('Cancelled', 'AbortError'));
    this.urls.forEach(url => URL.revokeObjectURL(url)); this.urls = [];
  }
}
