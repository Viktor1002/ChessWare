// Reads assets as data only; none of the supplied C++/DirectX code is executed.
import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
const root=resolve(process.argv[2]||'neverchess/neverlose-last/neverlose-last');
const input=await readFile(join(root,'examples/example_win32_directx9/bytes.hpp'),'utf8');
await mkdir('src/assets/neverchess',{recursive:true});
for(const [name,weight]of [['museo500_binary',500],['museo900_binary',900]]){
 const match=input.match(new RegExp(name+'\\s*\\[\\s*\\]\\s*=\\s*\\{([\\s\\S]*?)\\};'));
 if(!match)throw new Error('Missing font '+name);
 const data=Buffer.from([...match[1].matchAll(/0x([0-9a-f]{2})/gi)].map(m=>parseInt(m[1],16)));
 if(data.readUInt32BE(0)!==0x10000)throw new Error('Invalid TrueType header');
 await writeFile(`src/assets/neverchess/museo-${weight}.ttf`,data);
 console.log(`Imported Museo ${weight}: ${data.length} bytes`);
}
await copyFile(join(root,'LICENSE.txt'),'licenses/neverchess-imgui.txt');
const icons=input.match(/font_awesome_binary\s*\[\s*\]\s*=\s*\{([\s\S]*?)\};/);
if(!icons)throw new Error('Missing source icon font');
await writeFile('src/assets/neverchess/icons.ttf',Buffer.from([...icons[1].matchAll(/0x([0-9a-f]{2})/gi)].map(m=>parseInt(m[1],16))));
const avatar=input.match(/esliboganet\s*\[\s*\]\s*=\s*\{([\s\S]*?)\};/);
if(avatar)await writeFile('src/assets/neverchess/source-avatar.jpg',Buffer.from([...avatar[1].matchAll(/0x([0-9a-f]{2})/gi)].map(m=>parseInt(m[1],16))));
