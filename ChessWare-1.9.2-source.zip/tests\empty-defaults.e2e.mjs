import {chromium,expect} from '@playwright/test';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
const server=spawn(process.execPath,['scripts/serve.mjs','--port','4191'],{stdio:['ignore','pipe','inherit']});let browser;
try{
 await new Promise(resolve=>server.stdout.once('data',resolve));browser=await chromium.launch({channel:'msedge',headless:true});const page=await browser.newPage({viewport:{width:1440,height:900}}),requests=[];page.on('request',r=>{if(r.url().includes('/stockfish/bin/'))requests.push(r.url());});
 await page.goto('http://127.0.0.1:4191');await page.waitForFunction(()=>window.__skeet?.app);await page.keyboard.press('Insert');
 const off=async()=>{assert.equal(await page.locator('input[type=checkbox]:checked').count(),0);assert.equal(await page.evaluate(()=>window.__skeet.app.state.best),null);await expect(page.locator('.watermark')).toBeHidden();await expect(page.locator('.cs-cham')).toHaveCount(0);};await off();
 for(const style of ['Fatachessty','NeverChess','chessence','Fatachessty']){await page.evaluate(value=>window.__skeet.app.store.setMenuStyle(value),style);await off();}
 await page.evaluate(()=>window.__skeet.app.store.patch({watermark:true,tab:'Misc'}));
 for(const style of ['NeverChess','chessence','Fatachessty']){
  await page.locator('[data-select=menuStyle] .select-toggle').click();await expect(page.getByRole('option',{name:'chessence',exact:true})).toBeVisible();await expect(page.locator('[data-value="Old — Skeet"]')).toHaveCount(0);
  await page.getByRole('option',{name:style,exact:true}).click();await expect(page.locator('.watermark .wm-name')).toHaveText(style==='NeverChess'?'NC':style);
 }
 await page.reload();await page.waitForFunction(()=>window.__skeet?.app);await expect(page.locator('.watermark .wm-name')).toHaveText('Fatachessty');await page.evaluate(()=>window.__skeet.app.store.patch({watermark:false}));await off();
 await expect(page.locator('.ft-tool[aria-label=Configs]')).toHaveCount(0);await expect(page.getByRole('tab',{name:'Configs',exact:true})).toBeVisible();
 await page.getByRole('tab',{name:'Misc',exact:true}).click();
 await expect(page.locator('[data-live=history],[data-live=position],[data-key=history],[data-key=position],[data-action=copy-fen],[data-action=copy-pgn]')).toHaveCount(0);
 await expect(page.getByLabel('Move Sound',{exact:true})).toBeVisible();
 await page.getByRole('tab',{name:'Visuals',exact:true}).click();await page.locator('[data-page=Visuals] [data-ft-section="2"]').click();await page.getByRole('button',{name:'Choose Arrow Color',exact:true}).click();await page.getByLabel('Hex color',{exact:true}).fill('#12abef');await page.getByLabel('Hex color',{exact:true}).press('Tab');await page.getByRole('button',{name:'Close color picker',exact:true}).click();
 assert.ok(await page.evaluate(()=>{const s=window.__skeet.app.store.settings;return ['highlightColor','chamsOwnColor','chamsEnemyColor','chamsMoveColor','chamsTargetColor','chamsSelectedColor','chamsThreatColor'].every(k=>s[k]==='#12abef');}));await off();
 await page.reload();await page.waitForFunction(()=>window.__skeet?.app);await off();assert.equal(requests.length,0);assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsTargetColor),'#12abef');
 await page.getByRole('tab',{name:'Visuals',exact:true}).click();await page.locator('[data-page=Visuals] [data-ft-section="1"]').click();await page.locator('.menu').screenshot({path:'test-results/fatachessty-empty.png'});
 await page.getByRole('tab',{name:'Misc',exact:true}).click();await page.getByLabel('Auto-detect Game Mode',{exact:true}).check();await page.waitForTimeout(300);assert.equal(await page.getByLabel('Enable Rage',{exact:true}).isDisabled(),false);
 console.log('PASS all switches off on fresh start/reload and in all skins; removed folder shortcut; master color from real picker updates every visual without enabling functions; manual detection remains usable; zero engine downloads.');
}finally{await browser?.close();server.kill();}
