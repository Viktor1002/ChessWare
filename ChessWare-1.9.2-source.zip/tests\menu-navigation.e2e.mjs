import {chromium,expect} from '@playwright/test';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import assert from 'node:assert/strict';
import {DEFAULTS,STORAGE_KEY} from '../src/core.js';

const origin='http://127.0.0.1:4184';
const visibilityKey='chessence:menu-visible';
const settings={...DEFAULTS,rageEnabled:false,legitEnabled:false,autoPlay:false,autoMove:false,wmPing:false};
const seed={version:1,brand:'chessence',settings,active:'default',profiles:[{id:'default',name:'Default',settings}]};
const server=spawn(process.execPath,['scripts/serve.mjs','--port','4184'],{stdio:['ignore','pipe','inherit']});
let browser;
try{
  await Promise.race([
    once(server.stdout,'data'),
    once(server,'error').then(([error])=>{throw error;}),
    once(server,'exit').then(([code])=>{throw new Error(`Preview server exited before startup (${code}).`);})
  ]);
  browser=await chromium.launch({channel:'msedge',headless:true});
  const context=await browser.newContext({viewport:{width:1440,height:900}});
  await context.addInitScript(({key,data})=>{
    if(!localStorage.getItem(key))localStorage.setItem(key,JSON.stringify(data));
    // Observe the first connected menu before a browser paint or test interaction.
    window.__menuBoot=null;
    const observer=new MutationObserver(()=>{
      const menu=document.querySelector('#chess-skeet-root')?.shadowRoot?.querySelector('.menu');
      if(!menu)return;
      window.__menuBoot={hidden:menu.hidden,display:getComputedStyle(menu).display};
      observer.disconnect();
    });
    observer.observe(document,{childList:true,subtree:true});
  },{key:STORAGE_KEY,data:seed});
  const page=await context.newPage();
  const errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  const ready=async target=>{
    await target.waitForFunction(()=>window.__skeet?.app?.ui&&window.__menuBoot);
    assert.equal(await target.evaluate(()=>window.__skeet.app.store.settings.rageEnabled),false);
  };
  const expectClosed=async target=>{
    await expect(target.locator('.menu')).toBeHidden();
    assert.equal(await target.evaluate(()=>window.__skeet.app.ui.visible),false);
  };
  const expectOpen=async target=>{
    await expect(target.locator('.menu')).toBeVisible();
    assert.equal(await target.evaluate(()=>window.__skeet.app.ui.visible),true);
  };
  const stored=target=>target.evaluate(key=>sessionStorage.getItem(key),visibilityKey);
  const expectClosedBoot=async target=>{
    await ready(target);
    await expectClosed(target);
    assert.deepEqual(await target.evaluate(()=>window.__menuBoot),{hidden:true,display:'none'});
  };

  await page.goto(`${origin}/?menu=initial`);
  await expectClosedBoot(page);

  await page.keyboard.press('Insert');
  await expectOpen(page);
  assert.equal(await stored(page),'open');
  // Saving a profile with the menu open must not make visibility a config value.
  const profile=await page.evaluate(()=>window.__skeet.app.store.create('Navigation regression'));
  await page.reload();
  await ready(page);
  await expectOpen(page);
  await page.goto(`${origin}/demo/index.html?menu=open-navigation`);
  await ready(page);
  await expectOpen(page);

  // A new tab shares local settings, but has no inherited session visibility.
  const other=await context.newPage();
  await other.goto(`${origin}/demo/index.html?menu=fresh-tab`);
  await expectClosedBoot(other);
  await expectOpen(page);
  await other.close();

  await page.keyboard.press('Insert');
  await expectClosed(page);
  assert.equal(await stored(page),'closed');
  await page.evaluate(()=>{
    history.pushState({menuTest:true},'','/demo/index.html?menu=spa');
    dispatchEvent(new PopStateEvent('popstate',{state:history.state}));
  });
  await page.waitForTimeout(350); // Include the application's 250 ms board poll.
  await expectClosed(page);
  await page.goBack();
  await page.waitForTimeout(350);
  await expectClosed(page);
  await page.goto(`${origin}/?menu=closed-navigation`);
  await expectClosedBoot(page);
  assert.equal(await stored(page),'closed');
  await page.reload();
  await expectClosedBoot(page);

  await page.evaluate(id=>{
    const store=window.__skeet.app.store;
    store.patch({tab:'Misc',scale:105});
    store.setMenuStyle('NeverChess');
    store.load(id);
  },profile);
  await page.waitForTimeout(350);
  await expectClosed(page);
  assert.equal(await stored(page),'closed');
  assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.scale),100);
  await page.locator('.watermark').click();
  await expectOpen(page);
  assert.equal(await stored(page),'open');
  await page.keyboard.press('Insert');
  await expectClosed(page);
  assert.equal(await stored(page),'closed');
  assert.deepEqual(errors,[]);
  console.log('PASS menu defaults closed without an initialization flash; Insert and watermark toggle explicitly; open/closed survives reload and same-origin navigation; SPA navigation and config changes stay closed; fresh tabs are isolated.');
}finally{
  await browser?.close();
  server.kill();
}
