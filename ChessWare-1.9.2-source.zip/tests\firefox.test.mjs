import { test } from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { pageMovePayload, unwrapPage, pageData } from '../src/firefox.js';
import { SettingsStore } from '../src/core.js';

test('menu styles keep separate sizes and survive config reload',()=>{
  const data=new Map();const storage={getItem:key=>data.get(key)||null,setItem:(key,value)=>data.set(key,value)};
  const store=new SettingsStore(storage);
  assert.equal(store.settings.menuStyle,'chessence');
  store.patch({width:680,height:580});store.setMenuStyle('NeverChess');
  assert.equal(store.settings.width,690);assert.equal(store.settings.height,500);
  store.patch({width:800,spacing:15});store.setMenuStyle('chessence');
  assert.equal(store.settings.width,680);assert.equal(store.settings.height,580);
  store.setMenuStyle('NeverChess');assert.equal(store.settings.width,800);assert.equal(store.settings.spacing,15);
  store.create('New layout');
  const restored=new SettingsStore(storage);assert.equal(restored.settings.menuStyle,'NeverChess');assert.equal(restored.settings.width,800);
});
test('page arrays are copied to sandbox-owned plain data before UI use',()=>{const page=vm.runInNewContext('({JSON,values:[{from:"e2",to:"e4"}]})');const copied=pageData(page,page.values);assert.equal(Object.getPrototypeOf(copied),Array.prototype);assert.equal(Object.getPrototypeOf(copied[0]),Object.prototype);assert.deepEqual(copied,[{from:'e2',to:'e4'}]);});
test('move payload uses the page realm and includes only supported primitive data',()=>{
  const page=vm.runInNewContext('({Object})');
  const move=pageMovePayload(page,{from:'a7',to:'a8',promotion:'n',flags:8,color:1,callback:()=>{},piece:'p'},true);
  assert.equal(Object.getPrototypeOf(move),page.Object.prototype);
  assert.equal(move.promotion,'n');assert.equal(move.userGenerated,true);assert.equal(move.animate,true);
  assert.equal('callback' in move,false);
});
test('Firefox path exports move data through cloneInto without exporting functions',()=>{
  const page={};let call;
  globalThis.cloneInto=(value,target,options)=>{call={value,target,options};return {cloned:true,...value};};
  try{
    const result=pageMovePayload(page,{from:'e2',to:'e4',flags:2},false);
    assert.equal(result.cloned,true);assert.equal(call.target,page);assert.equal(call.options.cloneFunctions,false);assert.equal(call.value.from,'e2');
  }finally{delete globalThis.cloneInto;}
  const actual={game:{}};assert.equal(unwrapPage({wrappedJSObject:actual}),actual);
});
