import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULTS,SettingsStore,STORAGE_KEY} from '../src/core.js';
const memory=()=>{const data=new Map();return {getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,v)};};
const off=s=>Object.entries(DEFAULTS).filter(([,v])=>typeof v==='boolean').every(([key])=>s[key]===false);
test('fresh and default configurations have every function off',()=>{
 const store=new SettingsStore(memory());assert.ok(off(DEFAULTS));assert.ok(off(store.settings));assert.ok(off(store.active.settings));
});
test('master Arrow Color updates every visual color without enabling any function',()=>{
 const storage=memory(),store=new SettingsStore(storage);store.patch({arrowColor:'#12abef'});
 for(const key of ['arrowColor','highlightColor',...['Own','Enemy','Move','Target','Selected','Threat'].map(role=>'chams'+role+'Color')])assert.equal(store.settings[key],'#12abef',key);
 assert.ok(off(store.settings));assert.equal(new SettingsStore(storage).settings.chamsTargetColor,'#12abef');
 store.patch({chamsOwnColor:'#abcdef'});assert.equal(store.settings.chamsOwnColor,'#abcdef');store.patch({arrowColor:'#ff1234'});assert.equal(store.settings.chamsOwnColor,'#ff1234');
 store.patch({arrowColor:'invalid'});assert.equal(store.settings.chamsTargetColor,'#ff1234');
});
test('upgrade clears current switches once, preserves named configs and subsequent visual choices',()=>{
 const storage=memory(),settings={...DEFAULTS,chams:true,detect:true,watermark:true,width:848,menuStyle:'Fatachessty'};
 storage.setItem(STORAGE_KEY,JSON.stringify({version:1,active:'custom',settings,profiles:[{id:'default',name:'Default',settings},{id:'custom',name:'My setup',settings}]}));
 const store=new SettingsStore(storage);assert.ok(off(store.settings));assert.ok(off(store.profile('default').settings));assert.equal(store.settings.width,848);assert.equal(store.profile('custom').settings.chams,true);
 store.patch({watermark:true});const restored=new SettingsStore(storage);assert.equal(restored.settings.watermark,true);assert.equal(restored.settings.chams,false);
 restored.load('custom');assert.equal(restored.settings.chams,true);assert.equal(restored.settings.detect,true);
});
