// Pinned Stockfish.js 19.0.1; generated from the npm package.
export const ENGINE_ASSETS = {
  "single": {
    "js": {
      "url": "https://github.com/nmrugg/stockfish.js/releases/download/v19.0.1/stockfish-19-single.js",
      "size": 28130,
      "sha256": "8071dee87312f74805a859de933e1a1ef465579ab1a51fbd597388cdce9d444d"
    },
    "wasm": {
      "url": "https://github.com/nmrugg/stockfish.js/releases/download/v19.0.1/stockfish-19-single.wasm",
      "size": 99169054,
      "sha256": "991bede2f253ebb08ff01fcc48270f4b9c8e66b12d5bd5f8d6f52eb3e3b3a740"
    }
  },
  "full": {
    "js": {
      "url": "https://github.com/nmrugg/stockfish.js/releases/download/v19.0.1/stockfish-19.js",
      "size": 33326,
      "sha256": "623ee70a10d6dc202375127b49e2e1822635f9ab07693ae7be28e50a787f6218"
    },
    "wasm": {
      "url": "https://github.com/nmrugg/stockfish.js/releases/download/v19.0.1/stockfish-19.wasm",
      "size": 99076105,
      "sha256": "a599d78d72e0722d8895be84aca8b492d12e8bba3cdfcbcbc4a64017888c6667"
    }
  }
};
