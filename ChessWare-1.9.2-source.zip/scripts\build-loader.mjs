import {build} from 'esbuild';
import {readFile,writeFile,copyFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import JavaScriptObfuscator from 'javascript-obfuscator';
const version=JSON.parse(await readFile('package.json','utf8')).version;
const payload=await readFile('dist/ChessWare.protected.user.js');
const payloadName=`ChessWare-${version}.protected.user.js`;
await mkdir('dist',{recursive:true});
await copyFile('dist/ChessWare.protected.user.js',`dist/${payloadName}`);
const metadata=`// ==UserScript==
// @name         ChessWare Loader
// @namespace    chessware.loader
// @version      1.1.0
// @description  ChessWare.
// @author       ChessWare
// @license      GPL-3.0-or-later
// @match        https://www.chess.com/*
// @match        https://chess.com/*
// @grant        unsafeWindow
// @grant        GM_xmlhttpRequest
// @grant        GM_registerMenuCommand
// @connect      raw.githubusercontent.com
// @connect      github.com
// @connect      release-assets.githubusercontent.com
// @connect      api.chess.com
// @updateURL    https://raw.githubusercontent.com/Viktor1002/ChessWare/main/ChessWare.loader.user.js
// @downloadURL  https://raw.githubusercontent.com/Viktor1002/ChessWare/main/ChessWare.loader.user.js
// @run-at       document-idle
// @sandbox      JavaScript
// @noframes
// ==/UserScript==`;
const bundle=await build({entryPoints:['loader/loader.js'],write:false,bundle:true,format:'iife',target:['chrome110','firefox115'],loader:{'.css':'text'},minifyWhitespace:true,legalComments:'none'});
const options={compact:true,target:'browser-no-eval',seed:912110,
  identifierNamesGenerator:'hexadecimal',renameGlobals:false,renameProperties:false,
  stringArray:true,stringArrayThreshold:1,stringArrayEncoding:['rc4'],stringArrayRotate:true,stringArrayShuffle:true,
  stringArrayCallsTransform:true,stringArrayCallsTransformThreshold:0.6,
  controlFlowFlattening:true,controlFlowFlatteningThreshold:0.45,deadCodeInjection:true,deadCodeInjectionThreshold:0.1,
  numbersToExpressions:true,splitStrings:true,splitStringsChunkLength:12,
  reservedNames:['^GM_','^unsafeWindow$','^cloneInto$'],
  selfDefending:false,debugProtection:false,disableConsoleOutput:false,sourceMap:false};
const code=JavaScriptObfuscator.obfuscate(bundle.outputFiles[0].text,options).getObfuscatedCode();
await writeFile('dist/ChessWare.loader.user.js',metadata+'\n'+code+'\n');
await writeFile('dist/ChessWare.loader.protection.json',JSON.stringify({version:'1.1.0',tool:'javascript-obfuscator@5.10.0',options,bytes:Buffer.byteLength(code),sha256:createHash('sha256').update(metadata+'\n'+code+'\n').digest('hex')},null,2)+'\n');
const manifest={schema:1,version,url:`https://raw.githubusercontent.com/Viktor1002/ChessWare/main/dist/${payloadName}`,bytes:payload.length,sha256:createHash('sha256').update(payload).digest('hex')};
await writeFile('dist/release.json',JSON.stringify(manifest,null,2)+'\n');
console.log(`Built protected loader 1.1.0 and release manifest for ChessWare ${version}.`);
