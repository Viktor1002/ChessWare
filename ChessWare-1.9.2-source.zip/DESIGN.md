# Reference skin

The user's later correction supersedes the original interpretation: copy the supplied 657 × 555 screenshot's geometry, typography and navigation instead of creating a contemporary variant.

- Total window: 657 × 555 CSS pixels at 100% scale.
- Left rail: 76 px. Knife and target shortcuts have been removed, leaving five main tabs. The supplied image remains an unmodified sprite for the other icons.
- Main content begins 100 px from the left edge and 24 px from the top edge.
- Two approximately 256 px columns with a 22 px gap; inset dark panels, fine outlines, narrow scrollbars.
- No added titlebar, brand heading, page headings, tab captions or active green tab stripe. The top border strip remains draggable.
- Text: Verdana 9 px, 0.65 px letter spacing; fieldset legends bold at 9 px. Controls use 18 px rows, 6 px checkboxes, 5 px slider tracks and 18 px select buttons.
- Panel colours: `#101010`, textured frame `#151515 / #191919`, rail `#0c0c0c`, borders `#313131`, text `#bebebe`, accent `#8fae45`.
- Existing automatic chess functions remain functional after explicit activation for the current game. Both modes start paused; config loading, reload and detected game boundaries disarm them. Manual Analyse Position and its bind are removed. Stop All Assistance controls are located in Rage.
- Required version/status/config footer fits into the bottom strip without changing the overall dimensions.
- Misc contains an original-style watermark with fixed chessence branding, automatic own-account nickname, measured HTTP RTT and a live clock. Tickrate was removed in 1.3; brand/nickname text fields and center/restore actions were removed in 1.4.

Responsive scaling only applies when the viewport cannot contain the selected size. Dimensions are adjustable in Misc; the restore action was removed.

## Fatachessty

The third skin ports the user-supplied FatalityGUI source. `menu/menu.cpp` specifies 848×588; `gui/helpers.cpp` places content at (24,66) sized (800,482), horizontal tabs at x=126 and the toolbar at x=24/y=564. `window.cpp` draws a 50px header and 28px footer, title at x=25/y=19 and a 28px avatar near the upper right. `gui.h` supplies #110f23, #191534, #3c355d, #6d6496 and #eb055a. Source groups are 256px wide with 16px gaps, 478px tall without child tabs and 442px with the 36px child-tab area. Original control geometry is 12×12 checks, 100×14 sliders and 100×20 combos.

Josefin Sans SemiBold (the source's main face), Josefin Sans Bold and eight icons are imported as raw bytes; no native code runs. The full Fatachessty name shrinks only as needed to fit the 91px slot before navigation. The source's RGB title offset honours Animation/reduced motion. Five existing chess tabs and real settings replace the source's Counter-Strike content. The toolbar supplies real settings search, quicksave, Configs navigation and About. Each skin retains its own dimensions/spacing; leaving this skin restores original panel order and hides its chrome.

## NeverChess

Version 1.6.1 reduces the heading to 22px as requested. The account footer uses the actual own username/avatar from current-user data or trusted navigation, with own-side game headers as a fallback. A missing avatar can be read from the public player API; requests omit cookies, are cached and cancel on account changes. Opponents and arbitrary member pages cannot establish identity. Unknown identity uses an ellipsis, and image errors fall back to the user's initials. The source sample avatar is no longer rendered.

`Menu Style` switches between Old — Skeet and NeverChess. New — chessence was replaced. NeverChess ports the supplied ImGui example: 690 × 500 default, 170px sidebar, source Save at (190,20,100,25), section bar at (300,20,240,25), content at (185,76,490,404), 8px column gap, 210px left panel, full-height right panel and 20px group-caption area. The source #4d7dff accent, #020202 window and #050910 group fill are retained. Museo 14/28, Font Awesome and the avatar are extracted unchanged from bytes.hpp; FontFace objects are removed on teardown. Right-aligned switches measure 30×17 with 14px knobs; sliders measure 92×4 with 12px knobs and numeric cells; combos are 130px wide and colors use circular buttons. The source three-part header exposes 15 real panel views while retaining Legit, Rage, Misc, Visuals and Configs. HSV/HEX/alpha editing and Save are functional. The NC watermark uses actual username/ping/clock values. Old — Skeet remains available; original DOM order and visibility restore on switching back. Per-skin sizes/spacing are saved; source default gap migrates once to 8px.

Piece chams use alpha masks from the active Chess.com piece images, retaining the actual silhouettes. Normal own/enemy colors are overridden in order by capture target, engine origin, selection and threatened-piece colors. Capture targets are resolved with chess.js; en passant marks the pawn on the origin rank. Moves without captures never create a target. Keyed HTML layers fade over 220ms, reverse an interrupted exit, honor reduced motion, and clear obsolete pieces immediately after a position change. These layers do not receive pointer events. Unicode glyphs are a fallback for the local fixture.

Eight materials use the same mask: Flat (solid), Glow (radial glow), Outline (morphological border), Wireframe (crosshatch), Glass (transparent reflections), Metallic (reflective bands), Neon (bright border/glow), Scanline (moving horizontal bands). Role material overrides inherit the global choice by default. Extra outline, width and pulse are independent. Per-role alpha multiplies global opacity. SVG morphology runs on an already-masked child so it follows the silhouette rather than the square bounds. Pulse and scanline animate child surfaces, preserving the parent enter/exit fade. Disabled/reduced motion stops all ongoing effects.

Legit now follows Rage's four-panel engine/search/analysis structure with a dedicated strength-limit panel. Visual overlays retain unchanged keyed elements, animate opacity in both directions over 220 ms and use restrained gradient fills and soft arrow shadows. The animation never retains a move on a different position.
