import { spawn } from 'node:child_process';
import { readFile,writeFile,mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {VERSION} from '../src/core.js';
import {ENABLED_DEFAULTS} from './fixtures/features.mjs';
const driver=spawn(resolve('.test-tools/geckodriver/geckodriver.exe'),['--port','4447','--log','error','--allow-system-access'],{stdio:['ignore','pipe','pipe']});
const server=spawn(process.execPath,['scripts/serve.mjs','--port','4181'],{stdio:['ignore','pipe','inherit']});
let session;
const navigationOnly=process.argv.includes('--navigation-only');
const visualsOnly=process.argv.includes('--visuals-only');
const identityOnly=process.argv.includes('--identity-only');
const sessionOnly=process.argv.includes('--session-only');
const standaloneWatermark=process.argv.includes('--standalone-watermark');
const protectedBuild=process.argv.includes('--protected');
const loaderLocal=process.argv.includes('--loader-local');
const loaderBuild=process.argv.includes('--loader')||loaderLocal;
const scriptFile=loaderLocal?'ChessWare.loader.local-test.user.js':loaderBuild?'ChessWare.loader.user.js':protectedBuild?'ChessWare.protected.user.js':'ChessWare.user.js';
const fataOnly=process.argv.includes('--fatachessty-only')||standaloneWatermark;
async function request(method,path,body){const response=await fetch('http://127.0.0.1:4447'+path,{method,signal:AbortSignal.timeout(45000),headers:{'Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});const data=await response.json();if(data.value?.error)throw new Error(data.value.error+': '+data.value.message);return data.value;}
const command=(method,path,body)=>request(method,`/session/${session}`+path,body);
const execute=(script,args=[])=>command('POST','/execute/sync',{script,args});
const find=selector=>execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector(arguments[0]);',[selector]);
const click=async selector=>{const element=await find(selector);const id=element?.['element-6066-11e4-a52e-4f735466cecf'];assert.ok(id,selector);await command('POST',`/element/${id}/click`,{});};
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function waitFor(fn,timeout=20000){const start=Date.now();let last;while(Date.now()-start<timeout){try{const value=await fn();if(value)return value;}catch(e){last=e;}await sleep(250);}throw last||new Error('Timed out');}
await mkdir('test-results',{recursive:true});
try{
  await waitFor(()=>request('GET','/status'),10000);
  const created=await request('POST','/session',{capabilities:{alwaysMatch:{browserName:'firefox','moz:firefoxOptions':{binary:'C:\\Program Files\\Mozilla Firefox\\firefox.exe',args:['-headless'],prefs:{'intl.accept_languages':'en-US,en','browser.shell.checkDefaultBrowser':false,'browser.startup.homepage_override.mstone':'ignore','datareporting.policy.dataSubmissionEnabled':false,'toolkit.telemetry.reportingpolicy.firstRun':false}}}}});
  session=created.sessionId;console.log('Firefox:',created.capabilities.browserVersion);
  await command('POST','/timeouts',{pageLoad:15000,script:15000});
  console.log('Installing Tampermonkey');
  await command('POST','/moz/addon/install',{path:resolve('.test-tools/tampermonkey-5.5.0.xpi'),temporary:false});
  console.log('Tampermonkey installed');
  await sleep(2500);
  await command('POST','/url',{url:'http://127.0.0.1:4181/dist/'+scriptFile}).catch(error=>console.log('Navigation:',error.message));
  await sleep(2500);
  let installed=false,lastInstallRetry=Date.now();
  await waitFor(async()=>{
    const handles=await command('GET','/window/handles');
    for(const handle of handles){await command('POST','/window',{handle});const url=await command('GET','/url');if(!url.startsWith('moz-extension:'))continue;installed=await execute('const button=[...document.querySelectorAll("input[type=button]")].find(n=>/^(Install|Встановити|Установить)$/.test(n.value));if(button){button.click();return true;}return false;');if(installed)return true;}
    // A fresh extension can finish starting after the initial source request.
    if(Date.now()-lastInstallRetry>5000){lastInstallRetry=Date.now();await command('POST','/url',{url:'http://127.0.0.1:4181/dist/'+scriptFile}).catch(()=>{});}
    return false;
  },30000);
  assert.ok(installed,'Tampermonkey installer button');console.log('chessence installed in Tampermonkey');
  await sleep(1500);const remaining=await command('GET','/window/handles');await command('POST','/window',{handle:remaining[0]});
  if(standaloneWatermark){server.kill();await sleep(500);await assert.rejects(()=>fetch('http://127.0.0.1:4181/',{signal:AbortSignal.timeout(1500)}));}
  await command('POST','/url',{url:navigationOnly||identityOnly||fataOnly?'https://www.chess.com/':'https://www.chess.com/play/computer'}).catch(e=>console.log('Page load:',e.message));
  if(loaderBuild){
    await waitFor(()=>execute('return !!document.querySelector("#chessware-loader")'),30000);
    assert.equal(await execute('return !!document.querySelector("#chess-skeet-root")'),false,'payload never runs before Load');
    await execute('document.querySelector("#chessware-loader").shadowRoot.querySelector(".login-button").click();');
    await waitFor(async()=>{
      const status=await execute('const root=document.querySelector("#chessware-loader").shadowRoot;return {text:root.querySelector(".log").textContent,disabled:root.querySelector("[data-action=load]").disabled};');
      if(status.text.includes('failed')||status.text.includes('HTTP ')||status.text.includes('Invalid '))throw new Error(status.text);
      return !status.disabled&&status.text.includes('Verified');
    },90000);
    await writeFile('test-results/firefox-loader-ready.png',Buffer.from(await command('GET','/screenshot'),'base64'));
    await execute('document.querySelector("#chessware-loader").shadowRoot.querySelector("[data-action=load]").click();');
    const loaded=await waitFor(()=>execute('const r=document.querySelector("#chessware-loader").shadowRoot;return r.querySelector(".log").textContent;'));
    assert.ok(loaded.includes('Loaded · Insert'),loaded);
    await execute('document.querySelector("#chessware-loader").shadowRoot.querySelector("[data-action=exit]").click();');
    console.log('Native loader verified payload and launched ChessWare through Tampermonkey. Transport:',loaderLocal?'local fixture':'GitHub');
  }
  await waitFor(()=>execute('return !!document.querySelector("#chess-skeet-root")'),30000);
  assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelectorAll("input[type=checkbox]:checked").length;'),0,'fresh production defaults have every function off');
  // These existing feature regressions opt in through real controls after checking the empty baseline.
  await execute('const root=document.querySelector("#chess-skeet-root").shadowRoot;for(const key of arguments[0]){const input=root.querySelector(`[data-key="${key}"]`);if(input&&!input.checked){input.checked=true;input.dispatchEvent(new Event("change",{bubbles:true}));}}', [Object.keys(ENABLED_DEFAULTS).filter(key=>ENABLED_DEFAULTS[key]===true)]);
  if(fataOnly){
    await click('.watermark');await click('[data-tab="Misc"]');await click('[data-select="menuStyle"] .select-toggle');await click('[data-select="menuStyle"] [data-value="Fatachessty"]');
    await execute('document.body.insertAdjacentHTML("beforeend",\'<a data-cy="nav-link-profile" href="/member/Guest4873515159">Profile</a>\');');
    await waitFor(()=>execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".nc-account-name").textContent==="Guest4873515159";'),15000);
    await waitFor(()=>execute('return document.fonts.check(\'12px "Fatachessty Josefin"\')&&document.fonts.check(\'700 18px "Fatachessty Josefin"\');'),15000);
    const rects=await execute('const root=document.querySelector("#chess-skeet-root").shadowRoot,m=root.querySelector(".menu").getBoundingClientRect(),title=root.querySelector(".ft-brand");return {skin:root.querySelector(".menu").dataset.skin,width:m.width,height:m.height,title:title.textContent,titleFits:title.scrollWidth<=title.clientWidth,panels:[...root.querySelectorAll("[data-page=Misc] fieldset:not([hidden])")].map(n=>{const r=n.getBoundingClientRect();return [r.x-m.x,r.y-m.y,r.width,r.height];})};');
    assert.equal(rects.skin,'fatachessty');assert.equal(rects.width,848);assert.equal(rects.height,588);assert.equal(rects.title,'Fatachessty');assert.equal(rects.titleFits,true);assert.deepEqual(rects.panels,[[24,66,256,478],[296,66,256,478],[568,66,256,478]]);
    const watermark=await execute('const root=document.querySelector("#chess-skeet-root").shadowRoot,w=root.querySelector(".watermark"),n=w.querySelector(".wm-name"),s=getComputedStyle(n);return {text:n.textContent,font:s.fontFamily,weight:s.fontWeight,uppercase:s.textTransform,shadow:s.textShadow,background:getComputedStyle(w).backgroundColor,animation:s.animationName};');
    assert.equal(watermark.text,'Fatachessty');assert.ok(watermark.font.includes('Fatachessty Josefin'));assert.equal(watermark.weight,'700');assert.equal(watermark.uppercase,'uppercase');assert.equal(watermark.background,'rgb(25, 21, 52)');assert.equal(watermark.animation,'ft-glitch');
    assert.ok(await execute('const w=document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".watermark");return w.getBoundingClientRect().height<=26&&getComputedStyle(w).fontSize==="10px"&&getComputedStyle(w.querySelector(".wm-name")).fontSize==="12px";'));
    await click('[data-tab="Visuals"]');await click('[data-page="Visuals"] [data-ft-section="1"]');await click('[data-key="chamsOutline"]');
    assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector("[data-key=chamsOutline]").checked;'),true);
    await click('[data-select="chamsMaterial"] .select-toggle');await click('.options:not([hidden]) [data-value="Neon"]');
    await click('[data-color-key="chamsOwnColor"]');assert.equal(await execute('return !document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".nc-color-picker").hidden;'),true);await click('.nc-picker-close');
    await click('[data-page="Visuals"] [data-ft-section="2"]');await click('[data-key="animation"]');assert.equal(await execute('return getComputedStyle(document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".watermark .wm-name")).animationName;'),'none');
    await click('.ft-tool[aria-label="About"]');assert.equal(await execute('return !document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".ft-dialog").hidden;'),true);await click('[aria-label="Close dialog"]');await sleep(250);
    await writeFile('test-results/firefox-fatachessty.png',Buffer.from(await command('GET','/screenshot'),'base64'));
    await command('POST','/refresh',{}).catch(()=>{});
    if(loaderBuild){
      await waitFor(()=>execute('return !!document.querySelector("#chessware-loader")'),30000);
      await waitFor(()=>execute('return !!document.querySelector("#chess-skeet-root")'),90000);
      assert.ok(await execute('const r=document.querySelector("#chessware-loader").shadowRoot;return r.querySelector(".login").hidden&&r.querySelector(".loader").hidden;'),'refresh restores loaded mod silently');
      await command('POST','/url',{url:'https://www.chess.com/games'}).catch(()=>{});
      await waitFor(()=>execute('return !!document.querySelector("#chess-skeet-root")'),90000);
      assert.ok(await execute('const r=document.querySelector("#chessware-loader").shadowRoot;return r.querySelector(".login").hidden&&r.querySelector(".loader").hidden;'),'another Chess.com page restores loaded mod silently');
      assert.ok(await execute('const r=document.querySelector("#chess-skeet-root").shadowRoot;return ["rageEnabled","legitEnabled","autoPlay","autoMove"].every(k=>!r.querySelector(`[data-key="${k}"]`).checked);'),'restoring code never arms assistance');
    }
    await waitFor(()=>execute('return document.querySelector("#chess-skeet-root")?.shadowRoot.querySelector(".menu").dataset.skin==="fatachessty";'),30000);
    await writeFile(loaderLocal?'test-results/firefox-loader-local.json':loaderBuild?'test-results/firefox-loader.json':protectedBuild?'test-results/firefox-protected.json':'test-results/firefox-fatachessty.json',JSON.stringify({version:VERSION,loaderBuild,loaderLocal,protectedBuild,bundleSHA256:createHash('sha256').update(await readFile('dist/'+scriptFile)).digest('hex'),firefox:created.capabilities.browserVersion,tampermonkey:'5.5.0',...rects,watermark,installationServerStopped:standaloneWatermark,outline:true,material:true,colorPicker:true,about:true,reload:true},null,2)+'\n');
    console.log('PASS native Firefox/Tampermonkey Fatachessty: exact frame/groups, original fonts, full title, sections, real outline/material/color editor, toolbar and reload.');
  }else if(identityOnly){
    // Reproduce a signed-in own-profile navigation node in this fresh guest test profile.
    // No login or private account is used. The avatar is fetched from the real public API.
    await execute('document.body.insertAdjacentHTML("beforeend",\'<a data-cy="nav-link-profile" href="/member/Hikaru">Profile</a>\');const descriptor=Object.getOwnPropertyDescriptor(window,"context");if(!descriptor||descriptor.configurable)Object.defineProperty(window,"context",{configurable:true,get(){throw new Error("Permission denied to access object");}});');
    await waitFor(()=>execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".nc-account-name").textContent==="Hikaru";'),15000);
    await waitFor(()=>execute('const img=document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".nc-avatar img");return !img.hidden&&img.complete&&img.naturalWidth>0&&img.src.startsWith("https://images.chesscomfiles.com/");'),20000);
    await click('.watermark');await click('[data-tab="Misc"]');await click('[data-select="menuStyle"] .select-toggle');await click('[data-select="menuStyle"] [data-value="NeverChess"]');
    assert.equal(await execute('return getComputedStyle(document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".nc-brand")).fontSize;'),'22px');
    const shot=await command('GET','/screenshot');await writeFile('test-results/firefox-account.png',Buffer.from(shot,'base64'));
    console.log('PASS native Firefox/Tampermonkey: own-profile navigation fixture resolves with denied page context; real public API avatar loads through GM request; title is 22px.');
  }else if(navigationOnly){
    const hidden=()=>execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".menu").hidden;');
    const toggle=()=>execute('document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".watermark").click();');
    assert.equal(await hidden(),true);await toggle();assert.equal(await hidden(),false);await toggle();assert.equal(await hidden(),true);
    await execute('history.pushState({},"","/?chessence-nav=spa");window.dispatchEvent(new PopStateEvent("popstate"));');assert.equal(await hidden(),true);
    await command('POST','/url',{url:'https://www.chess.com/?chessence-nav=full'}).catch(()=>{});
    await waitFor(()=>execute('return !!document.querySelector("#chess-skeet-root")'),30000);assert.equal(await hidden(),true);
    await command('POST','/refresh',{}).catch(()=>{});await waitFor(()=>execute('return !!document.querySelector("#chess-skeet-root")'),30000);assert.equal(await hidden(),true);
    await toggle();assert.equal(await hidden(),false);
    const current=await command('GET','/window');const other=await command('POST','/window/new',{type:'tab'});await command('POST','/window',{handle:other.handle});
    await command('POST','/url',{url:'https://www.chess.com/?chessence-nav=other'}).catch(()=>{});await waitFor(()=>execute('return !!document.querySelector("#chess-skeet-root")'),30000);assert.equal(await hidden(),true);
    await command('POST','/window',{handle:current});assert.equal(await hidden(),false);
    console.log('PASS native Firefox + Tampermonkey: menu stays hidden through SPA, navigation and refresh; independent tab state and explicit watermark opening.');
  }else{
  await sleep(2500);
  await execute('const welcome=document.querySelector("#first-time-modal");const start=welcome&&[...welcome.querySelectorAll("button")].find(b=>b.textContent.trim()==="Start");if(start)start.click();');
  await sleep(300);
  await execute('const play=[...document.querySelectorAll("button")].find(b=>b.textContent.trim()==="Play"&&b.getBoundingClientRect().width>0);if(play)play.click();');
  await sleep(400);
  await execute('const start=[...document.querySelectorAll("button")].find(b=>b.textContent.trim()==="Start"&&b.getBoundingClientRect().width>0);if(start)start.click();');
  if(sessionOnly){
    // Test game-bound activation in the real userscript realm without a network engine dependency.
    const modes=()=>execute('const root=document.querySelector("#chess-skeet-root").shadowRoot;return Object.fromEntries(["rageEnabled","legitEnabled","autoPlay","autoMove"].map(k=>[k,root.querySelector(`[data-key=${k}]`).checked]));');
    const paused={rageEnabled:false,legitEnabled:false,autoPlay:false,autoMove:false};
    await waitFor(()=>execute('return !document.querySelector("#chess-skeet-root").shadowRoot.querySelector("[data-key=rageEnabled]").disabled;'),30000);
    assert.deepEqual(await modes(),paused);
    await click('.watermark');await click('[data-tab="Rage"]');await click('[data-key="continuous"]');await click('[data-key="rageEnabled"]');
    await sleep(600);assert.equal((await modes()).rageEnabled,true);
    assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector("[data-page=Rage] [data-live=best]").textContent;'),'—');
    const playFirstLegal=()=>execute('const game=document.querySelector("wc-chess-board").game;const move=game.getLegalMoves()[0];game.move({...move,userGenerated:true,animate:true});');
    await playFirstLegal();await waitFor(()=>execute('return document.querySelector("wc-chess-board").game.getHistorySANs().length>=2;'),30000);await sleep(500);
    assert.equal((await modes()).rageEnabled,true,'real normal moves retain Rage activation');
    await click('[data-page="Rage"] [data-action="stop"]');await click('[data-tab="Legit"]');await click('[data-key="legitContinuous"]');await click('[data-key="legitEnabled"]');
    await sleep(500);assert.equal((await modes()).legitEnabled,true);
    await playFirstLegal();await waitFor(()=>execute('return document.querySelector("wc-chess-board").game.getHistorySANs().length>=4;'),30000);await sleep(500);
    assert.equal((await modes()).legitEnabled,true,'real normal moves retain Legit activation');
    const moves=await execute('return document.querySelector("wc-chess-board").game.getHistorySANs();');
    await command('POST','/refresh',{}).catch(()=>{});await waitFor(()=>execute('return !!document.querySelector("#chess-skeet-root")'),30000);await sleep(800);
    assert.deepEqual(await modes(),paused,'reload never restores runtime modes');
    await writeFile('test-results/firefox-session-controls.json',JSON.stringify({version:VERSION,firefox:created.capabilities.browserVersion,tampermonkey:'5.5.0',initiallyPaused:true,normalMovesRetainRage:true,normalMovesRetainLegit:true,reloadPaused:true,moves,scope:'fresh guest bot game; engine analysis disabled to isolate session control'},null,2)+'\n');
    console.log('PASS native Firefox/Tampermonkey: starts paused; real bot-game moves retain manual Rage/Legit activation; reload disarms both modes and auto-move switches. Moves:',moves);
  }else if(visualsOnly){
    await waitFor(()=>execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelectorAll(".cs-cham").length===32;'),30000);
    await click('.watermark');await click('[data-tab="Rage"]');await click('[data-page="Rage"] [data-action="stop"]');
    await click('[data-tab="Misc"]');await click('[data-select="menuStyle"] .select-toggle');await click('[data-select="menuStyle"] [data-value="NeverChess"]');await click('[data-tab="Visuals"]');
    await click('[data-nc-section="1"]');await click('.watermark');await sleep(400);
    const on=await command('GET','/screenshot');
    const rect=await execute('const r=document.querySelector("wc-chess-board").getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height};');
    await click('.watermark');await click('[data-key="chams"]');await click('.watermark');await sleep(300);
    const off=await command('GET','/screenshot');
    const {PNG}=(await import('../node_modules/playwright-core/lib/utilsBundle.js')).default;
    const a=PNG.sync.read(Buffer.from(on,'base64')),b=PNG.sync.read(Buffer.from(off,'base64'));let changed=0;
    for(let y=Math.ceil(rect.top);y<Math.min(a.height,rect.top+rect.height);y++)for(let x=Math.ceil(rect.left);x<Math.min(a.width,rect.left+rect.width);x++){const i=(y*a.width+x)*4;if(Math.abs(a.data[i]-b.data[i])+Math.abs(a.data[i+1]-b.data[i+1])+Math.abs(a.data[i+2]-b.data[i+2])>35)changed++;}
    assert.ok(changed>1000,`Real masked-piece pixels changed: ${changed}`);
    await writeFile('test-results/firefox-chams-on.png',Buffer.from(on,'base64'));await writeFile('test-results/firefox-chams-off.png',Buffer.from(off,'base64'));
    const hashes=new Set();await click('.watermark');await click('[data-key="chams"]');
    for(const material of ['Flat','Glow','Outline','Wireframe','Glass','Metallic','Neon','Scanline']){
      await click('[data-select="chamsMaterial"] .select-toggle');await click(`.options:not([hidden]) [data-value="${material}"]`);await click('.watermark');await sleep(300);
      const shot=await command('GET','/screenshot'),png=PNG.sync.read(Buffer.from(shot,'base64')),hash=createHash('sha256');let pixels=0;
      for(let y=Math.ceil(rect.top);y<Math.min(png.height,rect.top+rect.height);y++){const start=(y*png.width+Math.ceil(rect.left))*4,end=(y*png.width+Math.min(png.width,Math.floor(rect.left+rect.width)))*4;hash.update(png.data.subarray(start,end));for(let i=start;i<end;i+=4)if(Math.abs(png.data[i]-b.data[i])+Math.abs(png.data[i+1]-b.data[i+1])+Math.abs(png.data[i+2]-b.data[i+2])>35)pixels++;}
      assert.ok(pixels>200,`${material} must visibly render on real piece images: ${pixels}`);hashes.add(hash.digest('hex'));await writeFile(`test-results/firefox-chams-${material.toLowerCase()}.png`,Buffer.from(shot,'base64'));await click('.watermark');
      console.log(`Firefox material ${material}: ${pixels} changed board pixels`);
    }
    assert.equal(hashes.size,8,'eight real Firefox materials differ');
    console.log(`PASS native Firefox/Tampermonkey + NeverChess: real Chess.com piece masks visibly change ${changed} board pixels; chams toggle and hidden menu work.`);
  }else{
  await waitFor(()=>execute('return !document.querySelector("#chess-skeet-root").shadowRoot.querySelector("[data-key=rageEnabled]").disabled;'),30000);
  await click('.watermark');await click('[data-tab="Rage"]');await click('[data-key="rageEnabled"]');
  const state=()=>execute('const root=document.querySelector("#chess-skeet-root")?.shadowRoot;const tab=root?.querySelector("[data-key=legitEnabled]").checked?"Legit":"Rage";return root?{badge:root.querySelector(".badge")?.textContent,status:root.querySelector(".footer .status")?.textContent,engine:root.querySelector("[data-live=engine]")?.textContent,toast:root.querySelector(".toast")?.textContent,best:root.querySelector(`[data-page=${tab}] [data-live=best]`)?.textContent}:null;');
  let last='',lastLog=0;
  await waitFor(async()=>{const s=await state();const next=JSON.stringify(s);if(next!==last&&(!s?.engine?.startsWith('Downloading engine')||Date.now()-lastLog>10000)){last=next;lastLog=Date.now();console.log('State:',next);}if(s?.toast?.includes('Permission denied'))throw new Error(s.toast);return s?.best&&s.best!=='—';},180000);
  console.log('Native Firefox + Tampermonkey engine ready:',await state());
  const chamsState=await execute('const root=document.querySelector("#chess-skeet-root").shadowRoot;return {count:root.querySelectorAll(".cs-cham").length,masks:[...root.querySelectorAll(".cs-cham-shape:not(.cs-cham-glyph)")].filter(n=>getComputedStyle(n).maskImage!=="none").length};');
  assert.ok(chamsState.count>=30,JSON.stringify(chamsState));assert.ok(chamsState.masks>=30,JSON.stringify(chamsState));console.log('Native piece silhouettes:',chamsState);
  await click('[data-tab="Rage"]');await click('[data-key="autoPlay"]');
  await waitFor(()=>execute('return document.querySelector("wc-chess-board").game.getHistorySANs().length>=2'),30000);
  const moves=await execute('return document.querySelector("wc-chess-board").game.getHistorySANs();');console.log('Accepted Firefox moves:',moves);
  assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector("[data-key=rageEnabled]").checked;'),true,'normal moves retain manual Rage activation');
  await click('[data-page="Rage"] [data-action="stop"]');
  await click('[data-tab="Legit"]');await click('[data-key="legitEnabled"]');
  await waitFor(async()=>{const s=await state();return s?.best&&s.best!=='—'&&s.status==='Analysis complete';},30000);
  assert.ok((await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector("[data-page=Legit] [data-live=choice]").textContent;')).includes('Skill 4/20'));
  await click('[data-key="autoMove"]');
  await waitFor(()=>execute('return document.querySelector("wc-chess-board").game.getHistorySANs().length>=4'),30000);
  console.log('Legit accepted Firefox moves:',await execute('return document.querySelector("wc-chess-board").game.getHistorySANs();'));
  assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector("[data-key=legitEnabled]").checked;'),true,'normal moves retain manual Legit activation');
  await click('[data-tab="Rage"]');await click('[data-page="Rage"] [data-action="stop"]');
  assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelectorAll("[data-key=wmTick],[data-key=wmTickText]").length;'),0);
  assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelectorAll(".nav-knife").length;'),0);
  assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelectorAll(".nav-target,[data-key=wmBrand],[data-key=wmNickname],[data-select=analysisKey],[data-action=analyze],[data-action=center],[data-action=reference-size]").length;'),0);
  assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelectorAll("[data-page=Rage] [data-select=stopKey]").length;'),1);
  assert.ok(!(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".watermark").textContent;')).includes('Marko'));
  const shot=await command('GET','/screenshot');await writeFile('test-results/firefox-chessence.png',Buffer.from(shot,'base64'));
  await click('[data-tab="Misc"]');
  await click('[data-select="menuStyle"] .select-toggle');
  await click('[data-select="menuStyle"] [data-value="NeverChess"]');
  assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".menu").dataset.skin;'),'neverchess');
  assert.ok(await execute('return document.fonts.check(\'900 23px "NeverChess Museo"\');'));
  let skinShot=await command('GET','/screenshot');await writeFile('test-results/firefox-chessence-new.png',Buffer.from(skinShot,'base64'));
  await click('[data-select="menuStyle"] .select-toggle');
  await click('.options:not([hidden]) [data-value="chessence"]');
  assert.equal(await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".menu").dataset.skin;'),'old');
  const toast=await execute('return document.querySelector("#chess-skeet-root").shadowRoot.querySelector(".toast").textContent;');assert.ok(!toast.includes('Permission denied'),toast);
  console.log('PASS native Firefox 159 + Tampermonkey 5.5: startup, full NNUE download, analysis, accepted move and stop.');
  }
  }
}catch(error){console.error(error.message);if(session){const shot=await command('GET','/screenshot').catch(()=>null);if(shot)await writeFile('test-results/firefox-failure.png',Buffer.from(shot,'base64'));}throw error;}finally{if(session)await command('DELETE','').catch(()=>{});driver.kill();server.kill();}
