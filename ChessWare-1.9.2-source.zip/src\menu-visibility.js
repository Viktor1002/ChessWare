export const MENU_VISIBILITY_KEY='chessence:menu-visible';

// Visibility belongs to the browser tab, not a config or a single document.
export class MenuVisibility {
  constructor(storage){
    this.storage=storage;this.visible=false;
    try{this.visible=storage?.getItem(MENU_VISIBILITY_KEY)==='open';}catch{}
  }
  set(value){
    this.visible=!!value;
    try{this.storage?.setItem(MENU_VISIBILITY_KEY,this.visible?'open':'closed');}catch{}
    return this.visible;
  }
}

export function menuSessionStorage(){
  try{return window.sessionStorage;}catch{return null;}
}
