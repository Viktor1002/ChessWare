import {chromium,expect} from '@playwright/test';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import {DEFAULTS,STORAGE_KEY} from '../src/core.js';
const server=spawn(process.execPath,['scripts/serve.mjs','--port','4187'],{stdio:['ignore','pipe','inherit']});let browser;
try{
 await new Promise(resolve=>server.stdout.once('data',resolve));browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:900}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.route('https://images.chesscomfiles.com/test/**',route=>route.fulfill({contentType:'image/svg+xml',body:'<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="64" height="64" fill="#4d7dff"/><circle cx="32" cy="24" r="10" fill="white"/><path d="M12 60a20 20 0 0 1 40 0" fill="white"/></svg>'}));
 await page.addInitScript(({key,defaults})=>{if(!localStorage.getItem(key)){const settings={...defaults,menuStyle:'NeverChess',width:690,height:500,spacing:8,x:650,y:105,rageEnabled:false,wmPing:false};localStorage.setItem(key,JSON.stringify({version:1,brand:'chessence',settings,active:'default',profiles:[{id:'default',name:'Default',settings}]}));}},{key:STORAGE_KEY,defaults:DEFAULTS});
 await page.goto('http://127.0.0.1:4187');await page.keyboard.press('Insert');
 await page.evaluate(()=>{
   window.__skeet.setMode('off');
   Object.defineProperty(window,'context',{configurable:true,get(){throw new Error('Permission denied to access object');}});
   document.body.insertAdjacentHTML('beforeend','<div class="player-component" data-username="Opponent"><a href="/member/Opponent"><img src="https://images.chesscomfiles.com/test/opponent.png"></a></div><nav id="sb"><a class="nav-link-profile" href="/member/OwnerNick"><img src="https://images.chesscomfiles.com/test/owner.png"></a></nav>');
 });
 await expect(page.locator('.nc-account-name')).toHaveText('OwnerNick');await expect(page.locator('.watermark')).toContainText('OwnerNick');
 const image=page.locator('.nc-avatar img');await expect(image).toBeVisible();await expect(image).toHaveAttribute('src','https://images.chesscomfiles.com/test/owner.png');await expect(image).not.toHaveAttribute('src',/opponent/);
 await expect.poll(()=>image.evaluate(n=>n.complete&&n.naturalWidth>0)).toBe(true);
 assert.equal(await page.locator('.nc-brand').evaluate(n=>getComputedStyle(n).fontSize),'22px');
 await page.screenshot({path:'test-results/account-profile.png'});
 await page.evaluate(()=>{const a=document.querySelector('#sb a');a.href='/member/SecondNick';a.querySelector('img').src='https://images.chesscomfiles.com/test/second.png';});
 await expect(page.locator('.nc-account-name')).toHaveText('SecondNick');await expect(image).toHaveAttribute('src','https://images.chesscomfiles.com/test/second.png');
 await page.evaluate(()=>{Object.defineProperty(window,'context',{configurable:true,value:{user:{username:'CurrentAccount',avatarUrl:'https://images.chesscomfiles.com/test/current.png'}}});});
 await expect(page.locator('.nc-account-name')).toHaveText('CurrentAccount');await expect(image).toHaveAttribute('src','https://images.chesscomfiles.com/test/current.png');
 await page.route('https://images.chesscomfiles.com/test/broken.png',route=>route.fulfill({status:404,body:''}));
 await page.evaluate(()=>window.context.user.avatarUrl='https://images.chesscomfiles.com/test/broken.png');await expect(image).toBeHidden();await expect(page.locator('.nc-avatar-initials')).toHaveText('CU');
 await page.evaluate(()=>{delete window.context;document.querySelector('#sb').remove();window.__skeet.board.remove();});
 await expect(page.locator('.nc-account-name')).toHaveText('…');await expect(page.locator('.watermark')).not.toContainText('Opponent');await expect(page.locator('.watermark')).not.toContainText('Guest');
 await page.keyboard.press('Insert');await page.reload();await expect(page.locator('.menu')).toBeHidden();assert.deepEqual(errors,[]);
 console.log('PASS real own navigation nickname/avatar outside a game, denied page context, opponent exclusion, account/portrait updates, broken-image initials, no fake Guest and 22px title.');
}finally{await browser?.close();server.kill();}
