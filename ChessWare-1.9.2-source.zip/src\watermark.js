import {ProfileIdentity,accountName} from './account.js';
export function watermarkParts(settings, now, ping, username='Guest') {
  const parts=[settings.menuStyle==='NeverChess'?'NC':settings.menuStyle==='Fatachessty'?'Fatachessty':'chessence',username==='…'?'…':accountName(username)||'Guest'];
  if(settings.wmPing)parts.push(ping == null ? '— ms' : `${ping} ms`);
  if(settings.wmTime)parts.push(new Intl.DateTimeFormat(settings.wmClock==='12-hour'?'en-US':'en-GB',{hour:'2-digit',minute:'2-digit',...(settings.wmSeconds?{second:'2-digit'}:{}),hour12:settings.wmClock==='12-hour'}).format(now));
  return parts;
}
export class Watermark {
  constructor(element,store,page=typeof unsafeWindow!=='undefined'?unsafeWindow:window){this.element=element;this.store=store;this.page=page;this.identity=new ProfileIdentity(page);this.ping=null;this.lastPing=0;this.pending=false;this.timer=setInterval(()=>this.update(),1000);this.unsubscribe=store.subscribe(()=>this.update());this.update();}
  update(){
    const s=this.store.settings;this.element.hidden=!s.watermark;
    this.element.dataset.animated=String(s.animation);
    this.profile=this.identity.read();this.username=this.profile.username||'…';
    const parts=watermarkParts(s,new Date(),this.ping,this.username);
    this.element.replaceChildren();
    for(const [i,text]of parts.entries()){
      const span=document.createElement('span');span.className=i===0?'wm-name':'wm-field';
      if(i===0&&['gamesense','chessence'].includes(text)){const split=text==='chessence'?5:4;span.append(document.createTextNode(text.slice(0,split)));const accent=document.createElement('b');accent.textContent=text.slice(split);span.append(accent);}else span.textContent=text;
      this.element.append(span);
    }
    const right=s.wmPosition.endsWith('right'),top=s.wmPosition.startsWith('Top');
    Object.assign(this.element.style,{left:right?'auto':s.wmOffsetX+'px',right:right?s.wmOffsetX+'px':'auto',top:top?s.wmOffsetY+'px':'auto',bottom:top?'auto':s.wmOffsetY+'px',opacity:s.wmOpacity/100});
    this.element.title=`Toggle menu (${s.menuKey}). Ping: measured HTTP round trip.`;
    if(s.watermark&&s.wmPing&&!document.hidden&&!this.pending&&Date.now()-this.lastPing>30000)this.measure();
  }
  async measure(){
    this.pending=true;this.lastPing=Date.now();this.controller=new AbortController();const timer=setTimeout(()=>this.controller.abort(),5000);
    try{const start=performance.now();const response=await fetch(new URL('/favicon.ico',location.origin),{method:'HEAD',cache:'no-store',credentials:'omit',signal:this.controller.signal});this.ping=response.ok?Math.round(performance.now()-start):null;}
    catch{this.ping=null;}finally{clearTimeout(timer);this.pending=false;}
  }
  destroy(){clearInterval(this.timer);this.controller?.abort();this.identity.destroy();this.unsubscribe();}
}
