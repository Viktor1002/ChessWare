# ChessWare

Tampermonkey userscript. Login → Load.
