import {ENABLED_DEFAULTS} from './fixtures/features.mjs';
import {chromium,expect} from '@playwright/test';
import {spawn} from 'node:child_process';
import {mkdir,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const server=spawn(process.execPath,['scripts/serve.mjs','--port','4190'],{stdio:['ignore','pipe','inherit']});let browser;
try{
 await new Promise(resolve=>server.stdout.once('data',resolve));browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:900}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{window.context={user:{username:'PortOwner'}};});await page.addInitScript(defaults=>{if(localStorage.getItem('chess-skeet:v1'))return;const settings={...defaults};localStorage.setItem('chess-skeet:v1',JSON.stringify({version:1,defaultsRevision:1,settings,active:'default',profiles:[{id:'default',name:'Default',settings}]}));},ENABLED_DEFAULTS);await page.goto('http://127.0.0.1:4190');
 await expect(page.locator('.menu')).toBeHidden();await page.keyboard.press('Insert');await page.getByRole('tab',{name:'Misc',exact:true}).click();
 await page.getByRole('button',{name:'Menu Style chessence',exact:true}).click();await expect(page.getByRole('option',{name:'Fatachessty',exact:true})).toBeVisible();await page.getByRole('option',{name:'Fatachessty',exact:true}).click();
 await expect(page.locator('.menu')).toHaveAttribute('data-skin','fatachessty');await page.evaluate(()=>document.fonts.ready);await page.evaluate(()=>window.__skeet.app.store.patch({x:450,y:100}));
 const relative=locator=>locator.evaluate(n=>{const r=n.getBoundingClientRect(),m=n.getRootNode().querySelector('.menu').getBoundingClientRect();return {x:r.x-m.x,y:r.y-m.y,w:r.width,h:r.height};});
 assert.deepEqual(await relative(page.locator('.menu')),{x:0,y:0,w:848,h:588});assert.deepEqual(await relative(page.locator('.titlebar')),{x:0,y:0,w:848,h:50});assert.deepEqual(await relative(page.locator('.main')),{x:24,y:66,w:800,h:482});
 assert.equal(await page.locator('.menu').evaluate(n=>getComputedStyle(n).backgroundColor),'rgb(17, 15, 35)');assert.equal(await page.locator('.titlebar').evaluate(n=>getComputedStyle(n).backgroundColor),'rgb(25, 21, 52)');
 assert.ok(await page.evaluate(()=>document.fonts.check('12px "Fatachessty Josefin"')));
 assert.ok(await page.locator('.watermark').evaluate(n=>{const r=n.getBoundingClientRect(),s=getComputedStyle(n),title=getComputedStyle(n.querySelector('.wm-name'));return r.height<=26&&s.fontSize==='10px'&&title.fontSize==='12px'&&s.paddingLeft==='8px'&&s.paddingTop==='4px';}));
 const title=page.locator('.ft-brand');await expect(title).toHaveText('Fatachessty');assert.ok(await title.evaluate(n=>n.scrollWidth<=n.clientWidth));const titleBox=await relative(title);assert.equal(titleBox.x,25);assert.ok(titleBox.x+titleBox.w<=126);
 await expect(page.locator('.nc-account-name')).toHaveText('PortOwner');assert.equal(await page.locator('.nav>button').count(),5);
 await page.evaluate(()=>{window.context.user.username='Guest4873515159';window.__skeet.app.store.rename('default','Default gyjp');});
 await expect(page.locator('.nc-account-name')).toHaveText('Guest4873515159');
 assert.ok(await page.locator('.nc-account-name,.nc-account small').evaluateAll(nodes=>nodes.every(n=>n.clientHeight>=18&&parseFloat(getComputedStyle(n).lineHeight)>=16&&n.scrollWidth<=n.clientWidth)));
 const account=await relative(page.locator('.nc-account'));assert.deepEqual([account.y,account.h],[5,40]);
 await page.locator('.nc-account').screenshot({path:'test-results/fatachessty-account-spacing.png'});
 await page.evaluate(()=>{window.context.user.username='PortOwner';window.__skeet.app.store.rename('default','Default');});await expect(page.locator('.nc-account-name')).toHaveText('PortOwner');
 assert.equal(await page.locator('.nav-svg,.ft-tool').evaluateAll(async nodes=>{for(const node of nodes){const url=node.style.getPropertyValue('--ft-icon').match(/url\("(.*)"\)/)[1],image=new Image();image.src=url;await image.decode();if(!image.naturalWidth)throw new Error('Source icon failed to decode');}return nodes.length;}),8);
 for(const tab of ['Rage','Legit','Visuals','Misc','Configs']){
  await page.getByRole('tab',{name:tab,exact:true}).click();const scope=page.locator(`[data-page="${tab}"]`),sections=scope.locator('.ft-subnav button');
  for(let i=0;i<await sections.count();i++){
   if(await sections.nth(i).isVisible())await sections.nth(i).click();
   const panels=scope.locator('fieldset:visible');assert.equal(await panels.count(),3);const rects=await panels.evaluateAll(nodes=>nodes.map(n=>{const r=n.getBoundingClientRect(),m=n.getRootNode().querySelector('.menu').getBoundingClientRect();return {x:r.x-m.x,y:r.y-m.y,w:r.width,h:r.height};}));
   assert.deepEqual(rects.map(r=>r.x),[24,296,568]);assert.deepEqual(rects.map(r=>r.w),[256,256,256]);assert.ok(rects.every(r=>r.y===(['Misc','Configs'].includes(tab)?66:102)&&r.h===(['Misc','Configs'].includes(tab)?478:442)));
  }
 }
 await page.getByRole('tab',{name:'Visuals',exact:true}).click();await page.locator('[data-page="Visuals"] [data-ft-section="1"]').click();
 const toggle=page.getByLabel('Extra Outline',{exact:true});assert.deepEqual(await toggle.evaluate(n=>[n.offsetWidth,n.offsetHeight]),[12,12]);await toggle.check();
 const range=page.getByLabel('Outline Width',{exact:true});assert.deepEqual(await range.evaluate(n=>[n.offsetWidth,n.offsetHeight]),[100,14]);await range.focus();await page.keyboard.press('ArrowRight');assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsOutlineWidth),3);
 await page.getByRole('button',{name:'Material Flat',exact:true}).click();await page.getByRole('option',{name:'Metallic',exact:true}).click();
 await page.getByRole('button',{name:'Choose Own Color',exact:true}).click();await expect(page.getByRole('dialog',{name:'Color picker'})).toBeVisible();await page.getByLabel('Hex color',{exact:true}).fill('#12abef');await page.getByLabel('Hex color',{exact:true}).press('Tab');assert.equal(await page.evaluate(()=>window.__skeet.app.store.settings.chamsOwnColor),'#12abef');await page.getByRole('button',{name:'Close color picker',exact:true}).click();
 await page.getByRole('button',{name:'Search',exact:true}).click();await page.getByLabel('Find a setting',{exact:true}).fill('Menu Style');await page.getByRole('button',{name:'Misc › Menu Style',exact:true}).click();await expect(page.locator('[data-page="Misc"]')).toBeVisible();
 await expect(page.locator('.ft-tool[aria-label=Configs]')).toHaveCount(0);await page.getByRole('tab',{name:'Configs',exact:true}).click();await page.locator('#config-name').fill('Fata profile');await page.getByRole('button',{name:'Create Config',exact:true}).click();await page.getByRole('button',{name:'Quicksave',exact:true}).click();
 await page.getByRole('button',{name:'About',exact:true}).click();await expect(page.getByRole('dialog',{name:'Menu information'})).toContainText('Fatachessty');await page.getByRole('button',{name:'Close dialog',exact:true}).click();
 await page.getByRole('tab',{name:'Rage',exact:true}).click();await page.locator('[data-page="Rage"] [data-ft-section="0"]').click();await expect(page.locator('.toast')).toBeHidden({timeout:6000});await page.waitForTimeout(180);await mkdir('test-results',{recursive:true});await page.locator('.menu').screenshot({path:'test-results/fatachessty-rage.png'});
 await page.reload();await expect(page.locator('.menu')).toHaveAttribute('data-skin','fatachessty');await expect(page.getByLabel('Enable Rage',{exact:true})).not.toBeChecked();await expect(page.locator('.ft-brand')).toHaveText('Fatachessty');assert.ok(await title.evaluate(n=>n.scrollWidth<=n.clientWidth));
 await page.getByRole('tab',{name:'Visuals',exact:true}).click();await page.locator('[data-page="Visuals"] [data-ft-section="1"]').click();await page.waitForTimeout(180);await page.locator('.menu').screenshot({path:'test-results/fatachessty-chams.png'});
 const change=async name=>{await page.getByRole('tab',{name:'Misc',exact:true}).click();await page.locator('[data-select="menuStyle"] .select-toggle').click();await page.getByRole('option',{name,exact:true}).click();};
 await change('NeverChess');assert.equal((await page.locator('.menu').boundingBox()).width,690);await expect(page.locator('.ft-brand')).toBeHidden();await expect(page.locator('.ft-tools')).toBeHidden();
 await change('chessence');assert.equal((await page.locator('.menu').boundingBox()).width,657);await expect(page.locator('[data-page="Misc"] fieldset:visible')).toHaveCount(3);
 await change('Fatachessty');assert.equal((await page.locator('.menu').boundingBox()).width,848);await page.keyboard.press('Insert');await page.reload();await expect(page.locator('.menu')).toBeHidden();
 assert.deepEqual(errors,[]);await writeFile('test-results/fatachessty.json',JSON.stringify({geometry:'848×588',header:50,content:[24,66,800,482],groups:[256,256,256],checkbox:[12,12],slider:[100,14],originalFonts:true,titleFits:true,threeSkins:true,search:true,quicksave:true,configs:true,hiddenNavigation:true},null,2)+'\n');
 console.log('PASS source Fatachessty geometry/fonts/icons, fitting title, all five tabs and sections, original-sized controls, color editor, toolbar, configs/reload and three-skin restoration.');
}finally{await browser?.close();server.kill();}
