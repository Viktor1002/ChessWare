import { build } from 'esbuild';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const assets={};
for(const [flavor,stem] of [['single','stockfish-19-single'],['full','stockfish-19']]){
  assets[flavor]={};
  for(const ext of ['js','wasm']){const data=await readFile(`node_modules/stockfish/bin/${stem}.${ext}`);assets[flavor][ext]={url:`https://github.com/nmrugg/stockfish.js/releases/download/v19.0.1/${stem}.${ext}`,size:data.length,sha256:createHash('sha256').update(data).digest('hex')};}
}
await writeFile('src/engine-assets.js',`// Pinned Stockfish.js 19.0.1; generated from the npm package.\nexport const ENGINE_ASSETS = ${JSON.stringify(assets,null,2)};\n`);
const metadata=`// ==UserScript==
// @name         ChessWare
// @namespace    chess-skeet.local
// @version      1.9.2
// @description  Firefox + Tampermonkey. Skeet / NeverChess / Fatachessty menus, piece chams, watermark and Stockfish 19 NNUE for active Chess.com games.
// @author       ChessWare
// @license      GPL-3.0-or-later
// @match        https://www.chess.com/*
// @match        https://chess.com/*
// @grant        unsafeWindow
// @grant        GM_xmlhttpRequest
// @grant        GM_registerMenuCommand
// @connect      github.com
// @connect      release-assets.githubusercontent.com
// @connect      api.chess.com
// @run-at       document-idle
// @sandbox      JavaScript
// @noframes
// ==/UserScript==`;
await mkdir('dist',{recursive:true});
const userscriptOptions={entryPoints:['src/index.js'],bundle:true,format:'iife',target:['chrome110','firefox115'],loader:{'.css':'text','.png':'dataurl','.jpg':'dataurl','.ttf':'dataurl'},legalComments:'inline'};
await build({...userscriptOptions,outfile:'dist/ChessWare.user.js',banner:{js:metadata}});
await build({entryPoints:['demo/demo.js'],outfile:'demo/bundle.js',bundle:true,format:'iife',target:'chrome110',loader:{'.css':'text','.png':'dataurl','.jpg':'dataurl','.ttf':'dataurl'}});
await writeFile('dist/chessence.user.js',await readFile('dist/ChessWare.user.js'));
await writeFile('dist/chess-skeet.user.js',await readFile('dist/ChessWare.user.js'));
console.log('Built dist/ChessWare.user.js and local preview.');
