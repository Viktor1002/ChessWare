// Native Firefox regression transport only; never distribute this test artifact.
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {build} from 'esbuild';
import JavaScriptObfuscator from 'javascript-obfuscator';
let source=await readFile('loader/loader.js','utf8');
source=source.replaceAll('https://raw.githubusercontent.com/Viktor1002/ChessWare/main/dist/','http://127.0.0.1:4181/dist/')
  .replaceAll('https://raw.githubusercontent.com/Viktor1002/ChessWare/main/release.json','http://127.0.0.1:4181/dist/release.local-test.json')
  .replaceAll('https://raw.githubusercontent.com/Viktor1002/ChessWare/','http://127.0.0.1:4181/');
const manifest=JSON.parse(await readFile('dist/release.json','utf8'));
manifest.url='http://127.0.0.1:4181/dist/'+manifest.url.split('/').pop();
const report=JSON.parse(await readFile('dist/ChessWare.loader.protection.json','utf8'));
const bundled=await build({stdin:{contents:source,resolveDir:resolve('loader'),sourcefile:'loader-native-test.js'},write:false,bundle:true,format:'iife',target:['chrome110','firefox115'],loader:{'.css':'text'},minifyWhitespace:true,legalComments:'none'});
const code=JavaScriptObfuscator.obfuscate(bundled.outputFiles[0].text,report.options).getObfuscatedCode();
const metadata=(await readFile('dist/ChessWare.loader.user.js','utf8')).match(/^\/\/ ==UserScript==[\s\S]*?\/\/ ==\/UserScript==/)[0]
  .replace('chessware.loader','chessware.loader.local-test').replace('// @connect      raw.githubusercontent.com','// @connect      127.0.0.1\n// @connect      raw.githubusercontent.com');
await writeFile('dist/ChessWare.loader.local-test.user.js',metadata+'\n'+code+'\n');
await writeFile('dist/release.local-test.json',JSON.stringify(manifest));
console.log('Built native-only test transport; production artifacts unchanged.');
