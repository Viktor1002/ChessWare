import {test} from 'node:test';
import assert from 'node:assert/strict';
import {MenuVisibility,MENU_VISIBILITY_KEY} from '../src/menu-visibility.js';
const memory=()=>{const data=new Map();return {getItem:key=>data.get(key)||null,setItem:(key,value)=>data.set(key,value)};};
test('closed is the default and closing survives document recreation',()=>{
 const storage=memory(),first=new MenuVisibility(storage);assert.equal(first.visible,false);
 first.set(true);assert.equal(new MenuVisibility(storage).visible,true);
 first.set(false);assert.equal(storage.getItem(MENU_VISIBILITY_KEY),'closed');assert.equal(new MenuVisibility(storage).visible,false);
});
test('another tab and invalid or blocked storage never auto-open the menu',()=>{
 const first=memory(),second=memory();new MenuVisibility(first).set(true);assert.equal(new MenuVisibility(second).visible,false);
 second.setItem(MENU_VISIBILITY_KEY,'true');assert.equal(new MenuVisibility(second).visible,false);
 const blocked={getItem(){throw new Error('SecurityError');},setItem(){throw new Error('SecurityError');}};
 const visibility=new MenuVisibility(blocked);assert.equal(visibility.visible,false);assert.equal(visibility.set(true),true);assert.equal(visibility.set(false),false);
});
