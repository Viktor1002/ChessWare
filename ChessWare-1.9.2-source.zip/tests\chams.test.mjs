import {ENABLED_DEFAULTS as DEFAULTS} from './fixtures/features.mjs';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
import {Chess,sanitize,CHOICES} from '../src/core.js';
const bundle=await build({entryPoints:['src/chams.js'],bundle:true,write:false,platform:'node',format:'esm',loader:{'.css':'text'}});
const {chamsPieces}=await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const settings={...DEFAULTS,rageEnabled:true,chams:true,chamsOwn:true,chamsEnemy:true,chamsMove:true,chamsTarget:true};
const position={fen:'4k3/8/8/3p4/4P3/8/8/4K3 w - - 0 1',player:'w',flipped:false};
const state={allowed:true,analysisAllowed:true,best:'e4d5',threats:[]};
test('chams distinguish the moving piece and actual captured piece from own/enemy silhouettes',()=>{
 const pieces=chamsPieces(position,settings,state),at=s=>pieces.find(p=>p.square===s);
 assert.equal(at('e4').role,'move');assert.equal(at('e4').color,settings.chamsMoveColor);
 assert.equal(at('d5').role,'target');assert.equal(at('d5').side,'b');assert.equal(at('d5').color,settings.chamsTargetColor);
 assert.equal(at('e1').role,'own');assert.equal(at('e8').role,'enemy');
 const disabled=chamsPieces(position,{...settings,chamsMove:false,chamsTarget:false},state);
 assert.equal(disabled.find(p=>p.square==='d5').role,'enemy');assert.equal(disabled.find(p=>p.square==='e4').role,'own');
 assert.deepEqual(chamsPieces(position,{...settings,chams:false},state),[]);
 assert.deepEqual(chamsPieces(position,settings,{...state,allowed:false}),[]);
});
test('en passant marks the captured pawn rather than the empty destination',()=>{
 const pieces=chamsPieces({...position,fen:'4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 2'},settings,{...state,best:'e5d6'});
 assert.equal(pieces.find(p=>p.square==='d5').role,'target');assert.equal(pieces.find(p=>p.square==='e5').role,'move');
 assert.equal(pieces.some(p=>p.square==='d6'),false);
 const quiet=chamsPieces({fen:new Chess().fen(),player:'w'},settings,{...state,best:'e2e4'});assert.equal(quiet.some(p=>p.role==='target'),false);
});
test('own colour does not depend on board orientation and stale/disabled suggestions have no move roles',()=>{
 const pieces=chamsPieces({...position,player:'b',flipped:true},settings,{...state,analysisAllowed:false,selected:'d5',threats:[{square:'e4'}]});
 assert.equal(pieces.find(p=>p.square==='e8').role,'own');assert.equal(pieces.find(p=>p.square==='e1').role,'enemy');
 assert.equal(pieces.find(p=>p.square==='d5').role,'selected');assert.deepEqual([pieces[0].x,pieces[0].y],[37.5,87.5]);
 assert.equal(chamsPieces(position,settings,{...state,best:'a1a8'}).some(p=>['target','move'].includes(p.role)),false);
 const threats=chamsPieces(position,{...settings,chamsThreat:true},{...state,best:null,threats:[{square:'e4'}]});assert.equal(threats.find(p=>p.square==='e4').role,'threat');
});
test('NeverChess replaces legacy modern skin and chams settings survive sanitization',()=>{
 const migrated=sanitize({menuStyle:'New — chessence',width:720,height:570,newWidth:720,newHeight:570,chamsTargetColor:'#abcdef',chamsOpacity:500,chamsGlow:-1});
 assert.deepEqual(CHOICES.menuStyle,['chessence','NeverChess','Fatachessty']);assert.equal(migrated.menuStyle,'NeverChess');assert.equal(migrated.width,690);assert.equal(migrated.height,500);
 assert.equal(migrated.chamsTargetColor,'#abcdef');assert.equal(migrated.chamsOpacity,100);assert.equal(migrated.chamsGlow,0);
});
test('global material and independent role overrides persist without changing target selection',()=>{
 const config=sanitize({...settings,chamsMaterial:'Glass',chamsOwnMaterial:'Metallic',chamsTargetMaterial:'Neon',chamsGlow:7,chamsOutline:true,chamsOutlineWidth:5,chamsPulse:true});
 const pieces=chamsPieces(position,config,state),at=s=>pieces.find(p=>p.square===s);
 assert.equal(at('d5').material,'Neon');assert.equal(at('e4').material,'Glass');assert.equal(at('e1').material,'Metallic');assert.equal(at('e8').material,'Glass');
 assert.equal(config.chamsOutlineWidth,5);assert.equal(config.chamsPulse,true);
 assert.equal(sanitize({chamsMaterial:'unknown',chamsTargetMaterial:'unknown'}).chamsTargetMaterial,'Inherit');
 assert.equal(CHOICES.chamsMaterial.length,8);
});
