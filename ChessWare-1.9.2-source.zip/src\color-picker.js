export function hexToHsv(hex){
  const [r,g,b]=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255),v=Math.max(r,g,b),min=Math.min(r,g,b),d=v-min;
  let h=0;if(d){if(v===r)h=((g-b)/d)%6;else if(v===g)h=(b-r)/d+2;else h=(r-g)/d+4;h=(h*60+360)%360;}
  return {h,s:v?d/v:0,v};
}
export function hsvToHex({h,s,v}){
  const c=v*s,x=c*(1-Math.abs(((h/60)%2)-1)),m=v-c;
  const rgb=h<60?[c,x,0]:h<120?[x,c,0]:h<180?[0,c,x]:h<240?[0,x,c]:h<300?[x,0,c]:[c,0,x];
  return '#'+rgb.map(n=>Math.round((n+m)*255).toString(16).padStart(2,'0')).join('');
}
export class ColorPicker{
  constructor(root,store,toast){
    this.root=root;this.store=store;this.toast=toast;
    this.el=document.createElement('div');this.el.className='nc-color-picker';this.el.hidden=true;this.el.setAttribute('role','dialog');this.el.setAttribute('aria-label','Color picker');
    this.el.innerHTML='<div class="nc-picker-title"><span></span><button class="nc-picker-close" aria-label="Close color picker">×</button></div><div class="nc-color-sv" tabindex="0" role="slider" aria-label="Saturation and brightness" aria-valuemin="0" aria-valuemax="100"><span class="nc-color-cursor"></span></div><input class="nc-picker-slider nc-picker-hue" type="range" min="0" max="359" step="1" aria-label="Hue"><input class="nc-picker-slider nc-picker-alpha" type="range" min="0" max="100" step="1" aria-label="Color opacity"><label class="nc-picker-hex">HEX<input aria-label="Hex color" maxlength="7" spellcheck="false"></label>';
    root.querySelector('.menu').append(this.el);
    this.sv=this.el.querySelector('.nc-color-sv');this.hue=this.el.querySelector('.nc-picker-hue');this.alpha=this.el.querySelector('.nc-picker-alpha');this.hex=this.el.querySelector('.nc-picker-hex input');
    root.addEventListener('click',e=>{
      const button=e.target.closest('[data-color-key]');
      if(button){if(store.settings.menuStyle!=='chessence')this.open(button);else root.querySelector(`[data-key="${button.dataset.colorKey}"]`)?.focus();}
      else if(e.target.closest('.nc-picker-close')||!this.el.contains(e.target))this.close();
    });
    this.hue.addEventListener('input',()=>{this.hsv.h=Number(this.hue.value);this.commit();});
    this.alpha.addEventListener('input',()=>store.patch({[this.alphaKey]:Number(this.alpha.value)}));
    this.hex.addEventListener('change',()=>{if(/^#[a-f0-9]{6}$/i.test(this.hex.value)){store.patch({[this.key]:this.hex.value});this.sync();}else this.toast('Use a six-digit hex colour.',true);});
    const point=e=>{const r=this.sv.getBoundingClientRect();this.hsv.s=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));this.hsv.v=1-Math.max(0,Math.min(1,(e.clientY-r.top)/r.height));this.commit();};
    this.sv.addEventListener('pointerdown',e=>{if(e.button)return;e.preventDefault();this.sv.setPointerCapture(e.pointerId);point(e);});
    this.sv.addEventListener('pointermove',e=>{if(this.sv.hasPointerCapture(e.pointerId))point(e);});
    this.sv.addEventListener('pointerup',e=>{if(this.sv.hasPointerCapture(e.pointerId))this.sv.releasePointerCapture(e.pointerId);});
    this.sv.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();this.hsv.s=Math.max(0,Math.min(1,this.hsv.s+(e.key==='ArrowRight'?.01:e.key==='ArrowLeft'?-.01:0)));this.hsv.v=Math.max(0,Math.min(1,this.hsv.v+(e.key==='ArrowUp'?.01:e.key==='ArrowDown'?-.01:0)));this.commit();});
    this.el.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();this.close();this.origin?.focus();}});
  }
  open(button){
    if(!this.el.hidden&&this.origin===button){this.close();return;}
    this.origin=button;this.key=button.dataset.colorKey;this.alphaKey=this.key.startsWith('chams')?this.key.slice(0,-5)+'Alpha':this.key==='arrowColor'?'arrowAlpha':'opacity';this.alpha.min=this.alphaKey==='opacity'?5:0;
    this.el.querySelector('.nc-picker-title span').textContent=button.closest('.color-row').querySelector('label').textContent;
    this.el.hidden=false;this.sync();
    const menu=this.root.querySelector('.menu'),rect=menu.getBoundingClientRect(),b=button.getBoundingClientRect(),scale=rect.width/menu.offsetWidth;
    this.el.style.left=Math.max(5,Math.min((b.right-rect.left)/scale+8,menu.offsetWidth-225))+'px';
    this.el.style.top=Math.max(5,Math.min((b.top-rect.top)/scale,menu.offsetHeight-this.el.offsetHeight-6))+'px';
    this.hex.focus();
  }
  close(){this.el.hidden=true;}
  commit(){this.writing=true;this.store.patch({[this.key]:hsvToHex(this.hsv)});this.writing=false;this.draw();}
  sync(){if(this.el.hidden)return;if(this.store.settings.menuStyle==='chessence'){this.close();return;}if(!this.writing)this.hsv=hexToHsv(this.store.settings[this.key]);this.draw();}
  draw(){
    const color=this.store.settings[this.key];this.hex.value=color;this.hue.value=Math.round(this.hsv.h);this.alpha.value=this.store.settings[this.alphaKey];
    this.el.style.setProperty('--picker-hue',hsvToHex({h:this.hsv.h,s:1,v:1}));this.el.style.setProperty('--picker-color',color);this.el.style.setProperty('--picker-thumb',color);
    const cursor=this.el.querySelector('.nc-color-cursor');cursor.style.left=this.hsv.s*100+'%';cursor.style.top=(1-this.hsv.v)*100+'%';
    this.sv.setAttribute('aria-valuenow',String(Math.round(this.hsv.s*100)));this.sv.setAttribute('aria-valuetext',`Saturation ${Math.round(this.hsv.s*100)}%, brightness ${Math.round(this.hsv.v*100)}%`);
  }
}
