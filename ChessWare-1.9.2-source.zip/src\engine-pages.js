export function enginePages({panel,check,range,note,action,select}) {
  const stopButton=()=>`<div class="actions">${action('stop','Stop All Assistance')}</div>`;
  const live=label=>panel('Live analysis',`<div class="stats"><div class="stat"><span>White eval</span><strong data-live="eval">—</strong></div><div class="stat"><span>Depth</span><strong data-live="depth">—</strong></div><div class="stat"><span>${label}</span><strong data-live="best">—</strong></div></div><div class="analysis-note" data-live="choice"></div><div data-live="lines" class="lines"><div class="empty">Waiting for analysis…</div></div><div class="analysis-note" data-live="mate"></div><div class="analysis-note" data-live="threats"></div><div class="resource-line"><span data-live="nodes">No search running</span><span data-live="speed"></span></div>`);
  return {
    Legit:`<div class="columns"><div class="stack">${panel('Engine',
      check('legitEnabled','Enable Legit',true)+check('suggestion','Best Move')+check('autoMove','Auto Play')+check('legitContinuous','Continuous Analysis')+
      '<div class="subtle-rule"></div>'+check('legitEvaluation','Evaluation')+check('legitBestLine','Best Line')+check('legitMate','Mate Detection')+check('legitThreats','Threat Analysis')+
      range('delay','Move Delay','ms')+'<div class="engine-state" data-live="engine">Engine is sleeping</div>')}
      ${panel('Strength limits',range('legitSkill','Engine Strength','/ 20')+note('Real Stockfish Skill Level. Legit is capped at 10 of 20; lower values play weaker.')+'<div class="resource-line"><span data-live="legit-resources"></span></div>')}</div>
      <div class="stack">${panel('Search',range('legitDepth','Search Depth')+range('legitMultiPV','MultiPV')+range('legitMoveTime','Move Time','ms'))}${live('Selected move')}</div></div>`,
    Rage:`<div class="columns"><div class="stack">${panel('Engine',
      check('rageEnabled','Enable Rage',true)+check('bestMove','Best Move')+check('autoPlay','Auto Play')+check('continuous','Continuous Analysis')+
      '<div class="subtle-rule"></div>'+check('evaluation','Evaluation')+check('bestLine','Best Line')+check('mate','Mate Detection')+check('threats','Threat Analysis',false,'Shows attacked pieces for the side to move; not a second engine search.')+
      '<div class="engine-state" data-live="engine">Engine is sleeping</div><div class="subtle-rule"></div>'+select('stopKey','Stop All Assistance'))}
      ${panel('Performance',range('threads','Engine Threads')+range('hash','Hash Size','MB')+'<div class="resource-line"><span data-live="resources"></span></div>'+note('Auto adapts to your device. Threads are limited by browser isolation.'))}</div>
      <div class="stack">${panel('Search',range('depth','Search Depth')+range('multiPV','MultiPV')+range('moveTime','Move Time','ms')+stopButton())}${live('Best move')}</div></div>`
  };
}
