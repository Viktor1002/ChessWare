import { SettingsStore, Chess, guard, resources, searchOptions, attackedPieces, legalMove } from './core.js';
import { ChessComAdapter } from './adapter.js';
import { StockfishEngine } from './engine.js';
import { SkeetUI } from './ui.js';
import { BoardOverlay } from './overlay.js';
import { PieceChams } from './chams.js';
import {GameSession} from './game-session.js';

export function boot({page = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window, adapter, engine, storage=localStorage}={}) {
  if(document.querySelector('#chess-skeet-root'))return;
  const store=new SettingsStore(storage),limits=resources();
  const session=new GameSession();
  adapter ||= new ChessComAdapter(page);
  let snapshot={},reason='Waiting for the chessboard',status='Ready',generation=0,lines=[],best=null,threats=[],selected=null;
  let run=null,scheduled=null,moveTimer=null,lastKey='',completedKey='',settingsKey='',destroyed=false,movePending=false;
  const ui=new SkeetUI(store,limits,{
    invalidate:()=>invalidate(),
    stop:()=>stop()
  });
  const overlay=new BoardOverlay(ui.root.querySelector('.board-overlay'));
  const chams=new PieceChams(ui.root.querySelector('.piece-chams'));
  engine ||= new StockfishEngine(message=>{ui.live('engine',message);status=message;paint();});
  function invalidate(hard=false){generation++;clearTimeout(moveTimer);clearTimeout(scheduled);moveTimer=null;scheduled=null;movePending=false;completedKey='';lines=[];best=null;engine.cancel?.();if(hard)engine.dispose();}
  function stop(){invalidate(true);store.patch({rageEnabled:false,legitEnabled:false,autoPlay:false,autoMove:false});status='Assistance stopped';ui.live('engine','Engine is sleeping');paint();}
  function signature(s){return JSON.stringify(['legitEnabled','suggestion','autoMove','delay','legitSkill','legitDepth','legitMultiPV','legitMoveTime','legitContinuous','rageEnabled','bestMove','autoPlay','continuous','depth','multiPV','moveTime','threads','hash','detect'].map(k=>s[k]));}
  store.subscribe(()=>{
    const key=signature(store.settings);
    if(key!==settingsKey){settingsKey=key;invalidate();scheduled=setTimeout(()=>{scheduled=null;tick();},220);}
    if(!store.settings.detect || (!store.settings.rageEnabled&&!store.settings.legitEnabled)) { engine.dispose(); ui.live('engine','Engine is sleeping'); }
    paint();
  });settingsKey=signature(store.settings);
  function paint(){
    if(destroyed)return;
    const s=store.settings,armed=!!(s.rageEnabled||s.legitEnabled)&&!reason,visibleThreats=armed?threats:[];
    ui.update({snapshot,reason,status,lines,best,threats:visibleThreats,settings:s});
    const finalBoard=snapshot.over&&!guard({...snapshot,over:false,playing:true},s);
    const visualState={best,lines,threats:visibleThreats,selected,allowed:!reason||finalBoard,analysisAllowed:armed};
    chams.render(snapshot,s,visualState);overlay.render(snapshot,s,visualState);
  }
  function sound(){try{const Audio=window.AudioContext||window.webkitAudioContext;const audio=audioContext ||= new Audio();if(audio.state==='suspended'){audio.resume().catch(()=>{});return;}const oscillator=audio.createOscillator(),volume=audio.createGain();oscillator.type='sine';oscillator.frequency.setValueAtTime(640,audio.currentTime);oscillator.frequency.exponentialRampToValueAtTime(390,audio.currentTime+.09);volume.gain.setValueAtTime(.025,audio.currentTime);volume.gain.exponentialRampToValueAtTime(.0001,audio.currentTime+.12);oscillator.connect(volume).connect(audio.destination);oscillator.start();oscillator.stop(audio.currentTime+.12);}catch{}}
  let audioContext=null;
  function tick(){
    if(destroyed)return;
    const p=adapter.read();let s=store.settings;const r=guard(p,s),previous=snapshot;
    const reset=session.update(p,!r);
    if(reset){invalidate(true);snapshot=p;reason=r;selected=null;threats=[];store.disarm();s=store.settings;}
    const key=JSON.stringify([p.route,p.bot,p.playing,p.over,p.player,p.fen,p.context,r]);
    if(key!==lastKey || p.game!==previous.game||reset){
      const prior=previous;if(!reset)invalidate(!!r);lastKey=key;snapshot=p;reason=r;selected=null;
      threats=!r?attackedPieces(p.fen):[];
      if(r)ui.live('engine','Engine paused · active game required');
      if(!r&&prior.fen&&prior.fen!==p.fen&&s.sound)sound();
      status=r||((s.rageEnabled||s.legitEnabled)?'Position ready':'Paused · enable Legit or Rage for this game');
    }else{snapshot=p;reason=r;}
    paint();
    if(reason||scheduled||run||movePending||document.hidden)return;
    const enabled=s.legitEnabled||s.rageEnabled;
    const automatic=s.legitEnabled&&(s.legitContinuous||s.autoMove)||s.rageEnabled&&(s.continuous||s.autoPlay);
    if(enabled&&automatic&&completedKey!==lastKey){
      const ticket=generation;
      run=analyse(p,{...s},ticket).finally(()=>{run=null;if(!destroyed)queueMicrotask(tick);});
    }
  }
  const current=(ticket,p)=>{
    if(destroyed||ticket!==generation)return false;
    const now=adapter.read();return !guard(now,store.settings)&&now.game===p.game&&now.board===p.board&&now.sessionKey===p.sessionKey&&now.fen===p.fen&&now.context===p.context;
  };
  async function analyse(p,s,ticket){
    const startKey=lastKey;status='Analysing…';
    try{
      if(new Chess(p.fen).isGameOver()){completedKey=startKey;status='Position has ended';return;}
      const result=await engine.search(p.fen,searchOptions(s,limits),values=>{
        if(!current(ticket,p))return;lines=values;best=s.rageEnabled?(values[0]?.pv[0]||null):null;status='Analysing…';paint();
      });
      if(!current(ticket,p))return;
      // At reduced strength Stockfish may choose a move outside the exposed MultiPV lines.
      // UCI bestmove is the actual weakened choice; PV1 would silently restore full strength.
      lines=result.lines;best=result.move;
      if(!legalMove(p.fen,best)){best=null;throw new Error('No legal engine move is available.');}
      completedKey=startKey;status='Analysis complete';ui.live('engine','Stockfish 19 NNUE · ready');paint();
      const auto=s.rageEnabled?s.autoPlay:s.autoMove;
      if(auto&&p.player===p.fen.split(' ')[1]){
        movePending=true;
        const delay=s.rageEnabled?250:s.delay;
        status=`Move queued · ${delay} ms`;paint();
        moveTimer=setTimeout(async()=>{
          try{
            if(!current(ticket,p))return;
            const settings=store.settings;if(!(settings.rageEnabled&&settings.autoPlay||settings.legitEnabled&&settings.autoMove))return;
            await adapter.move(best,p,settings,()=>current(ticket,p));
          }catch(error){if(ticket===generation){store.patch({autoPlay:false,autoMove:false});ui.toast(error.message,true);}}
          finally{movePending=false;tick();}
        },delay);
      }
    }catch(error){
      if(ticket!==generation||error.name==='AbortError')return;
      completedKey=startKey;status=error.message;ui.live('engine',error.message);ui.toast(error.message,true);
      store.patch({autoPlay:false,autoMove:false,rageEnabled:false,legitEnabled:false});
    }
  }
  const keydown=e=>{
    if(e.repeat||e.ctrlKey||e.altKey||e.metaKey)return;
    const s=store.settings;
    // The stop key always works, including when a checkbox, slider or text field has focus.
    if(e.code===s.stopKey){e.preventDefault();e.stopPropagation();stop();ui.toast('All assistance stopped.');return;}
    const path=e.composedPath();if(path.some(n=>n?.tagName&&(['TEXTAREA','SELECT'].includes(n.tagName)||(n.tagName==='INPUT'&&!['checkbox','range','button'].includes(n.type)))||n?.isContentEditable))return;
    if(e.code===s.menuKey){e.preventDefault();ui.toggle();}
  };
  const pointerdown=e=>{
    if(e.composedPath().includes(ui.host))return;
    const p=adapter.read();if(guard(p,store.settings)||!p.board?.contains(e.target))return;
    const r=p.board.getBoundingClientRect();let file=Math.floor((e.clientX-r.left)/r.width*8),rank=7-Math.floor((e.clientY-r.top)/r.height*8);
    if(p.flipped){file=7-file;rank=7-rank;}if(file<0||file>7||rank<0||rank>7)return;
    const square=String.fromCharCode(97+file)+(rank+1),piece=new Chess(p.fen).get(square);
    selected=piece?.color===p.fen.split(' ')[1]?square:null;paint();
  };
  const visibility=()=>{if(document.hidden){invalidate();}else tick();};
  const route=()=>tick();
  document.addEventListener('keydown',keydown,true);document.addEventListener('pointerdown',pointerdown,true);document.addEventListener('visibilitychange',visibility);
  window.addEventListener('popstate',route);window.addEventListener('hashchange',route);
  const interval=setInterval(tick,250);const geometry=()=>paint();window.addEventListener('scroll',geometry,true);window.addEventListener('resize',geometry);
  if(typeof GM_registerMenuCommand==='function')GM_registerMenuCommand('Show / hide ChessWare',()=>ui.toggle());
  tick();if(store.error)ui.toast(store.error,true);
  return {store,ui,tick,stop,get state(){return {snapshot,reason,lines,best,status};},destroy(){destroyed=true;clearInterval(interval);invalidate(true);overlay.destroy?.();chams.destroy();audioContext?.close();document.removeEventListener('keydown',keydown,true);document.removeEventListener('pointerdown',pointerdown,true);document.removeEventListener('visibilitychange',visibility);window.removeEventListener('popstate',route);window.removeEventListener('hashchange',route);window.removeEventListener('scroll',geometry,true);window.removeEventListener('resize',geometry);ui.destroy();}};
}
