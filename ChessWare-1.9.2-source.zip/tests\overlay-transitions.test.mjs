import {ENABLED_DEFAULTS as DEFAULTS} from './fixtures/features.mjs';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { Chess } from '../src/core.js';

const bundle = await build({entryPoints:['src/overlay.js'],bundle:true,write:false,platform:'node',format:'esm',loader:{'.css':'text'}});
const {BoardOverlay} = await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));

class Element {
  constructor(tag,root){this.tag=tag;this.root=root;this.children=[];this.attrs=new Map();this.parentNode=null;this.isConnected=true;this.style={setProperty:(k,v)=>this.style[k]=v};this.classList={toggle:()=>{}};}
  setAttribute(k,v){this.attrs.set(k,String(v));} removeAttribute(k){this.attrs.delete(k);} hasAttribute(k){return this.attrs.has(k);}
  toggleAttribute(k,on){if(on)this.setAttribute(k,'');else this.removeAttribute(k);}
  append(...nodes){for(const n of nodes){n.remove();n.parentNode=this;this.children.push(n);}}
  remove(){if(this.parentNode){const list=this.parentNode.children;list.splice(list.indexOf(this),1);this.parentNode=null;}}
  replaceChildren(...nodes){for(const n of [...this.children])n.remove();this.append(...nodes);}
  insertBefore(n,reference){n.remove();n.parentNode=this;const i=reference?this.children.indexOf(reference):this.children.length;this.children.splice(i<0?this.children.length:i,0,n);}
  get nextSibling(){if(!this.parentNode)return null;const a=this.parentNode.children;return a[a.indexOf(this)+1]||null;}
  getRootNode(){return this.root||this;}
}

test('overlays fade out, reverse a cancelled exit and immediately reject stale-position arrows',()=>{
  const original={};for(const key of ['document','requestAnimationFrame','cancelAnimationFrame','matchMedia','setTimeout','clearTimeout'])original[key]=globalThis[key];
  const frames=new Map(),timers=new Map();let id=0;const media={matches:false,addEventListener:(_,fn)=>media.listener=fn,removeEventListener:()=>media.listener=null};
  const root=new Element('root'),svg=new Element('svg',root);root.append(svg);
  globalThis.document={createElement:tag=>new Element(tag,root),createElementNS:(_,tag)=>new Element(tag,root)};
  globalThis.requestAnimationFrame=fn=>{frames.set(++id,fn);return id;};globalThis.cancelAnimationFrame=id=>frames.delete(id);
  globalThis.setTimeout=fn=>{timers.set(++id,fn);return id;};globalThis.clearTimeout=id=>timers.delete(id);globalThis.matchMedia=()=>media;
  const flushFrames=()=>{while(frames.size){const current=[...frames.values()];frames.clear();current.forEach(fn=>fn());}};
  let overlay;
  try{
    overlay=new BoardOverlay(svg);
    const board={isConnected:true,getBoundingClientRect:()=>({left:30,top:40,width:600,height:600})};
    const snapshot={board,fen:new Chess().fen(),flipped:false};
    const settings={...DEFAULTS,rageEnabled:true,legitEnabled:false,animation:true,arrow:true,arrows:false};
    const state={allowed:true,analysisAllowed:true,best:'e2e4',lines:[],threats:[]};
    overlay.render(snapshot,settings,state);const first=overlay.items.get('arrow:e2e4').node;
    assert.ok(first.hasAttribute('data-entering'));flushFrames();assert.equal(first.hasAttribute('data-entering'),false);
    overlay.render(snapshot,{...settings,arrow:false},state);
    assert.equal(first.parentNode,svg);assert.ok(first.hasAttribute('data-leaving'));assert.equal(timers.size,1);
    overlay.render(snapshot,settings,state);
    assert.equal(overlay.items.get('arrow:e2e4').node,first);assert.equal(first.hasAttribute('data-leaving'),false);assert.equal(timers.size,0);
    const game=new Chess();game.move('e4');overlay.render({...snapshot,fen:game.fen()},settings,{...state,best:'e7e5'});
    assert.equal(first.parentNode,null,'old move is removed without an exit delay on a different position');
    assert.ok(overlay.items.has('arrow:e7e5'));
    overlay.render({...snapshot,fen:game.fen()},settings,{...state,allowed:false});flushFrames();
    assert.equal(overlay.items.size,0);assert.ok(svg.hasAttribute('hidden'));assert.equal(frames.size,0);assert.equal(timers.size,0);
    overlay.render(snapshot,settings,state);flushFrames();overlay.render(snapshot,{...settings,arrow:false},state);
    for(const fn of [...timers.values()])fn();timers.clear();assert.ok(svg.hasAttribute('hidden'));
    overlay.render(snapshot,settings,state);media.matches=true;media.listener();
    assert.equal(overlay.motion,false);assert.equal(frames.size,0);assert.equal(overlay.items.get('arrow:e2e4').node.hasAttribute('data-entering'),false);
    overlay.render(snapshot,{...settings,arrow:false},state);assert.equal(overlay.exiting.size,0);assert.ok(svg.hasAttribute('hidden'));
    overlay.destroy();assert.equal(media.listener,null);assert.equal(overlay.style.parentNode,null);
  }finally{overlay?.destroy();for(const[key,value]of Object.entries(original)){if(value===undefined)delete globalThis[key];else globalThis[key]=value;}}
});

