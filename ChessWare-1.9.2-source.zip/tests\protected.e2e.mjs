import {chromium,expect} from '@playwright/test';
import {build} from 'esbuild';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {ENABLED_DEFAULTS} from './fixtures/features.mjs';
const code=await readFile('dist/ChessWare.protected.user.js','utf8');
assert.match(code,/^\/\/ ==UserScript==/);assert.match(code,/\/\/ @name\s+ChessWare/);assert.ok(!code.includes('sourceMappingURL='));
// Run the actual production artifact on a fully intercepted chess.com origin with a local board.
// The fixture supplies game state and transport only; all product code is the protected file.
let fixture=await readFile('demo/demo.js','utf8');
fixture=fixture.replace("import { boot } from '../src/app.js';",'').replace('render();const app=boot({adapter});','render();const app={tick(){},store:{patch(){}},stop(){}};');
assert.ok(!fixture.includes('boot({adapter})'));
const built=await build({stdin:{contents:fixture,resolveDir:process.cwd()+'/demo',sourcefile:'protected-fixture.js'},bundle:true,write:false,format:'iife',loader:{'.css':'empty'}});
const fixtureCode=built.outputFiles[0].text,html=(await readFile('demo/index.html','utf8')).replace('<script src="/demo/bundle.js"></script>','');
const browser=await chromium.launch({channel:'msedge',headless:true});
try{
 const page=await browser.newPage({viewport:{width:1440,height:900}}),errors=[],downloads=[];page.on('pageerror',e=>errors.push(e.message));
 const cache=new Map();await page.exposeFunction('__protectedAssetChunk',async(name,offset)=>{
  if(!/^stockfish-19(?:-single)?\.(?:js|wasm)$/.test(name))throw new Error('Unexpected asset');
  if(!cache.has(name))cache.set(name,await readFile('node_modules/stockfish/bin/'+name));
  if(!offset)downloads.push(name);const data=cache.get(name);return {size:data.length,chunk:data.subarray(offset,offset+1048576).toString('base64')};
 });
 const transport=()=>{window.GM_xmlhttpRequest=opts=>{let aborted=false;const name=new URL(opts.url).pathname.split('/').pop();(async()=>{let data,offset=0;do{const {size,chunk}=await window.__protectedAssetChunk(name,offset);if(aborted)return;data||=new Uint8Array(size);const bytes=Uint8Array.from(atob(chunk),c=>c.charCodeAt(0));data.set(bytes,offset);offset+=bytes.length;opts.onprogress?.({loaded:offset,total:size});}while(offset<data.length);opts.onload({status:200,response:data.buffer});})().catch(()=>opts.onerror?.());return {abort:()=>{aborted=true;opts.onabort?.();}};};};
 await page.route('**/*',async route=>{
  const url=new URL(route.request().url());
  if(url.pathname==='/play/computer')return route.fulfill({contentType:'text/html',body:html});
  return route.fulfill({status:404,body:''});
 });

 await page.goto('https://www.chess.com/play/computer');await page.evaluate(fixtureCode);await page.evaluate(transport);await page.evaluate(code);await page.waitForSelector('#chess-skeet-root',{state:'attached'});
 await expect(page.locator('.menu')).toBeHidden();await page.keyboard.press('Insert');assert.equal(await page.locator('input[type=checkbox]:checked').count(),0);
 await page.evaluate(s=>{window.localStorage.setItem('chess-skeet:v1',JSON.stringify({version:1,defaultsRevision:1,settings:{...s,depth:8,moveTime:300,wmPing:false},active:'default',profiles:[{id:'default',name:'Default',settings:{...s,depth:8,moveTime:300,wmPing:false}}]}));},ENABLED_DEFAULTS);
 await page.reload();await page.evaluate(fixtureCode);await page.evaluate(transport);await page.evaluate(code);await expect(page.locator('.menu')).toBeVisible();await expect(page.locator('.badge')).toHaveText('Bot game');
 await page.getByRole('tab',{name:'Rage',exact:true}).click();await page.getByLabel('Enable Rage',{exact:true}).check();
 await expect(page.locator('[data-page=Rage] [data-live=best]')).not.toHaveText('—',{timeout:60000});
 await page.locator('[data-page=Rage]').getByLabel('Auto Play',{exact:true}).check();await page.waitForFunction(()=>window.__skeet.moveCount>=1);await page.keyboard.press('F8');await expect(page.getByLabel('Enable Rage',{exact:true})).not.toBeChecked();
 for(const [style,brand]of [['Fatachessty','Fatachessty'],['NeverChess','NC'],['chessence','chessence']]){
  await page.getByRole('tab',{name:'Misc',exact:true}).click();await page.locator('[data-select=menuStyle] .select-toggle').click();await page.getByRole('option',{name:style,exact:true}).click();await expect(page.locator('.watermark .wm-name')).toHaveText(brand);
 }
 await page.getByRole('tab',{name:'Configs',exact:true}).click();await page.locator('#config-name').fill('Protected config');await page.getByRole('button',{name:'Create Config',exact:true}).click();await expect(page.locator('.footer .config')).toContainText('Protected config');
 await page.reload();await page.evaluate(fixtureCode);await page.evaluate(transport);await page.evaluate(code);await expect(page.locator('.footer .config')).toContainText('Protected config');assert.deepEqual(errors,[]);assert.ok(downloads.some(p=>p.endsWith('.wasm')));
 await writeFile('test-results/protected.json',JSON.stringify({sha256:createHash('sha256').update(code).digest('hex'),initialSwitchesOff:true,realWASM:true,acceptedFixtureMove:true,stopKey:true,threeSkins:true,configReload:true,errors},null,2)+'\n');
 console.log('PASS actual protected userscript: fresh disabled defaults, full local WASM, legal fixture move, stop, all skins/watermarks, config/reload and zero exceptions.');
}finally{await browser.close();}

