import { chromium } from '@playwright/test';
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const page = await browser.newPage();
  await page.goto('https://www.chess.com/play/computer', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForTimeout(5000);
  console.log(JSON.stringify(await page.evaluate(() => {
    const board = document.querySelector('wc-chess-board, chess-board'); const game = board?.game;
    const call = name => { try { return game?.[name]?.(); } catch(e) { return String(e); } };
    return { title: document.title, url: location.href, board: board?.outerHTML.slice(0, 800), methods: game ? Object.keys(game) : [], fen: call('getFEN'), mode: call('getMode'), player: call('getPlayingAs'), headers: call('getHeaders'), result: call('getResult'), position: call('getPositionInfo'), moves: call('getLegalMoves'), options: call('getOptions'), buttons: [...document.querySelectorAll('button')].map(b => ({ text: b.innerText, test: b.getAttribute('data-cy'), class: b.className })).filter(b => b.text), botElements: [...document.querySelectorAll('[class*="bot"], [data-cy*="bot"]')].slice(0, 30).map(n => ({tag:n.tagName, class:n.className, text:n.textContent.slice(0,80)})) };
  }), null, 2));
} finally { await browser.close(); }
