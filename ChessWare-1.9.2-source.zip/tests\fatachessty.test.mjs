import {test} from 'node:test';
import assert from 'node:assert/strict';
import {SettingsStore,CHOICES,DEFAULTS} from '../src/core.js';
test('three menu styles keep independent dimensions and configurations',()=>{
 const memory=new Map(),storage={getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},store=new SettingsStore(storage);
 assert.deepEqual(CHOICES.menuStyle,['chessence','NeverChess','Fatachessty']);
 store.setMenuStyle('Fatachessty');assert.deepEqual([store.settings.width,store.settings.height,store.settings.spacing],[848,588,16]);
 store.patch({width:900,height:620,spacing:18});store.setMenuStyle('NeverChess');assert.equal(store.settings.width,690);
 store.patch({width:710});store.setMenuStyle('chessence');assert.equal(store.settings.width,657);
 store.setMenuStyle('Fatachessty');assert.deepEqual([store.settings.width,store.settings.height,store.settings.spacing],[900,620,18]);
 const id=store.create('Fatality port');store.save(id);store.setMenuStyle('NeverChess');assert.equal(store.settings.width,710);store.load(id);
 assert.equal(store.settings.menuStyle,'Fatachessty');assert.equal(store.settings.width,900);assert.equal(new SettingsStore(storage).settings.menuStyle,'Fatachessty');
 assert.equal(DEFAULTS.fatalWidth,848);
});
