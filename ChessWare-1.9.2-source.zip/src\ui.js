import css from './styles.css';
import {enginePages} from './engine-pages.js';
import sharedCss from './shared.css';
import neverCss from './neverchess.css';
import fatalCss from './fatachessty.css';
import josefinRegular from './assets/fatachessty/josefin-regular.ttf';
import josefinBold from './assets/fatachessty/josefin-bold.ttf';
import {FatachesstyLayout} from './fatachessty-layout.js';
import museo500 from './assets/neverchess/museo-500.ttf';
import museo900 from './assets/neverchess/museo-900.ttf';
import iconFont from './assets/neverchess/icons.ttf';
import {NeverChessLayout} from './neverchess-layout.js';
import {ColorPicker} from './color-picker.js';
import referenceSprite from './assets/skeet-reference.png';
import { Watermark } from './watermark.js';
import {MenuVisibility,menuSessionStorage} from './menu-visibility.js';
import { VERSION, RANGES, CHOICES, scoreLabel, sanLine, effective } from './core.js';
const icons = {
  Legit: '<path d="m10 3 4 3 3 1 2 6-4-1-3 3 6 5H6l1-6 4-5-4 1-2-2 5-5Z"/><path d="M5 22h15M13 7h.01"/>',
  Rage: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 1v4m0 14v4M1 12h4m14 0h4"/>',
  Misc: '<path d="m9 3 1-2h4l1 2 3 2 3 1v4l-2 2 1 3 1 2-3 3-3-1-3 1-2 1-3-3 1-3-2-3-1-2 3-3Z"/><circle cx="12" cy="11" r="4"/>',
  Visuals: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  Configs: '<path d="M3 5h7l2 3h9v12H3Z"/><path d="M7 12h10M7 16h6"/>',
  close: '<path d="m6 6 12 12M6 18 18 6"/>'
};
const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]}</svg>`;
const check = (key, text, primary = false, title = '') => `<label class="check${primary ? ' primary' : ''}" title="${title}"><input type="checkbox" data-key="${key}"><span>${text}</span></label>`;
const range = (key, text, unit = '') => `<div class="control"><label for="cs-${key}"><span class="control-name" title="${text}">${text}</span><output data-output="${key}" data-unit="${unit}"></output></label><input class="range" id="cs-${key}" aria-label="${text}" type="range" data-key="${key}" min="${RANGES[key][0]}" max="${RANGES[key][1]}" step="${RANGES[key][2]}"></div>`;
const select = (key, text) => `<div class="control"><div class="control-label" id="cs-label-${key}">${text}</div><div class="select" data-select="${key}"><button class="select-toggle" aria-labelledby="cs-label-${key} cs-value-${key}" aria-haspopup="listbox" aria-expanded="false"><span id="cs-value-${key}"></span></button><div class="options" role="listbox" aria-labelledby="cs-label-${key}" hidden>${CHOICES[key].map(v => `<button class="option" role="option" aria-selected="false" data-value="${v}">${v}</button>`).join('')}</div></div></div>`;
const panel = (title, content, cls = '') => `<fieldset class="${cls}"><legend>${title}</legend>${content}</fieldset>`;
const note = text => `<p class="note">${text}</p>`;
const action = (id, label, cls = '') => `<button class="action ${cls}" data-action="${id}">${label}</button>`;
const color = (key, label) => `<div class="color-row"><label for="cs-${key}">${label}</label><button class="swatch" data-swatch="${key}" data-color-key="${key}" aria-label="Choose ${label}"></button><input id="cs-${key}" class="hex" data-key="${key}" aria-label="${label}" maxlength="7" spellcheck="false" pattern="#[0-9a-fA-F]{6}"></div>`;
const referenceStart = css.indexOf('/* Reference geometry:');
const baseCss = css.slice(0, referenceStart);
const referenceCss = css.slice(referenceStart);

function pages() {
  return {
    ...enginePages({panel,check,range,note,action,select}),
    Misc: `<div class="columns"><div class="stack">${panel('Interface', range('scale', 'Menu Scale', '%') + range('spacing', 'Panel Spacing', 'px') + range('width', 'Menu Width', 'px') + range('height', 'Menu Height', 'px') + select('dock', 'Menu Position') + check('watermark', 'Watermark') + '<div class="subtle-rule"></div>' + select('menuKey', 'Toggle menu'))}</div><div class="stack">${panel('Chess Utilities', check('sound', 'Move Sound'))}${panel('General', check('detect', 'Auto-detect Game Mode', true) + note('Automatically connects to the active board in bot games, Live Chess and Daily Chess.') + '<div class="subtle-rule"></div><div class="config-summary" data-live="session"></div>')}</div></div>`,
    Visuals: `<div class="columns"><div class="stack">${panel('Board Visuals', check('lastMove', 'Last Move Highlight') + check('selected', 'Selected Piece') + check('legal', 'Legal Moves') + check('captures', 'Capture Highlight'))}${panel('Move Visuals', check('arrow', 'Best Move Arrow') + check('arrows', 'Multiple Move Arrows') + check('threatIndicators', 'Threat Indicators') + check('check', 'Check Indicator') + check('mateIndicator', 'Mate Indicator') + note('Arrows follow the current position in the active game.'))}</div><div class="stack">${panel('Customization', color('arrowColor', 'Arrow Color') + color('highlightColor', 'Highlight Color') + '<div class="palette" aria-label="Arrow colour presets">' + ['#a4c85a','#67b6d1','#d3ab60','#c486b5','#e47a69'].map(c => `<button aria-label="Arrow colour ${c}" data-color="${c}" style="background:${c}"></button>`).join('') + '</div><div class="subtle-rule"></div>' + range('thickness', 'Arrow Thickness', 'px') + range('opacity', 'Highlight Opacity', '%') + check('animation', 'Animation') + note('Arrow Color recolors all visual effects and chams. Individual colors can then be adjusted separately.'))}${panel('Piece Chams', check('chams','Enable Piece Chams',true) + check('chamsOwn','Own Pieces') + color('chamsOwnColor','Own Color') + check('chamsEnemy','Opponent Pieces') + color('chamsEnemyColor','Opponent Color') + check('chamsMove','Best Move Piece') + color('chamsMoveColor','Move Piece Color') + check('chamsTarget','Capture Target') + color('chamsTargetColor','Target Color') + check('chamsSelected','Selected Piece Chams') + color('chamsSelectedColor','Selected Color') + check('chamsThreat','Threatened Pieces') + color('chamsThreatColor','Threat Color') + '<div class="subtle-rule"></div>' + note('Target follows the engine move, including en passant. Uses the current piece set. Animation controls fades.'))}</div></div>`,
    Configs: `<div class="columns"><div class="stack">${panel('Local configurations', '<div class="config-info"><span>Config name</span><span data-live="profile-count"></span></div><div class="config-list" role="listbox" aria-label="Configurations"></div>' + note('Stored in this browser on Chess.com.'))}</div><div class="stack">${panel('Manage configuration', '<label for="config-name" class="field-label">Config name</label><input id="config-name" class="text-input" maxlength="32" placeholder="My training config" autocomplete="off"><div class="actions">' + action('create', 'Create Config', 'accent') + '</div><div class="subtle-rule"></div><div class="config-summary" data-live="config-summary"></div><div class="actions">' + action('save', 'Save Config') + action('load', 'Load Config') + '</div><div class="actions">' + action('rename', 'Rename Config') + action('delete', 'Delete Config', 'danger') + '</div>')}${panel('Storage', note('Current settings are saved automatically after each change. Save Config updates the selected preset; Load Config restores its saved values.') + '<div class="subtle-rule"></div>' + note('Loading a config cancels pending moves and pauses assistance. Enable a mode manually for the current game.'))}</div></div>`
  };
}

export class SkeetUI {
  constructor(store, limits, actions) {
    this.store = store; this.limits = limits; this.actions = actions;this.visibility=new MenuVisibility(menuSessionStorage());this.visible=this.visibility.visible; this.profileId = store.data.active;
    this.host = document.createElement('div'); this.host.id = 'chess-skeet-root';
    this.root = this.host.attachShadow({ mode: 'open' });
    this.root.innerHTML = `<style>${css}</style><div class="piece-chams" aria-hidden="true" hidden></div><svg class="board-overlay" aria-hidden="true" hidden></svg><button class="watermark" title="Toggle ChessWare menu"><span class="brand">chess<span>ence</span></span><span class="wm-status">locked</span><kbd>Insert</kbd></button><section class="menu" aria-label="ChessWare"><div class="spectrum"></div><header class="titlebar"><span class="brand">chess<span>ence</span></span><span class="edition">live analysis</span><span class="spacer"></span><span class="badge locked">Waiting for game</span><button class="icon-btn close" aria-label="Close menu">${icon('close')}</button></header><div class="workspace"><nav class="nav" role="tablist" aria-label="Settings" aria-orientation="vertical">${CHOICES.tab.map(tab => `<button role="tab" id="tab-${tab}" aria-controls="page-${tab}" data-tab="${tab}" aria-selected="false">${icon(tab)}<span>${tab}</span></button>`).join('')}<div class="nav-tail">CS / ${VERSION}</div></nav><main class="main">${Object.entries(pages()).map(([tab, html]) => `<section id="page-${tab}" role="tabpanel" aria-labelledby="tab-${tab}" data-page="${tab}" hidden><div class="section-head"><h1>${tab}</h1><span>${({Legit:'Stockfish 19 / limited strength',Rage:'Stockfish 19 / NNUE',Misc:'Make it yours.',Visuals:'Read the board.',Configs:'Your settings, saved.'})[tab]}</span></div>${html}</section>`).join('')}</main></div><footer class="footer"><span class="version">v${VERSION}</span><span class="status" role="status">Starting…</span><span class="config"></span><button class="resize-grip" aria-label="Resize menu" title="Drag to resize; also available in Misc"></button></footer><div class="toast" role="status" hidden></div></section>`;
    this.fonts=[];
    if(typeof FontFace==='function')for(const [weight,url]of [[500,museo500],[900,museo900],[400,iconFont]]){const face=new FontFace(weight===400?'NeverChess Icons':'NeverChess Museo',`url(${url})`,{weight:String(weight)});document.fonts.add(face);this.fonts.push(face);face.load().catch(()=>{});}
    if(typeof FontFace==='function')for(const [weight,url]of [[400,josefinRegular],[700,josefinBold]]){const face=new FontFace('Fatachessty Josefin',`url(${url})`,{weight:String(weight)});document.fonts.add(face);this.fonts.push(face);face.load().then(()=>this.fatal?.fitBrand()).catch(()=>{});}
    this.referenceChrome();
    this.menu = this.root.querySelector('.menu');this.menu.hidden=!this.visible;
    document.body.append(this.host);
    this.bind(); store.subscribe(() => this.sync()); this.sync();
    this.watermark = new Watermark(this.root.querySelector('.watermark'),store);
  }
  referenceChrome(){
    this.root.querySelector('style').textContent=baseCss;
    const sharedStyle=document.createElement('style');sharedStyle.textContent=sharedCss;this.root.append(sharedStyle);
    this.referenceStyle=document.createElement('style');this.referenceStyle.textContent=referenceCss;this.root.append(this.referenceStyle);
    this.host.style.setProperty('--nav-reference',`url("${referenceSprite}")`);
    const bar=document.createElement('div');bar.className='drag-strip';bar.title='Drag menu';this.root.querySelector('.menu').append(bar);
    const entries=[['Legit','head'],['Rage','head-ring'],['Visuals','sun'],['Misc','gears'],['Configs','user']];
    this.root.querySelector('.nav').innerHTML=entries.map(([tab,glyph])=>`<button role="tab" id="tab-${tab}" aria-controls="page-${tab}" data-tab="${tab}" aria-label="${tab}" aria-selected="false" title="${tab}" class="nav-${glyph}"><span class="nav-svg">${icon(tab)}</span><span class="nav-label">${tab}</span><span class="reference-icon icon-${glyph}" aria-hidden="true"></span></button>`).join('');
    const menu=this.root.querySelector('.menu');
    menu.insertAdjacentHTML('beforeend','<div class="nc-brand" aria-hidden="true">NEVERCHESS</div><div class="nc-account"><span class="nc-avatar" aria-hidden="true"><span class="nc-avatar-initials">?</span><img alt="" referrerpolicy="no-referrer" hidden></span><div class="nc-account-copy"><span class="nc-account-name">…</span><small>Config: <b class="nc-account-config">Default</b></small></div></div>');
    this.avatarImage=menu.querySelector('.nc-avatar img');this.avatarInitials=menu.querySelector('.nc-avatar-initials');
    this.avatarImage.addEventListener('error',()=>{this.failedAvatar=this.avatarSource;this.avatarImage.hidden=true;this.avatarInitials.hidden=false;});
    this.root.querySelector('.titlebar').insertAdjacentHTML('afterbegin',action('save','Save','nc-save')+'<span class="nc-toolbar-title">General</span>');
    for(const [tab,label,group]of [['Rage','Aimbot','aim'],['Visuals','Visuals','visuals'],['Misc','Miscellaneous','misc']]){const node=document.createElement('span');node.className='nc-nav-group nc-group-'+group;node.textContent=label;this.root.querySelector(`[data-tab="${tab}"]`).before(node);}
    this.root.querySelector('[data-page="Visuals"] .stack:last-child').insertAdjacentHTML('beforeend',panel('Chams Materials',
      '<div class="chams-material-controls">'+select('chamsMaterial','Material')+check('chamsOutline','Extra Outline')+range('chamsOutlineWidth','Outline Width','px')+check('chamsPulse','Pulse')+range('chamsOpacity','Chams Opacity','%')+range('chamsGlow','Chams Glow','px')+'<div class="subtle-rule"></div>'+['Own','Enemy','Move','Target','Selected','Threat'].map(role=>select('chams'+role+'Material',({Own:'Own Material',Enemy:'Opponent Material',Move:'Move Material',Target:'Target Material',Selected:'Selected Material',Threat:'Threat Material'})[role])).join('')+note('Inherit follows Material. Outline and Neon draw the silhouette border; Wireframe draws a crosshatch over the piece silhouette.')+'</div>'));
    this.root.querySelectorAll('fieldset').forEach(field=>{
      const legend=field.querySelector('legend');field.dataset.panel=legend.textContent.toLowerCase().replaceAll(' ','-');
      const body=document.createElement('div');body.className='panel-body';
      [...field.childNodes].filter(n=>n!==legend).forEach(n=>body.append(n));field.append(body);
    });
    this.root.querySelector('[data-page="Misc"] [data-panel="general"] .panel-body').insertAdjacentHTML('beforeend',
      '<div class="subsection">Watermark</div>'+check('watermark','Show Watermark')+check('wmPing','Show Ping')+check('wmTime','Show Time')+select('wmClock','Clock Format')+check('wmSeconds','Show Seconds')+select('wmPosition','Watermark Position')+range('wmOffsetX','Horizontal Offset','px')+range('wmOffsetY','Vertical Offset','px')+range('wmOpacity','Watermark Opacity','%')+note('Ping: HTTP round trip, refreshed every 30 s.'));
    this.root.querySelector('[data-page="Misc"] [data-panel="interface"] .panel-body').insertAdjacentHTML('afterbegin',select('menuStyle','Menu Style'));
    this.never=new NeverChessLayout(this.root);this.fatal=new FatachesstyLayout(this.root,this.store,this);this.colorPicker=new ColorPicker(this.root,this.store,(message,error)=>this.toast(message,error));
  }
  text(selector, value) { for (const n of this.root.querySelectorAll(selector)) if (n.textContent !== String(value)) n.textContent = value; }
  live(key, value) { this.text(`[data-live="${key}"]`, value); }
  bind() {
    this.root.addEventListener('change', e => {
      const key = e.target.dataset.key; if (!key) return;
      const value = e.target.type === 'checkbox' ? e.target.checked : e.target.type === 'range' ? Number(e.target.value) : e.target.value;
      if (key.endsWith('Color') && !/^#[0-9a-f]{6}$/i.test(value)) { this.toast('Use a colour such as #a4c85a.', true); this.sync(); return; }
      this.store.patch({ [key]: value });
    });
    this.root.addEventListener('input', e => { if (e.target.type === 'range' && e.target.dataset.key) this.store.patch({ [e.target.dataset.key]: Number(e.target.value) }); });
    this.root.addEventListener('click', e => {
      if (e.target.closest('.watermark,.close')) this.toggle();
      const section=e.target.closest('button[data-nc-section]');if(section){this.closeSelects();this.never.select(Number(section.dataset.ncSection));}
      const tab = e.target.closest('[data-tab]'); if (tab) { this.store.patch({ tab: tab.dataset.tab }); this.root.querySelector('.main').scrollTop = 0; }
      const toggle = e.target.closest('.select-toggle');
      if(toggle)this.openSelect(toggle);
      const option = e.target.closest('.option'); if (option) { const select=option.closest('.select')||this.dropdown?.select;if(!select)return;const key=select.dataset.select;if(key==='menuStyle')this.store.setMenuStyle(option.dataset.value);else this.store.patch({ [key]: option.dataset.value }); select.querySelector('.select-toggle').focus(); this.closeSelects(); }
      const preset = e.target.closest('[data-color]'); if (preset) this.store.patch({ arrowColor: preset.dataset.color });
      const profile = e.target.closest('[data-profile]'); if (profile) { this.profileId = profile.dataset.profile; this.renderProfiles(); }
      const actionNode = e.target.closest('[data-action]'); if (actionNode) this.handleAction(actionNode.dataset.action);
      if (!e.target.closest('.select,.options')) this.closeSelects();
    });
    this.root.addEventListener('keydown', e => {
      const tab = e.target.closest('[data-tab]');
      if (tab && ['ArrowUp','ArrowDown','Home','End',...(this.store.settings.menuStyle==='Fatachessty'?['ArrowLeft','ArrowRight']:[])].includes(e.key)) { e.preventDefault(); const tabs = [...this.root.querySelectorAll('[data-tab]')];if(this.store.settings.menuStyle!=='chessence')tabs.sort((a,b)=>['Rage','Legit','Visuals','Misc','Configs'].indexOf(a.dataset.tab)-['Rage','Legit','Visuals','Misc','Configs'].indexOf(b.dataset.tab));const i = e.key === 'Home' ? 0 : e.key === 'End' ? tabs.length - 1 : (tabs.indexOf(tab) + (['ArrowDown','ArrowRight'].includes(e.key) ? 1 : -1) + tabs.length) % tabs.length; tabs[i].click(); tabs[i].focus(); }
      const option = e.target.closest('.option');
      if (option && ['ArrowUp','ArrowDown','Home','End','Escape'].includes(e.key)) { e.preventDefault(); if(e.key === 'Escape'){(option.closest('.select')||this.dropdown?.select)?.querySelector('.select-toggle').focus(); this.closeSelects();return;} const opts = [...option.parentElement.children], index = e.key === 'Home' ? 0 : e.key === 'End' ? opts.length-1 : (opts.indexOf(option)+(e.key==='ArrowDown'?1:-1)+opts.length)%opts.length; opts[index].focus(); }
    });
    this.drag(this.root.querySelector('.drag-strip'), false); this.drag(this.root.querySelector('.resize-grip'), true);
    this.drag(this.root.querySelector('.titlebar'), false);
    this.resize = () => this.layout(); window.addEventListener('resize', this.resize);
  }
  closeSelects() {
    if(this.dropdown){const {select,list}=this.dropdown;select.append(list);list.removeAttribute('style');this.dropdown=null;}
    this.root.querySelectorAll('.options').forEach(n=>{n.hidden=true;const key=n.closest('.select')?.dataset.select;for(const option of n.children)option.setAttribute('aria-selected',String(option.dataset.value===this.store.settings[key]));});this.root.querySelectorAll('.select-toggle').forEach(n=>n.setAttribute('aria-expanded','false'));
  }
  openSelect(toggle){
    const open=toggle.getAttribute('aria-expanded')!=='true';this.closeSelects();if(!open)return;
    const select=toggle.closest('.select'),list=select.querySelector('.options');list.hidden=false;toggle.setAttribute('aria-expanded','true');
    if(this.store.settings.menuStyle!=='chessence'){
      this.dropdown={select,list};this.menu.append(list);const rect=this.menu.getBoundingClientRect(),button=toggle.getBoundingClientRect(),scale=this.scale||1;
      list.style.cssText='position:absolute;z-index:40;right:auto;width:'+button.width/scale+'px;left:'+(button.left-rect.left)/scale+'px;max-height:260px;';
      const height=list.offsetHeight,below=(button.bottom-rect.top)/scale+3,top=below+height>this.menu.offsetHeight-5?(button.top-rect.top)/scale-height-3:below;
      list.style.top=Math.max(5,top)+'px';
    }
    list.querySelector('[aria-selected=true]')?.focus();
  }
  async handleAction(actionName) {
    try {
      const name = this.root.querySelector('#config-name').value;
      if (actionName === 'create') { this.profileId = this.store.create(name); this.toast('Config created.'); }
      else if (actionName === 'save') { this.store.save(this.profileId); this.toast('Config saved.'); }
      else if (actionName === 'load') { this.actions.invalidate(); this.store.load(this.profileId); this.toast('Config loaded.'); }
      else if (actionName === 'rename') { this.store.rename(this.profileId, name); this.toast('Config renamed.'); }
      else if (actionName === 'delete') { this.actions.invalidate(); this.store.remove(this.profileId); this.profileId = this.store.data.active; this.toast('Config deleted.'); }
      else await this.actions[actionName]?.();
      this.renderProfiles();
    } catch (error) { this.toast(error.message, true); }
  }
  sync() {
    const s = this.store.settings;
    const old=s.menuStyle==='chessence';
    if(this.skin!==s.menuStyle){
      this.closeSelects();this.never.update(s.tab,false);this.fatal.update(s.tab,false);
      this.skin=s.menuStyle;this.referenceStyle.textContent=old?referenceCss:s.menuStyle==='NeverChess'?neverCss:fatalCss;this.menu.dataset.skin=old?'old':s.menuStyle==='NeverChess'?'neverchess':'fatachessty';this.host.dataset.skin=this.menu.dataset.skin;

    }
    if(s.menuStyle==='NeverChess')this.never.update(s.tab,true);
    if(s.menuStyle==='Fatachessty')this.fatal.update(s.tab,true);
    this.fatal.fitBrand();this.colorPicker.sync();
    this.root.querySelectorAll('[data-key]').forEach(n => { const v = s[n.dataset.key]; if(n.type === 'checkbox') n.checked = v; else n.value = v; if(n.type === 'range'){const fill=`${(v - Number(n.min)) / (Number(n.max) - Number(n.min)) * 100}%`;n.style.setProperty('--fill',fill);n.closest('.control')?.style.setProperty('--fill',fill);} });
    this.root.querySelectorAll('[data-output]').forEach(n => { const key = n.dataset.output, value = s[key]; n.textContent = value === 0 && ['threads','hash'].includes(key) ? 'Auto' : value + (n.dataset.unit ? ' ' + n.dataset.unit : ''); });
    this.root.querySelectorAll('[data-select]').forEach(n => { const value = s[n.dataset.select]; n.querySelector('.select-toggle span').textContent = value; n.querySelectorAll('.option').forEach(o => o.setAttribute('aria-selected',String(o.dataset.value === value))); });
    this.root.querySelectorAll('[data-swatch]').forEach(n => n.style.background = s[n.dataset.swatch]);
    this.root.querySelectorAll('[data-tab]').forEach(n => { const selected = s.tab === n.dataset.tab; n.setAttribute('aria-selected',String(selected)); n.tabIndex = selected ? 0 : -1; });
    this.root.querySelectorAll('[data-page]').forEach(n => n.hidden = s.tab !== n.dataset.page);
    this.root.querySelector('.watermark').hidden = !s.watermark;
    this.host.style.setProperty('--gap',s.spacing+'px'); this.menu.dataset.animated = s.animation;
    this.host.classList.toggle('no-animation',!s.animation);
    const eff = effective(s, this.limits);
    this.live('resources', `${eff.threads} thread${eff.threads === 1 ? '' : 's'} · ${eff.hash} MB hash · ${this.limits.cores} logical cores`);
    const limited=effective({...s,legitEnabled:true},this.limits);
    this.live('legit-resources',`Limit: 1 thread · ${limited.hash} MB hash · depth ≤16`);
    const thread = this.root.querySelector('[data-key="threads"]'); thread.max = this.limits.maxThreads; thread.value = Math.min(s.threads, this.limits.maxThreads);
    const hash = this.root.querySelector('[data-key="hash"]'); hash.max = this.limits.maxHash; hash.value = Math.min(s.hash, this.limits.maxHash);
    for(const [key,input,value,unit] of [['threads',thread,eff.threads,''],['hash',hash,eff.hash,' MB']]){
      input.style.setProperty('--fill',`${(Number(input.value)-Number(input.min))/(Number(input.max)-Number(input.min))*100}%`);
      this.text(`[data-output="${key}"]`,s[key]===0?'Auto':`${value}${unit}${s[key]>value?' (limited)':''}`);
    }
    this.text('.nc-account-config',this.store.active.name);
    this.text('.nc-toolbar-title',s.tab);
    this.text('.footer .config', this.store.active.name + (this.store.dirty ? ' *' : ''));
    this.layout(); this.renderProfiles();
  }
  layout() {
    const s = this.store.settings;
    this.scale = Math.min(s.scale / 100, (innerWidth - 16) / s.width, (innerHeight - 16) / s.height);
    this.menu.style.width = s.width+'px'; this.menu.style.height = s.height+'px'; this.menu.style.transform = `scale(${this.scale})`;
    const width = s.width * this.scale, height = s.height * this.scale;
    const x = s.dock === 'Left' ? 9 : s.dock === 'Right' ? innerWidth - width - 9 : s.x;
    this.menu.style.left = Math.max(8,Math.min(x,innerWidth-width-8))+'px'; this.menu.style.top = Math.max(8,Math.min(s.y,innerHeight-height-8))+'px';
  }
  drag(handle, resize) {
    handle.addEventListener('pointerdown', e => {
      if(e.button !== 0 || (!resize && e.target.closest('button'))) return;
      e.preventDefault(); handle.setPointerCapture(e.pointerId);
      const start = { x:e.clientX,y:e.clientY,left:parseFloat(this.menu.style.left),top:parseFloat(this.menu.style.top),width:this.store.settings.width,height:this.store.settings.height };
      const move = event => {
        if(resize) this.store.patch({width:start.width+(event.clientX-start.x)/this.scale,height:start.height+(event.clientY-start.y)/this.scale});
        else { this.menu.style.left = Math.max(8,Math.min(start.left+event.clientX-start.x,innerWidth-this.menu.offsetWidth*this.scale-8))+'px'; this.menu.style.top = Math.max(8,Math.min(start.top+event.clientY-start.y,innerHeight-this.menu.offsetHeight*this.scale-8))+'px'; }
      };
      const end = () => { handle.removeEventListener('pointermove',move); handle.removeEventListener('pointerup',end); handle.removeEventListener('pointercancel',end); if(!resize) this.store.patch({x:parseFloat(this.menu.style.left),y:parseFloat(this.menu.style.top),dock:'Free'}); };
      handle.addEventListener('pointermove',move);handle.addEventListener('pointerup',end);handle.addEventListener('pointercancel',end);
    });
  }
  renderProfiles() {
    const list = this.root.querySelector('.config-list');
    if(!this.store.data.profiles.some(p=>p.id===this.profileId)) this.profileId=this.store.data.active;
    const signature = JSON.stringify([this.store.data.profiles.map(p=>[p.id,p.name]),this.profileId,this.store.data.active]);
    if(this.profileSignature !== signature){
      this.profileSignature = signature; list.replaceChildren();
      for(const p of this.store.data.profiles){const b=document.createElement('button');b.className='profile';b.dataset.profile=p.id;b.setAttribute('role','option');b.setAttribute('aria-selected',String(p.id===this.profileId));const name=document.createElement('span');name.textContent=p.name;b.append(name);if(p.id===this.store.data.active){const tag=document.createElement('small');tag.textContent='active';b.append(tag);}list.append(b);}
    }
    const p=this.store.profile(this.profileId);this.live('profile-count',`${this.store.data.profiles.length} saved`);
    this.live('config-summary',`${p.name} · Rage depth ${p.settings.depth} · Legit depth ${p.settings.legitDepth}, skill ${p.settings.legitSkill}/20 · Loads paused.`);
  }
  analysisPage(tab,{snapshot:p,reason,settings:s,lines,best,threats}){
    const page=this.root.querySelector(`[data-page="${tab}"]`),legit=tab==='Legit';
    const enabled=legit?s.legitEnabled:s.rageEnabled,allowed=!reason&&enabled;
    const showEval=legit?s.legitEvaluation:s.evaluation,showLine=legit?s.legitBestLine:s.bestLine;
    const showMate=legit?s.legitMate:s.mate,showThreats=legit?s.legitThreats:s.threats,showBest=legit?s.suggestion:s.bestMove;
    const text=(key,value)=>{for(const n of page.querySelectorAll(`[data-live="${key}"]`))if(n.textContent!==String(value))n.textContent=value;};
    const line=allowed?lines[0]:null,san=allowed&&best?sanLine(p.fen,[best],1):'—';
    text('eval',line&&showEval?scoreLabel(line,p.fen):'—');text('depth',line?line.depth:'—');text('best',showBest?san:'—');
    text('nodes',line?`${line.nodes.toLocaleString()} nodes`:'No search running');text('speed',line?`${Math.round(line.nps/1000)} kn/s`:'');
    text('choice',allowed&&legit?(best?`Engine choice · Skill ${s.legitSkill}/20`:'Waiting for the limited-strength choice…'):'');
    text('mate',line&&showMate&&line.kind==='mate'?`Position mate: ${scoreLabel(line,p.fen)} (White perspective)`:'');
    text('threats',allowed&&showThreats?(threats.length?'Attacked: '+threats.map(t=>`${t.square}${t.undefended?' (undefended)':''}`).join(', '):'No pieces of the side to move are attacked.'):'');
    this.lineSignatures??=new Map();
    const signature=JSON.stringify([allowed,showLine,showEval,p?.fen,best,lines.map(l=>[l.score,l.kind,l.pv.join(' ')])]);
    if(this.lineSignatures.get(tab)===signature)return;this.lineSignatures.set(tab,signature);
    const box=page.querySelector('[data-live="lines"]');box.replaceChildren();
    const addRow=(index,score,pv,chosen=false)=>{const row=document.createElement('div');row.className='line-row'+(chosen?' chosen-line':'');for(const [cls,value]of [['line-index',index],['line-score',score],['line-pv',pv]]){const span=document.createElement('span');span.className=cls;span.textContent=value;row.append(span);}box.append(row);};
    if(allowed&&showLine&&(lines.length||best)){
      if(legit&&best&&!lines.some(l=>l.pv[0]===best))addRow('move','—',san,true);
      for(const l of lines)addRow(String(l.index),showEval?scoreLabel(l,p.fen):'',sanLine(p.fen,l.pv),legit&&l.pv[0]===best);
    }else{const empty=document.createElement('div');empty.className='empty';empty.textContent=reason?'Open a game to see analysis.':!enabled?`Enable ${tab} to analyse this position.`:!showLine?'Best Line is hidden.':'Waiting for an engine line…';box.append(empty);}
  }
  update(state) {
    const { snapshot: p, reason, lines = [], settings:s, best, threats = [] } = state;
    const allowed = !reason;
    for(const key of ['rageEnabled','legitEnabled','autoPlay','autoMove']){
      const input=this.root.querySelector(`[data-key="${key}"]`),mode=key==='autoPlay'?'rageEnabled':key==='autoMove'?'legitEnabled':null;
      input.disabled=!allowed||!!mode&&!s[mode];input.title=!allowed?'Open an active game first':mode&&!s[mode]?'Enable the mode for this game first':'Active only for the current game';
    }
    this.updateAccount();
    const badge=this.root.querySelector('.badge');badge.classList.toggle('locked',!allowed);badge.textContent=allowed?(p.bot?'Bot game':'Multiplayer'):'Waiting for game';
    this.text('.footer .status',this.store.error || reason || state.status || 'Ready');
    this.live('session',allowed?`${p.opponent} · playing ${p.player==='w'?'White':'Black'} · ${p.fen.split(' ')[1]==='w'?'White':'Black'} to move`:reason);
    this.live('turn',allowed?(p.fen.split(' ')[1]==='w'?'White':'Black'):'—');
    for(const tab of ['Legit','Rage'])this.analysisPage(tab,{snapshot:p,reason,settings:s,lines,best,threats});
  }
  updateAccount(){
    const profile=this.watermark?.profile||{},name=profile.username||'…',avatar=profile.avatar||null;
    this.text('.nc-account-name',name);this.root.querySelector('.nc-account-name').title=profile.username||'Waiting for Chess.com profile';
    this.avatarInitials.textContent=profile.username?profile.username.slice(0,2).toUpperCase():'?';
    if(avatar!==this.avatarSource){this.avatarSource=avatar;this.failedAvatar=null;if(avatar)this.avatarImage.src=avatar;else this.avatarImage.removeAttribute('src');}
    const show=!!avatar&&avatar!==this.failedAvatar;this.avatarImage.hidden=!show;this.avatarInitials.hidden=show;
  }
  toggle() { this.visible=this.visibility.set(!this.visible);this.menu.hidden=!this.visible;if(!this.visible){this.closeSelects();this.colorPicker.close();this.fatal.close();}if(this.visible){this.layout();this.fatal.fitBrand();this.root.querySelector('[aria-selected="true"][data-tab]')?.focus();} }
  toast(message,error=false) { const el=this.root.querySelector('.toast');el.textContent=message;el.classList.toggle('error',error);el.hidden=false;clearTimeout(this.toastTimer);this.toastTimer=setTimeout(()=>el.hidden=true,4500); }
  destroy(){clearTimeout(this.toastTimer);this.watermark.destroy();this.fatal.destroy();for(const face of this.fonts)document.fonts.delete(face);window.removeEventListener('resize',this.resize);this.host.remove();}
}
