import { isGameRoute, guard, legalMove, uciOf } from './core.js';
import { pageMovePayload, unwrapPage, pageData } from './firefox.js';

const safely = (fn, fallback = null) => { try { return fn() ?? fallback; } catch { return fallback; } };
export class ChessComAdapter {
  constructor(page = window) { this.page = unwrapPage(page); this.document = this.page.document; }
  read() {
    const route = isGameRoute(this.page.location);
    if (!route) return { route: false };
    try { return this.readGame(route); }
    catch(error) { return {route,error:`Position access failed: ${error.message}`}; }
  }
  readGame(route) {
    const boards = [...this.document.querySelectorAll('wc-chess-board, chess-board')];
    const board = unwrapPage(boards.find(b => b.getBoundingClientRect().width > 0 && unwrapPage(b)?.game));
    const game = board?.game;
    if (!game) return { route, board, game: null };
    const headers = safely(() => pageData(this.page,game.getHeaders(),{}), {});
    const options = safely(() => pageData(this.page,game.getOptions(),{}), {});
    const info = safely(() => pageData(this.page,game.getPositionInfo(),{}), {});
    const mode = safely(() => game.getMode()?.name);
    const result = safely(() => game.getResult());
    const playingAs = safely(() => game.getPlayingAs());
    const variant = safely(() => game.getVariant());
    const visible = selector => [...this.document.querySelectorAll(selector)].some(n => n.getBoundingClientRect().width > 0 && n.getBoundingClientRect().height > 0 && this.page.getComputedStyle(n).visibility !== 'hidden');
    const selecting = visible('.bot-selection-cta-button-button, .mode-selection-container-component');
    const bot = /^Play vs (?:Bot|Computer)$/i.test(headers.Event || '') || board.id === 'board-play-computer';
    const standard = variant === 'standard' || variant === 'chess' || variant?.name === 'standard';
    const end = safely(() => game.isAtEndOfLine(), false);
    const history = safely(() => pageData(this.page,game.getHistorySANs(),[]), []);
    const nodes=safely(()=>pageData(this.page,game.getNodeIds()));
    return {
      route, board, game, bot, playing: mode === 'playing' && !selecting && options.enabled !== false && end && standard,
      fen: safely(() => game.getFEN()), player: playingAs === 1 ? 'w' : playingAs === 2 ? 'b' : null,
      over: result !== '*' || !!info.gameOver, flipped: options.flipped === true || board.classList.contains('flipped'),
      opponent: headers[playingAs === 1 ? 'Black' : 'White'] || (bot?'Computer':'Opponent'),
      last: safely(() => pageData(this.page,game.getLastMove())), history, info,
      sessionKey:JSON.stringify([this.page.location.pathname,headers.Site,headers.Event,headers.Date,headers.Time,headers.UTCDate,headers.UTCTime,headers.GameId,headers.GameID,headers.Link,headers.White,headers.Black,Array.isArray(nodes)?nodes[0]:null]),
      // Captures history identity to reject results after takebacks or a new game at the same FEN.
      context: JSON.stringify([headers.Date, headers.White, headers.Black, nodes, history])
    };
  }
  async move(uci, expected, settings, stillCurrent) {
    const now = this.read();
    const reason = guard(now, settings);
    if (reason || !stillCurrent() || now.game !== expected.game || now.board !== expected.board || now.sessionKey !== expected.sessionKey || now.fen !== expected.fen || now.context !== expected.context || now.player !== now.fen?.split(' ')[1]) throw new Error(reason || 'Position or game changed before the move.');
    if (!legalMove(now.fen, uci)) throw new Error('Engine returned an illegal move.');
    const move = safely(() => pageData(this.page,now.game.getLegalMoves(),[]), []).find(m => uciOf(m) === uci);
    if (!move || typeof now.game.move !== 'function') throw new Error('Move API is unavailable on this board.');
    // This is the sole move sink. The active game, position and player turn are checked above.
    now.game.move(pageMovePayload(this.page, move, settings.animation));
    const deadline = Date.now() + 1800;
    while (Date.now() < deadline) {
      await new Promise(resolve => setTimeout(resolve, 60));
      const next = this.read();
      if (!next.route || next.game !== now.game) throw new Error('Board changed during the move.');
      if (next.fen !== now.fen) return true;
    }
    throw new Error('Chess.com did not accept the move. Auto play was stopped.');
  }
}
