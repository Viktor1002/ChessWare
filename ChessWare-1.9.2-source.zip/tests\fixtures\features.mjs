import {DEFAULTS} from '../../src/core.js';
// Feature tests opt in explicitly; production defaults intentionally have every switch off.
export const ENABLED_DEFAULTS={...DEFAULTS,...Object.fromEntries([
 'suggestion','legitContinuous','legitEvaluation','legitBestLine','legitMate','legitThreats',
 'bestMove','continuous','evaluation','bestLine','mate','threats','watermark','wmPing','wmTime','wmSeconds',
 'detect','lastMove','selected','legal','captures','arrow','threatIndicators','check','mateIndicator','animation',
 'chams','chamsOwn','chamsEnemy','chamsMove','chamsTarget','chamsSelected'
].map(key=>[key,true]))};
