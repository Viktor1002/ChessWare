$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Push-Location -LiteralPath $projectRoot
try {
    $releaseVersion = (Get-Content -LiteralPath 'package.json' -Raw | ConvertFrom-Json).version
    $releaseRoot = Join-Path $projectRoot 'release'
    $stageRoot = Join-Path $releaseRoot 'source'
    New-Item -ItemType Directory -Force -Path $stageRoot | Out-Null
    foreach ($sourceDir in @('src','loader','scripts','tests','licenses')) {
        Copy-Item -LiteralPath $sourceDir -Destination $stageRoot -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path (Join-Path $stageRoot 'demo') | Out-Null
    foreach ($demoFile in @('demo.js','index.html')) {
        Copy-Item -LiteralPath (Join-Path 'demo' $demoFile) -Destination (Join-Path $stageRoot 'demo') -Force
    }
    foreach ($sourceFile in @('package.json','package-lock.json','README.md','BUILD.md','LICENSE','CHANGELOG.md','DESIGN.md','VALIDATION.md','.gitignore')) {
        Copy-Item -LiteralPath $sourceFile -Destination $stageRoot -Force
    }
    Compress-Archive -Path (Join-Path $stageRoot '*') -DestinationPath (Join-Path $releaseRoot "ChessWare-$releaseVersion-source.zip") -Force
    Get-Item -LiteralPath (Join-Path $releaseRoot "ChessWare-$releaseVersion-source.zip") | Select-Object Name,Length
} finally { Pop-Location }
