import {Chess,legalMove} from './core.js';
import css from './chams.css';

const GLYPHS={w:{p:'♙',n:'♘',b:'♗',r:'♖',q:'♕',k:'♔'},b:{p:'♟',n:'♞',b:'♝',r:'♜',q:'♛',k:'♚'}};
let nextId=0;
export function chamsPieces(snapshot,settings,state){
  if(!settings.chams||!state.allowed||!snapshot.fen)return [];
  const game=new Chess(snapshot.fen),show=state.analysisAllowed&&((settings.rageEnabled&&settings.bestMove)||(settings.legitEnabled&&settings.suggestion));
  const move=show?legalMove(snapshot.fen,state.best):null;
  // En passant captures the pawn beside the origin, not the empty destination.
  const target=move?.captured?(move.flags.includes('e')?move.to[0]+move.from[1]:move.to):null;
  const threats=new Set((state.threats||[]).map(t=>t.square));
  return game.board().flat().filter(Boolean).flatMap(piece=>{
    const own=piece.color===snapshot.player;
    let role=own?'Own':'Enemy';
    if(piece.square===target&&settings.chamsTarget)role='Target';
    else if(piece.square===move?.from&&settings.chamsMove)role='Move';
    else if(piece.square===state.selected&&settings.chamsSelected)role='Selected';
    else if(threats.has(piece.square)&&settings.chamsThreat)role='Threat';
    else if(!settings['chams'+role])return [];
    let x=piece.square.charCodeAt(0)-97,y=8-Number(piece.square[1]);
    if(snapshot.flipped){x=7-x;y=7-y;}
    const override=settings['chams'+role+'Material'];
    return [{...piece,role:role.toLowerCase(),alpha:settings['chams'+role+'Alpha']??100,material:override&&override!=='Inherit'?override:settings.chamsMaterial,color:settings['chams'+role+'Color'],side:piece.color,key:piece.square+':'+piece.color+piece.type,x:x*12.5,y:y*12.5}];
  });
}

export class PieceChams{
  constructor(layer){
    this.layer=layer;this.items=new Map();this.exiting=new Map();this.frames=new Set();
    this.style=document.createElement('style');this.style.textContent=css;layer.getRootNode().append(this.style);
    this.filterId='chessence-chams-outline-'+(++nextId);
    this.filters=document.createElementNS('http://www.w3.org/2000/svg','svg');this.filters.classList.add('cs-chams-filters');this.filters.setAttribute('aria-hidden','true');
    this.filters.innerHTML=`<defs><filter id="${this.filterId}" x="-40%" y="-40%" width="180%" height="180%" color-interpolation-filters="sRGB"><feMorphology in="SourceGraphic" operator="dilate" radius="2" result="dilated"/><feComposite in="dilated" in2="SourceAlpha" operator="out"/></filter></defs>`;
    layer.getRootNode().append(this.filters);this.morphology=this.filters.querySelector('feMorphology');
    this.layer.style.setProperty('--cs-chams-outline-filter',`url(#${this.filterId})`);
    this.media=matchMedia('(prefers-reduced-motion: reduce)');
    this.onMotion=()=>{if(this.settings)this.setMotion(this.settings.animation);};this.media.addEventListener('change',this.onMotion);
  }
  setMotion(enabled){
    this.motion=enabled&&!this.media.matches;this.layer.classList.toggle('cs-chams-motion',this.motion);
    if(!this.motion){for(const id of this.frames)cancelAnimationFrame(id);this.frames.clear();for(const entry of this.items.values())entry.node.removeAttribute('data-entering');for(const entry of this.exiting.values()){clearTimeout(entry.timer);entry.node.remove();}this.exiting.clear();}
  }
  frame(fn){const id=requestAnimationFrame(()=>{this.frames.delete(id);if(!this.disposed)fn();});this.frames.add(id);}
  sprite(board,piece){
    const coordinate=String(piece.square.charCodeAt(0)-96)+piece.square[1];
    const element=board.querySelector(`.piece.${piece.side}${piece.type}.square-${coordinate}`);
    if(!element)return null;
    const style=getComputedStyle(element);
    const image=style.backgroundImage;
    if(image&&image!=='none')return {image,size:style.backgroundSize,position:style.backgroundPosition};
    const img=element.querySelector('img');
    return img?.currentSrc?{image:`url(${JSON.stringify(img.currentSrc)})`,size:'contain',position:'center'}:null;
  }
  remove(key,entry,immediate=false){
    this.items.delete(key);
    if(immediate||!this.motion){entry.node.remove();return;}
    entry.node.removeAttribute('data-entering');entry.node.setAttribute('data-leaving','');
    entry.timer=setTimeout(()=>{entry.node.remove();this.exiting.delete(key);this.layer.hidden=!this.items.size&&!this.exiting.size;},220);
    this.exiting.set(key,entry);
  }
  clear(){for(const id of this.frames)cancelAnimationFrame(id);this.frames.clear();for(const entry of this.exiting.values())clearTimeout(entry.timer);this.exiting.clear();this.items.clear();this.layer.replaceChildren();this.layer.hidden=true;this.board=null;this.position='';}
  render(snapshot,settings,state){
    if(this.disposed)return;this.settings=settings;this.setMotion(settings.animation);
    if(!state.allowed||!snapshot.board?.isConnected){this.clear();return;}
    const rect=snapshot.board.getBoundingClientRect();if(!rect.width||!rect.height){this.clear();return;}
    if(this.board!==snapshot.board||this.flipped!==snapshot.flipped)this.clear();
    this.board=snapshot.board;this.flipped=snapshot.flipped;
    const changed=this.position!==snapshot.fen;this.position=snapshot.fen;
    if(changed){for(const entry of this.exiting.values()){clearTimeout(entry.timer);entry.node.remove();}this.exiting.clear();}
    for(const key of ['left','top','width','height'])this.layer.style[key]=rect[key]+'px';
    this.layer.style.setProperty('--cs-chams-alpha',settings.chamsOpacity/100);
    this.layer.style.setProperty('--cs-chams-glow',settings.chamsGlow+'px');
    this.layer.dataset.outline=String(settings.chamsOutline);this.layer.dataset.pulse=String(settings.chamsPulse&&this.motion);
    this.morphology.setAttribute('radius',settings.chamsOutlineWidth);
    let pieces;try{pieces=chamsPieces(snapshot,settings,state);}catch{this.clear();return;}
    const keys=new Set(pieces.map(p=>p.key));
    for(const [key,entry] of this.items)if(!keys.has(key))this.remove(key,entry,changed);
    for(const piece of pieces){
      let entry=this.items.get(piece.key);
      if(!entry&&this.exiting.has(piece.key)){entry=this.exiting.get(piece.key);clearTimeout(entry.timer);this.exiting.delete(piece.key);entry.node.removeAttribute('data-leaving');this.items.set(piece.key,entry);}
      if(!entry){
        const node=document.createElement('div');node.className='cs-cham';node.dataset.chamsKey=piece.key;node.dataset.chamsSquare=piece.square;
        const shape=document.createElement('span');shape.className='cs-cham-shape';
        const edge=document.createElement('span');edge.className='cs-cham-outline';const edgeShape=document.createElement('span');edgeShape.className='cs-cham-shape';edge.append(edgeShape);
        node.append(edge,shape);this.layer.append(node);entry={node,shape,edgeShape};this.items.set(piece.key,entry);
        if(this.motion){node.setAttribute('data-entering','');this.frame(()=>this.frame(()=>node.removeAttribute('data-entering')));}
      }
      entry.node.dataset.role=piece.role;entry.node.style.left=piece.x+'%';entry.node.style.top=piece.y+'%';entry.node.style.setProperty('--cs-chams-color',piece.color);
      entry.node.dataset.material=piece.material||'Flat';entry.node.style.setProperty('--cs-chams-rgb',[1,3,5].map(i=>parseInt(piece.color.slice(i,i+2),16)).join(' '));
      entry.node.style.setProperty('--cs-chams-piece-alpha',settings.chamsOpacity*piece.alpha/10000);
      const sprite=this.sprite(snapshot.board,piece);
      // Use the active Chess.com piece set as the alpha mask; Unicode is only a fixture/fallback.
      entry.shape.classList.toggle('cs-cham-glyph',!sprite);
      entry.shape.textContent=sprite?'':GLYPHS[piece.side][piece.type];
      entry.shape.style.maskImage=sprite?.image||'none';entry.shape.style.maskSize=sprite?.size||'contain';entry.shape.style.maskPosition=sprite?.position||'center';
      if(!sprite){const fallback=snapshot.board.querySelector(`[data-square="${piece.square}"]`);if(fallback){const style=getComputedStyle(fallback);entry.shape.style.font=style.font;entry.shape.style.lineHeight=style.lineHeight;}else entry.shape.style.fontSize=(rect.width/8*.78)+'px';}
      entry.edgeShape.className=entry.shape.className;entry.edgeShape.style.cssText=entry.shape.style.cssText;entry.edgeShape.textContent=entry.shape.textContent;
    }
    this.layer.hidden=!this.items.size&&!this.exiting.size;
  }
  destroy(){this.clear();this.disposed=true;this.media.removeEventListener('change',this.onMotion);this.style.remove();this.filters.remove();}
}
