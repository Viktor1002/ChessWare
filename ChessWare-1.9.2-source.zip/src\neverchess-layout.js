// Panel views retain the five chess tabs; dimensions/widgets follow the supplied ImGui source.
export const NEVER_SECTIONS={
  Legit:[['General','engine','search'],['Limits','strength-limits','search'],['Analysis','search','live-analysis']],
  Rage:[['General','engine','search'],['Performance','performance','search'],['Analysis','search','live-analysis']],
  Visuals:[['General','board-visuals','move-visuals'],['Chams','piece-chams','chams-materials'],['Style','customization','board-visuals']],
  Misc:[['General','interface','general'],['Utilities','chess-utilities','general'],['Watermark','general','interface']],
  Configs:[['General','local-configurations','manage-configuration'],['Manage','manage-configuration','storage'],['Storage','storage','local-configurations']]
};
export class NeverChessLayout{
  constructor(root){
    this.root=root;this.views=new Map();this.original=new Map();this.active=false;
    for(const panel of root.querySelectorAll('fieldset'))this.original.set(panel,{parent:panel.parentNode,next:panel.nextSibling});
    const bar=root.querySelector('.titlebar');root.querySelector('.nc-toolbar-title')?.remove();
    this.sections=document.createElement('div');this.sections.className='nc-sections';this.sections.setAttribute('aria-label','NeverChess sections');
    bar.querySelector('.nc-save').after(this.sections);
    for(let index=0;index<3;index++){const button=document.createElement('button');button.className='nc-section';button.dataset.ncSection=index;button.setAttribute('aria-pressed','false');this.sections.append(button);}
  }
  select(index){this.views.set(this.tab,index);this.update(this.tab,true);}
  update(tab,enabled){
    const signature=JSON.stringify([tab,enabled,this.views.get(tab)||0]);if(signature===this.signature)return;this.signature=signature;
    this.tab=tab;this.active=enabled;
    const materials=this.root.querySelector('[data-panel="chams-materials"]'),controls=this.root.querySelector('.chams-material-controls');
    if(!enabled){
      // Restore DOM order and old Skeet's four-panel geometry.
      for(const [panel,where]of [...this.original].reverse()){where.parent.insertBefore(panel,where.next?.parentNode===where.parent?where.next:null);panel.hidden=false;panel.removeAttribute('data-nc-column');}
      this.root.querySelector('[data-panel="piece-chams"] .panel-body').prepend(controls);materials.hidden=true;
      return;
    }
    materials.querySelector('.panel-body').append(controls);
    const index=this.views.get(tab)||0,definition=NEVER_SECTIONS[tab],selected=definition[index];
    for(const [i,button]of [...this.sections.children].entries()){button.textContent=definition[i][0];button.setAttribute('aria-pressed',String(i===index));}
    const page=this.root.querySelector(`[data-page="${tab}"]`),columns=page.querySelector('.columns');
    page.dataset.ncView=selected[0];
    for(const panel of page.querySelectorAll('fieldset')){
      const column=panel.dataset.panel===selected[1]?1:panel.dataset.panel===selected[2]?2:0;
      panel.hidden=!column;panel.dataset.ncColumn=String(column);columns.append(panel);
    }
  }
}
